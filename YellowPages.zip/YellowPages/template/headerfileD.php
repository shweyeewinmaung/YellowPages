<?php
session_start();

include("../../YellowPages/library/db.php");
include("../../YellowPages/library/function.php");
include("../../YellowPages/library/globalfunction.php");
//include("../../library/permission.php");
include("../../YellowPages/dal/dal_customer.php");

/*if (isset($_POST['Customer_Name']))
{	
	$Customer_ID=AutoID($conn, 'tbl_customer','Customer_ID','C-',6);
	$Customer_Name=Clean($conn,$_POST['Customer_Name']);
	$Customer_Phone=Clean($conn,$_POST['Customer_Phone']);
	$Customer_Email=Clean($conn,$_POST['Customer_Email']);
	$Customer_Password=Clean($conn,$_POST['Customer_Password']);
	$Customer_Address=Clean($conn,$_POST['Customer_Address']);
	$Created_Date=GetCurrentDate();
	$Lastin_Date=GetCurrentDate();
	
	$ret=GetCustomerDataBy_CustomerEmail($conn,$Customer_Email);
		
	$num=mysqli_num_rows($ret);
	if($num>0)
	{
		$_SESSION['Customer_Email']="Exist";
	}else{
		InsertCustomer($conn,$Customer_ID, $Customer_Name, $Customer_Email, $Customer_Password,$Customer_Address,$Created_Date,$Lastin_Date);
		$_SESSION['Customer_Email']="Success";
	}
}*/
if(isset($_POST['btnAdd']))//Start btnAdd
	{
	//$tbl_name = temp_members_db;//table name
	$confirm_code = md5(uniqid(rand()));//Random Confirmation Code
	
	$Customer_Name=Clean($conn,$_POST['Customer_Name']);
	$Customer_Phone=Clean($conn,$_POST['Customer_Phone']);
	$Customer_Email=Clean($conn,$_POST['Customer_Email']);
	$Customer_Password=Clean($conn,$_POST['Customer_Password']);
	$Customer_Address=Clean($conn,$_POST['Customer_Address']);
	$Created_Date=GetCurrentDate();

	$sql = "INSERT INTO temp(confirm_code,Customer_Name,Customer_Phone,Customer_Email,Customer_Password,Customer_Address,Created_Date)VALUES('$confirm_code','$Customer_Name','$Customer_Phone','$Customer_Email','$Customer_Password','$Customer_Address','$Created_Date')";
	
	$result = mysqli_query($conn,$sql);

	
	if($result)//if sucessfully inserted data into database,send confirmation linl to email
	{ 
	/*************Send email to Owner Start***************************/
		 $toMail = 'shweyee@dpsmap.com'; // your email address     dpsmap@gmail.com
		//$toMail = 'shweyee@dpsmap.com'; 
		//$BCCMail = 'sonnyamo@gmail.com'; //sonnyamo@gmail.com,  BCC (Crbon copy) also send the email to this address (leave empty if you don't use it)
		$thanksPage = 'http://www.xinrei.com/YellowPages'; // the URL of the thank you page, You can modify the url and make it yours.
		$mailSub = 'Registration Activation Email '; // the subject of the email which you can change


			//================= DON'T EDIT BELOW THIS CODE ==============================

			$mailBody = '<font face="arial" size="12px" color="#000000">';
			foreach ($_POST as $field => $input) { 
				if( $field != "submit"  ){
					$mailBody .= '<tr><td style="font-size:12px"><b >'.ucfirst ($field) .'</b></td>
                                      <td style="font-size:12px"> : '. trim(strip_tags($input)) . '</td></tr>'; 
				}	
			}
				//===============================================================
				$mailBody .= '</table></font>';
				//===============================================================

				$headers = "From: $Customer_Email \r\n";
				//$headers .= "bcc: $BCCMail \r\n";
				$headers .= "Content-type: text/html\r\n";
				//$sendRem = mail($toMail, $mailSub, $mailBody, $headers);
				$sendRem = mail($toMail, $mailSub, $mailBody, $headers);
		
		/**************Send email to Owner End*************************/
		
		/**************Send email to customer start**********************/
		
		$to = $Customer_Email; // send email to...
		$subject = "Your confirmation link here";//your subject
		$header = "From:shweyee@dpsmap.com";//$header = "from:your name <your email>";//from
                //$header = "From:shweyee@dpsmap.com";//$header = "from:your name <your email>";//from
		$message="Your Confirmation link \r\n";//your message
		$message.="Click on this link to activate your account \r\n";
		//$message.="http://www.xinrei.com/mapdownload/confirmationmagway.php?passkey=$confirm_code \r \n";
		$message.="http://www.xinrei.com/YellowPages/Confirm?passkey=$confirm_code \r \n";
		
		$sentmail = mail($to,$subject,$message,$header);//send email
		
		/***************Send email to customer end*********************/
		if($sentmail){	
						//header('location:../thank.php');
						 print "<script language=\"JavaScript\">window.location.href=\"../Thank\";</script>";
					exit;
				}else{
					print '<h3>Failed to send your query.</h3>';
					print '<h4>Please Try Later.</h4>';
				}
		
	} 
		//if not found
	else {
		echo "Not found your email in our database";
	}
	//if your email successfully sent
	if($sentmail)
	{
		echo "Your Confirmation link has been sent to your email address.";
	} 
	else
	{
		echo "Cannot sent Confirmation link to your email address";
	}
}//end btnAdd
?>
<!DOCTYPE HTML>
<!--
	Phase Shift by TEMPLATED
	templated.co @templatedco
	Released for free under the Creative Commons Attribution 3.0 license (templated.co/license)
--><head>
<title>DPS Yellow Pages</title>
<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
</head>
    
    <body>
    <!-- Header -->
					<div id="header" class="skel-panels-fixed">
						<div id="logo">
							<h1><a href="../../YellowPages/">DPS</a></h1>
                             <?php
		if(!isset($_SESSION['SESS']['Customer']))
		{
			?>
            	<!--<form action="../loginval.php" method="POST">
                    <input type="text" name="txtname" placeholder="UserName" style="color:#000;" required />
                    <input type="text" name="txtpassword" placeholder="Password" style="color:#000;" required />
                    <input type="submit" value="Login" style="color:#000; background-color:#daf2bf; border:2px solid#daf2bf;">
                </form>-->
                 <button class="btn btn-primary" data-toggle="modal" data-target="#myModal">Login | Sign Up</button>
            <?php
		}
		else
		{
			echo "Welcome : ".$_SESSION['SESS']['Customer']['Customer_Name'];
		}
	?>
                            
								  <font style="color:red; font-size:18px; line-height:50px;">
								  <?php
                                if(@$_SESSION['Customer_Email']=="Success"){ echo "Registration is Successfully Saved"; unset($_SESSION['Customer_Email']);}
                             ?>
                            <?php 
                                if(@$_SESSION['Customer_Email']=="Exist"){ echo "Email is Already Exist!!! Please Choose Another Email to Register"; unset($_SESSION['Customer_Email']);}
                            ?></font>
                             <?php
										if(isset($_SESSION['LogIn']) && $_SESSION['LogIn']="Fail")
										{
											?>
											 <b style="color:red; font-weight:bold;"><?php echo $msg;?></b><br>
                                             <?php
										}
									?>
						</div>
						<nav id="nav">
							<ul>
                            <!-----------Customer Login Menu Start----------------->
                             <?php
		if(!isset($_SESSION['SESS']['Customer']))
		{
			?>
            
            	<li><a href="../Search">Search</a></li>
				<!--<li class="active"><a href="index.html">Homepage</a></li>
				<li><a href="left-sidebar.html">Left Sidebar</a></li>
				<li><a href="right-sidebar.html">Right Sidebar</a></li>
				<li><a href="no-sidebar.html">No Sidebar</a></li>
            	-->
            <?php
		}
		else
		{
			
				?>
             <li><a href="../Search">Search</a></li>
             <li><a href="../CustomerPage">Added Address Info</a></li>
           	<!-- <li class="active"><a href="index.html">CustomerHomepage</a></li>
			<li><a href="left-sidebar.html">CustomerLeft Sidebar</a></li>
			<li><a href="right-sidebar.html">CustomerRight Sidebar</a></li>
			<li><a href="no-sidebar.html">CustomerNo Sidebar</a></li> -->
            <li><a href="../LogOut" >Log Out</a></li>
           
            <?php
		}
	?>
    	<!-------------Customer Login Menu End------------->
                                
							</ul>
                           
						</nav>
                        
					</div>
                   
				<!-- Header -->
                
   			<!-- Large modal -->

<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                    ×</button>
                <h4 class="modal-title" id="myModalLabel">
                    LogIn and Sign Up Form</h4>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-12" >
                        <!-- Nav tabs -->
                        <ul class="nav nav-tabs">
                            <li class="active"><a href="#Login" data-toggle="tab">Login</a></li>
                            <li><a href="#Registration" data-toggle="tab">Sign Up</a></li>
                        </ul>
                        <!-- Tab panes -->
                        <div class="tab-content">
                   		<div class="tab-pane active" id="Login">
                         <form role="form" class="form-horizontal" action="../file/loginval.php" method="post">
                               <div class="form-group">
                                    <label for="email" class="col-sm-2 control-label">
                                        Email </label>
                                    <div class="col-sm-10">
                                        <input type="email" class="form-control" id="Customer_Email" placeholder="Email" name="Customer_Email" required />
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputPassword1" class="col-sm-2 control-label">
                                        Password </label>
                                    <div class="col-sm-10">
                                        <input type="password" class="form-control" id="Customer_Password" placeholder="Password" name="Customer_Password" required/>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-sm-2">
                                    </div>
                                    <div class="col-sm-10">
                                        <button type="submit" class="btn btn-primary btn-sm">
                                            Submit</button>
                                       
                                    </div>
                                  
                                     <div class="col-sm-2">
                                     </div>
                                    <div class="col-sm-10">
                                        <a href="../Forget">Forget Password</a>
                                    </div>
                                </div>
                                </form>
                            </div>
                            <!---------Sign Up Start------------>
                            <div class="tab-pane" id="Registration">
                                <form role="form" class="form-horizontal" method="post">
                               
						
                                <div class="form-group">
                                    <label for="Customer_Name" class="col-sm-2 control-label">
                                        Name</label>
                                     <div class="col-sm-10">
                                     <input type="text"  name="Customer_Name" required placeholder="Enter Name">
                                     </div>
                                </div>
                                <div class="form-group">
                                    <label for="Customer_Phone" class="col-sm-2 control-label">
                                        Phone</label>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control" name="Customer_Phone" placeholder="Enter Phone Number" />
                                    </div>
                                </div>
                                 <div class="form-group">
                                    <label for="email" class="col-sm-2 control-label">
                                        Email</label>
                                    <div class="col-sm-10">
                                        <input type="email" class="form-control" name="Customer_Email" placeholder="Enter Email" />
                                    </div>
                                </div>
                               
                                <div class="form-group">
                                    <label for="password" class="col-sm-2 control-label">
                                        Password</label>
                                    <div class="col-sm-10">
                                        <input type="password" class="form-control" name="Customer_Password" placeholder="Enter Password" />
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="Customer_Address" class="col-sm-2 control-label">
                                        Address</label>
                                    <div class="col-sm-10">
                                        <textarea name="Customer_Address" placeholder="Enter Address"></textarea>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-sm-2">
                                    </div>
                                    <div class="col-sm-10">
                                        <button type="submit" class="btn btn-primary btn-sm" name="btnAdd">Sign Up</button>
                                        <button type="reset" class="btn btn-default btn-sm">Cancel</button>
                                    </div>
                                </div>
                                </form>
                            </div>
                        </div>
                      
                    </div>
               
                </div>
            </div>
        </div>
    </div>
</div>

    </body>

<style>
.nav-tabs {
    margin-bottom: 15px;
}
.sign-with {
    margin-top: 25px;
    padding: 20px;
}
@media screen and (min-width:992px){
.modal-lg{
   width:50%
}
}
</style>
<script>
$('#myModal').modal('show');
</script>
    </html>