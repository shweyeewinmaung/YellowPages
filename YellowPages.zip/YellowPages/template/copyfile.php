<!-- Copyright -->
		<div id="copyright">
			<div class="container"> <span class="copyright"><a href="http://templated.co">Copyright © 2018 by D.P.S</a> </span>
				<ul class="icons">
					<li><a href="#" class="fa fa-facebook"><span>Facebook</span></a></li>
					<li><a href="#" class="fa fa-twitter"><span>Twitter</span></a></li>
					<li><a href="#" class="fa fa-google-plus"><span>Google+</span></a></li>
				</ul>
			</div>
		</div>

	