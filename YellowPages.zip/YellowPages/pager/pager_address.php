<?php

class pager
{
	public $pageSize,$currentPageIndex;
	public $offset,$maxPage;
	public $totalRecordCount;
	
	//Constructor
	function __construct($pageSize,$currentPageIndex)
	{
		//Page Size
		$this->pageSize=$pageSize;
		//by default we show first page
		$this->currentPageIndex=$currentPageIndex;		
		//counting the offset
		$this->offset=($currentPageIndex-1)*$pageSize;
		
		
		
	}	

/////////////////////////// All AddressBook///////////////////////////
	
	function SearchData_GetAllAddress($conn)
	{
		$sql="SELECT * FROM `tbl_address` ORDER BY Address_ID DESC ";
		
		return $sql;
		
	}
	
	function SearchData_GetPublishAddress($conn)
	{
		$sql="SELECT * FROM `tbl_address`  Where Status='Success' ORDER BY Address_ID DESC ";
		
		return $sql;
		
	}
	function SearchData_GetreguestAddress($conn)
	{
		$sql="SELECT * FROM `tbl_address`  Where Status='0' || Status='' ORDER BY Address_ID DESC";
		
		return $sql;
		
	}
	
	/////////////////////////// All Car ///////////////////////////
	
	function SearchData_AddressSearch($conn,$Address,$Category_Name,$Company_Name,$City_Name)
	{
		$A="";
		$CN="";
		$CO="";
		$CI="";
		
		$OrderBy=" ORDER BY Address_ID";
		
		if($Address!="")
		{
			$A="Address LIKE '%$Address%' ";
		}
		
		if($Category_Name!="")
		{
			if($A!="")
			{
				$CN="AND Category_Name LIKE '%$Category_Name%' ";
			}
			elseif($A=="")
			{
				$CN="Category_Name LIKE '%$Category_Name%' ";
			}
		}
		if($Company_Name!="")
		{
			if($A!="" || $CN!="")
			{
				$CO="AND Company_Name LIKE '%$Company_Name%' ";
			}
			elseif($A=="" || $CN=="")
			{
				$CO="Company_Name LIKE '%$Company_Name%' ";
			}
		}
		if($City_Name!="")
		{
			if($A!="" || $CN!="" || $CO!="")
			{
				$CI="AND City_Name LIKE '%$City_Name%' ";
			}
			elseif($A=="" || $CN=="" || $CO=="")
			{
				$CI="City_Name LIKE '%$City_Name%' ";
			}
		}
		$sql="SELECT * FROM `tbl_address` WHERE $A $CN $CO $CI";
		return $sql;
	}
	/****************************************************************/
	//function Search_Data($tableName,$orderByFieldName)

	/********************************************************************/	
	function Search_Data($conn,$str)
	{
		
		$sql= $str . " LIMIT $this->offset,$this->pageSize";
		$this->totalRecordCount=$this->Search_TotalRecordCount($conn,$str);
		//how many pages
		$this->maxPage=ceil($this->totalRecordCount/$this->pageSize);	
		$maxPage= $this->maxPage;
		$result=mysqli_query($conn,$sql) ;
		return $result;
		
		
	}

	/********************************************************************/	

	function Search_TotalRecordCount($conn,$sql)
	{
		//If no search key is defined
		$ret=mysqli_query($conn,$sql);
		$num=mysqli_num_rows($ret);
		
		return $num;					
	}

	/********************************************************************/

	function Generate_Pager($str,$conn)
	{
		/********************************************************************/
		// creating previous and next link	// plus the link to go straight to	// the first and last page
		/********************************************************************/				
		//the name of the current page	
		$self = $_SERVER['PHP_SELF'];
		if(isset($_GET['btnSearch']) )
		{
			if ($this->currentPageIndex>1)
			{
				$pageIndex=$this->currentPageIndex-1;	
				if($this->currentPageIndex==$this->maxPage)
				{
					 //echo  (($this->currentPageIndex*$this->pageSize)+1)-$this->pageSize."-".$this->totalRecordCount."of".$this->totalRecordCount; 
					 //echo  " of total Page".$this->maxPage  ;	
				}
				?>  
            
            <span style="background:#ccc; padding:5px 10px;border:1px solid#ccc; border-radius:2px; color:#ffffff; "><?php				
			echo "<a href='../Address/List?Address=".$_GET[Address]."&Category_Name=".$_GET[Category_Name]."&Company_Name=".$_GET['Company_Name']."&City_Name=".$_GET['City_Name']."&btnSearch=Search&page=1&$str'><<</a>&nbsp;";
			?></span>
             <span style="background:#ccc; padding:5px 10px;border:1px solid#ccc; border-radius:2px; color:#ffffff; "><?php		
			echo "<a href='../Address/List?Address=".$_GET[Address]."&Category_Name=".$_GET[Category_Name]."&Company_Name=".$_GET['Company_Name']."&City_Name=".$_GET['City_Name']."&btnSearch=Search&page=$pageIndex&$str'><</a>&nbsp;";
			?></span><?php							
		}

		else

		{}	
		/***********************************************************/
		if ($this->currentPageIndex==1)
		{
			$pageIndex=$this->currentPageIndex-1;	
			if($this->currentPageIndex==$this->maxPage)
				{
					// echo  (($this->currentPageIndex*$this->pageSize)+1)-$this->pageSize."-".$this->totalRecordCount."qqqof".$this->totalRecordCount; 
					// echo  " of total Page".$this->maxPage  ;	
				}
				?>  
            
           <?php							
		}

		else

		{}	
		/*****************************************************************/
		
						

		/********************************************************************/
		// print the link to access each page

		$b=false;

		for($i=1;$i<=$this->maxPage;$i++)
		{
			if ($i==$this->currentPageIndex)
			{
				?><span style="background:#007cc7; padding:5px 10px; border:2px solid#ccc; border-radius:2px; color:#ffffff;"><?php	
				echo $i . "&nbsp;";
				?></span>
                 <?php
             if($this->currentPageIndex<>$this->maxPage)
				{
					 
				}
			?>
            <?php
			}

			else
			{
				
			}
		}

		/********************************************************************/

		// "Next" and "Last" page link
		if ($this->currentPageIndex<$this->maxPage)
		{
			$pageIndex=$this->currentPageIndex+1;
			?> <span style="background:#ccc; padding:5px 10px;border:1px solid#ccc; border-radius:2px; color:#ffffff; "><?php
			echo "<a href='../Address/List?Address=".$_GET[Address]."&Category_Name=".$_GET[Category_Name]."&Company_Name=".$_GET['Company_Name']."&City_Name=".$_GET['City_Name']."&btnSearch=Search&page=$pageIndex&$str'>></a>&nbsp;";?></span>
             <span style="background:#ccc; padding:5px 10px;border:1px solid#ccc; border-radius:2px; color:#ffffff; "><?php
			echo "<a href='../Address/List?Address=".$_GET[Address]."&Category_Name=".$_GET[Category_Name]."&Company_Name=".$_GET['Company_Name']."&City_Name=".$_GET['City_Name']."&btnSearch=Search&page=$this->maxPage&$str'>>></a>&nbsp;";?></span><?php
			
		}

		else

		{}
	?>
    <span style="color:#deebf3;font-weight:bold;"> &nbsp;&nbsp;&nbsp;
	<?php echo  (($this->currentPageIndex*$this->pageSize)+1)-$this->pageSize."-".$this->currentPageIndex * $this->pageSize."of Result ".$this->totalRecordCount; 	echo " in Total " . $this->maxPage ." Pages";?> </span>
    <?php
		/********************************************************************/

	}
		
		
		
		
		/********************************************************************/
		// "Previous" and "First" page link
		if(!isset($_GET['btnSearch']) )
		{
	
			if ($this->currentPageIndex==1)
		{
			$pageIndex=$this->currentPageIndex-1;	
			if($this->currentPageIndex==$this->maxPage)
				{
					// echo  (($this->currentPageIndex*$this->pageSize)+1)-$this->pageSize."-".$this->totalRecordCount."of".$this->totalRecordCount; 
					//echo  " of total Page".$this->maxPage  ;
						
					// echo (($this->currentPageIndex*$this->pageSize)+1)-$this->pageSize."-".$this->currentPageIndex * $this->pageSize."entries of ".$this->totalRecordCount;  	
 //echo  "Results of Total  ".$this->maxPage  . " Pages " ;
				}
				?>  
            
           <?php							
		}

		else

		{}	
		/*****************************************************************/
		if ($this->currentPageIndex>1)
			{
				$pageIndex=$this->currentPageIndex-1;
				
              	if($this->currentPageIndex==$this->maxPage)
				{
					 //echo  (($this->currentPageIndex*$this->pageSize)+1)-$this->pageSize."-".$this->totalRecordCount."of".$this->totalRecordCount; 
					 //echo  " of total Page".$this->maxPage  ;	
				}
				?>  		
                <span style="background:#ccc; padding:5px 10px;border:1px solid#ccc; border-radius:2px; color:#ffffff; "><?php					
				echo "<a href='../Address/List?page=1&$str'><<</a>&nbsp;";?></span>
                <span style="background:#ccc; padding:5px 10px;border:1px solid#ccc; border-radius:2px; color:#ffffff;"><?php
				echo "<a href='../Address/List?page=$pageIndex&$str'><</a>&nbsp;";?></span><?php
							
			}
	
			else
	
			{}									

		/********************************************************************/
		// print the link to access each page

		$b=false;

		for($i=1;$i<=$this->maxPage;$i++)
		{
			if ($i==$this->currentPageIndex)
			{
			?><span style="background:#007cc7; padding:5px 10px; border:2px solid#ccc; border-radius:2px; color:#ffffff;"><?php	
					echo $i . "&nbsp;"; ?>
             </span>
             <?php
             if($this->currentPageIndex<>$this->maxPage)
				{
					?> <?php
				}
			?>
             
                <?php
			}

			else
			{
				
			}
		}

		/********************************************************************/

		// "Next" and "Last" page link
		if ($this->currentPageIndex<$this->maxPage)
		{
			$pageIndex=$this->currentPageIndex+1;
			?> <span style="background:#ccc; padding:5px 10px;border:1px solid#ccc; border-radius:2px; color:#ffffff; "><?php
			echo "<a href='../Address/List?page=$pageIndex&$str'>></a>&nbsp;";?></span><?php
			?> <span style="background:#ccc; padding:5px 10px;border:1px solid#ccc; border-radius:2px; color:#ffffff;"><?php
			echo "<a href='../Address/List?page=$this->maxPage&$str'>>></a>&nbsp;";?></span>
            
			<?php	
		}
		
		else

		{}
?><span style="color:#deebf3;font-weight:bold;"> &nbsp;&nbsp;&nbsp; <?php  echo (($this->currentPageIndex*$this->pageSize)+1)-$this->pageSize."-".$this->currentPageIndex * $this->pageSize."entries of ".$this->totalRecordCount;  	?>
<?php echo  "Results of Total  ".$this->maxPage  . " Pages " ;
// echo  (($this->currentPageIndex*$this->pageSize)+1)-$this->pageSize."-".$this->totalRecordCount."of".$this->totalRecordCount; 
					// echo  " of total Page".$this->maxPage  ;	?></span><?php
		/********************************************************************/

	}//if
	
	}
	/********************************************************************/
	
	

}	

?>