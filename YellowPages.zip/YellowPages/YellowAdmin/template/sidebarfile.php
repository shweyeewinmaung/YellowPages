<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>DPS Yellow Page Admin</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="../../YellowAdmin/bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="../../YellowAdmin/bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="../../YellowAdmin/bower_components/Ionicons/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="../../YellowAdmin/dist/css/AdminLTE.min.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="../../YellowAdmin/dist/css/skins/_all-skins.min.css">
  <!-- Morris chart -->
  <link rel="stylesheet" href="../../YellowAdmin/bower_components/morris.js/morris.css">
  <!-- jvectormap -->
  <link rel="stylesheet" href="../../YellowAdmin/bower_components/jvectormap/jquery-jvectormap.css">
  <!-- Date Picker -->
  <link rel="stylesheet" href="../../YellowAdmin/bower_components/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css">
  <!-- Daterange picker -->
  <link rel="stylesheet" href="../../YellowAdmin/bower_components/bootstrap-daterangepicker/daterangepicker.css">
  <!-- bootstrap wysihtml5 - text editor -->
  <link rel="stylesheet" href="../../YellowAdmin/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css">

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->

  <!-- Google Font -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
</head>
<body class="hold-transition skin-blue sidebar-mini">
 <header class="main-header">
    <!-- Logo -->
    <a href="../../Admin" class="logo">
      <!-- mini logo for sidebar mini 50x50 pixels -->
      <span class="logo-mini"><b>DPS</b></span>
      <!-- logo for regular state and mobile devices -->
     
     <img src=" ../../YellowAdmin/img/dpsmap_title.png" class="logo-lg" alt="User Image" width="250" height="50">
     
    </a>
    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top">
    <div style="float:right; margin-top:10px; margin-right:10px; color:#007cc7; font-weight:bold;">
      Welcome:: <?php echo $_SESSION['SESS']['User']['User_Name'];?><br> 
          <a href="#"><i class="fa fa-circle text-success"></i>   <?php echo $_SESSION['SESS']['User']['User_Role'];?></a>
          </div>
      <!-- Sidebar toggle button-->
      <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
        <span class="sr-only">Toggle navigation</span>
      </a>

    </nav>
    
  </header>
  <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
      <div class="user-panel">
       <!-- <div class="pull-left image">
          <img src="../../YellowAdmin/dist/img/user2-160x160.jpg" class="img-circle" alt="User Image">
        </div>-->
       <!-- <div class="pull-left info">
           <p> <?php //echo $_SESSION['SESS']['User']['User_Name'];?> </p>
          <a href="#"><i class="fa fa-circle text-success"></i>   <?php //echo $_SESSION['SESS']['User']['User_Role'];?></a>
        </div>-->
      </div>
     
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu" data-widget="tree">
        <li class="header">Admin Dashboard <br>
     
        </li>
       	<!------------User Start----------------------->
        <li <?php if( basename($_SERVER['PHP_SELF'], '.php') == 'userlist' || basename($_SERVER['PHP_SELF'], '.php') == 'userregister'||  basename($_SERVER['PHP_SELF'], '.php') == 'userupdate' ||  basename($_SERVER['PHP_SELF'], '.php') == 'userdelete' ) { ?> class="active treeview" <?php } else { ?>class="treeview" <?php }?> >
          <a href="#">
            <i class="fa fa-dashboard"></i> <span>User</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
              <li <?php if( basename($_SERVER['PHP_SELF'], '.php') == 'userlist' ) { ?> class="active" <?php } else {  }?>><a href="../../Admin/User/List"><i class="fa fa-circle-o"></i> All User</span></a></li>
               <li <?php if( basename($_SERVER['PHP_SELF'], '.php') == 'userregister' ) { ?> class="active" <?php } else {  }?>><a href="../../Admin/User/Register"><i class="fa fa-circle-o"></i>User Entry</span></a></li>
         </ul>
        </li>
       	<!------------User End----------------------->
        <!------------Customer Start----------------------->
         <li <?php if( basename($_SERVER['PHP_SELF'], '.php') == 'customerlist'|| basename($_SERVER['PHP_SELF'], '.php') == 'customerregister' ||  basename($_SERVER['PHP_SELF'], '.php') == 'customerupdate' ||  basename($_SERVER['PHP_SELF'], '.php') == 'customerdelete' ) { ?> class="active treeview"<?php } else { ?>class="treeview" <?php }?>  >
          <a href="#">
            <i class="fa fa-dashboard"></i> <span>Customer</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
          	<li <?php if( basename($_SERVER['PHP_SELF'], '.php') == 'customerlist' ) { ?> class="active" <?php } else {  }?>><a href="../../Admin/Customer/List"><i class="fa fa-circle-o"></i> All Customer</span></a></li>
            <li <?php if( basename($_SERVER['PHP_SELF'], '.php') == 'customerregister' ) { ?> class="active" <?php } else {  }?>><a href="../../Admin/Customer/Register"><i class="fa fa-circle-o"></i>Customer Entry</span></a></li>
          </ul>
        </li>
        <!------------Customer End----------------------->
        <!------------City Start----------------------->
         <li <?php if( basename($_SERVER['PHP_SELF'], '.php') == 'citylist'|| basename($_SERVER['PHP_SELF'], '.php') == 'cityrregister' ||  basename($_SERVER['PHP_SELF'], '.php') == 'cityupdate' ||  basename($_SERVER['PHP_SELF'], '.php') == 'citydelete' ) { ?> class="active treeview"<?php } else { ?>class="treeview" <?php }?>  >
          <a href="#">
            <i class="fa fa-dashboard"></i> <span>City</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
          	<li <?php if( basename($_SERVER['PHP_SELF'], '.php') == 'citylist' ) { ?> class="active" <?php } else {  }?>><a href="../../Admin/City/List"><i class="fa fa-circle-o"></i> All City</span></a></li>
            <li <?php if( basename($_SERVER['PHP_SELF'], '.php') == 'cityregister' ) { ?> class="active" <?php } else {  }?>><a href="../../Admin/City/Register"><i class="fa fa-circle-o"></i>City Entry</span></a></li>
          </ul>
        </li>
        <!------------City End----------------------->
        <!------------Category Start----------------------->
        <li <?php if( basename($_SERVER['PHP_SELF'], '.php') == 'categorylist' || basename($_SERVER['PHP_SELF'], '.php') == 'categoryregister'||  basename($_SERVER['PHP_SELF'], '.php') == 'categoryupdate' ||  basename($_SERVER['PHP_SELF'], '.php') == 'categorydelete') { ?> class="active treeview"<?php } else {?>class="treeview"<?php  }?>  >
          <a href="#">
            <i class="fa fa-dashboard"></i> <span>Category</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
          	<li <?php if( basename($_SERVER['PHP_SELF'], '.php') == 'categorylist' ) { ?> class="active" <?php } else {  }?>><a href="../../Admin/Category/List"><i class="fa fa-circle-o"></i> All Category</span></a></li>
            <li <?php if( basename($_SERVER['PHP_SELF'], '.php') == 'categoryregister' ) { ?> class="active" <?php } else {  }?>><a href="../../Admin/Category/Register"><i class="fa fa-circle-o"></i>Category Entry</span></a></li>
            
          </ul>
        </li>
        <!------------Category End----------------------->
        <!------------Address Start----------------------->
         <li <?php if( basename($_SERVER['PHP_SELF'], '.php') == 'addresslist' || basename($_SERVER['PHP_SELF'], '.php') == 'addressregister'||  basename($_SERVER['PHP_SELF'], '.php') == 'addressupdate' ||  basename($_SERVER['PHP_SELF'], '.php') == 'addressdelete' || basename($_SERVER['PHP_SELF'], '.php') == 'publishaddresslist' || basename($_SERVER['PHP_SELF'], '.php') == 'requestaddresslist') { ?> class="active treeview"<?php } else {?>class="treeview"<?php  }?>  >
          <a href="#">
            <i class="fa fa-dashboard"></i> <span>Address</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
          	<li <?php if( basename($_SERVER['PHP_SELF'], '.php') == 'addresslist' ) { ?> class="active" <?php } else {  }?>><a href="../../Admin/Address/List"><i class="fa fa-circle-o"></i> All Address</span></a></li>
            <li <?php if( basename($_SERVER['PHP_SELF'], '.php') == 'publishaddresslist' ) { ?> class="active" <?php } else {  }?>><a href="../../Admin/Address/PublishList"><i class="fa fa-circle-o"></i> Publish Address</span></a></li>
            <li <?php if( basename($_SERVER['PHP_SELF'], '.php') == 'requestaddresslist' ) { ?> class="active" <?php } else {  }?>><a href="../../Admin/Address/RequestList"><i class="fa fa-circle-o"></i> Request Address</span></a></li>
            <li <?php if( basename($_SERVER['PHP_SELF'], '.php') == 'addressregister' ) { ?> class="active" <?php } else {  }?>><a href="../../Admin/Address/Register"><i class="fa fa-circle-o"></i>Address Entry</span></a></li>
            
          </ul>
        </li>
        <!------------Address End----------------------->
     
        <li><a href="../../Admin/LogOut"><i class="fa fa-circle-o text-aqua"></i> <span>Logout</span></a></li>
      </ul>
    </section>
    <!-- /.sidebar -->
  </aside>
  </body>
  </html>
  <!-- jQuery 3 -->
<script src="../../YellowAdmin/bower_components/jquery/dist/jquery.min.js"></script>
<!-- jQuery UI 1.11.4 -->
<script src="../../YellowAdmin/bower_components/jquery-ui/jquery-ui.min.js"></script>
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<script>
  $.widget.bridge('uibutton', $.ui.button);
</script>
<!-- Bootstrap 3.3.7 -->
<script src="../../YellowAdmin/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- Morris.js charts -->
<script src="../../YellowAdmin/bower_components/raphael/raphael.min.js"></script>
<script src="../../YellowAdmin/bower_components/morris.js/morris.min.js"></script>
<!-- Sparkline -->
<script src="../../YellowAdmin/bower_components/jquery-sparkline/dist/jquery.sparkline.min.js"></script>
<!-- jvectormap -->
<script src="../../YellowAdmin/plugins/jvectormap/jquery-jvectormap-1.2.2.min.js"></script>
<script src="../../YellowAdmin/plugins/jvectormap/jquery-jvectormap-world-mill-en.js"></script>
<!-- jQuery Knob Chart -->
<script src="../../YellowAdmin/bower_components/jquery-knob/dist/jquery.knob.min.js"></script>
<!-- daterangepicker -->
<script src="../../YellowAdmin/bower_components/moment/min/moment.min.js"></script>
<script src="../../YellowAdmin/bower_components/bootstrap-daterangepicker/daterangepicker.js"></script>
<!-- datepicker -->
<script src="../../YellowAdmin/bower_components/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js"></script>
<!-- Bootstrap WYSIHTML5 -->
<script src="../../YellowAdmin/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js"></script>
<!-- Slimscroll -->
<script src="../../YellowAdmin/bower_components/jquery-slimscroll/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="../../YellowAdmin/bower_components/fastclick/lib/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="../../YellowAdmin/dist/js/adminlte.min.js"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<script src="../../YellowAdmin/dist/js/pages/dashboard.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="../../YellowAdmin/dist/js/demo.js"></script>