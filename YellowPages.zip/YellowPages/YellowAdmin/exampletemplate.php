
<div class="wrapper">

 <?php require_once('template/sidebarfileindex.php'); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       <a href="#"><i class="fa fa-dashboard"></i> Dashboard</a>
        
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Dashboard</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content"><!-----Section Start---------->
     
      <div class="row"><!-----Row Start------->
        
       			<section style="width:70%; margin-left:10%;">
							<header class="major"><h2>Add User</h2></header>
							<form method="post">
                    	
                            <div class="form-group">
                              <label for="User_Name">Name:</label>
                              <input type="text" class="form-control" id="User_Name" name="User_Name" required>
                            </div>
                            <div class="form-group">
                            <label for="User_Role">Role:</label><br />
                              <select class="form-control" id="User_Role" name="User_Role">
                                <option>Manager</option>
                                <option>Staff</option>
                               </select>
                              </div>
                              <div class="form-group">
                              <label for="User_Email">Email:</label>
                              <input type="email" class="form-control" id="User_Email" name="User_Email">
                            </div>
                            <div class="form-group">
                              <label for="User_Password">Password:</label>
                              <input type="password" class="form-control" id="User_Password" name="User_Password" required>
                            </div>
                            
                            <button type="submit" class="btn-primary" name="btnAdd"  >Entry</button>
                          
                          </form>
				</section>
				

       
      </div><!-----End Row-------->
     

    </section><!---End Section------->

  </div><!-- /.End content-wrapper -->
  <footer class="main-footer" style="text-align:center;"><strong >Copyright &copy; 2018 by D.P.S.</strong></footer>
  
</div>
<!-- ./wrapper -->


