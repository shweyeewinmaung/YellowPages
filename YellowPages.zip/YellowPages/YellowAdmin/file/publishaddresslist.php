<?php
session_start();

include("../../library/db.php");
include("../../library/function.php");
include("../../library/globalfunction.php");
include("../../library/adminpermission.php");
include("../../dal/dal_address.php");

$ret=GetPublishDataByAddress($conn);
$num=mysqli_num_rows($ret);
?>
<div class="wrapper">

 <?php require_once('../template/sidebarfile.php'); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       <a href="#"><i class="fa fa-dashboard"></i>Publish Address List</a>
        
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Publish Address List</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content"><!-----Section Start---------->
     
      <div class="row"><!-----Row Start------->
        
       			<section >
							<header class="major"><h2>Publish Address List</h2></header>
							<div class="table-responsive">
                    <table id="publishaddress_data" class="table table-striped table-bordered dt-responsive nowrap" width="98%" cellspacing="0" style=" background:#ccc;">
                         <thead style="background:#007cc7;color:#fff; font-weight:bold;">
                            <tr>
                                 	<th>No</th>
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>Lat</th>
                                    <th>Lng</th>
                                    <th>City</th>
                                    <th>Type</th>
                                    <th>Company</th>
                                    <th>View</th>
                                    
                                  
                                    <th>Created Date</th>
                                    <th>Lastin Update</th>
                                    <th>Detail</th>
                                    <th>Edit</th>
                                    <th>Delete</th>
                            </tr>
                            </thead>
                            <tbody>
                             <?php  $u=1;
                                while($row=mysqli_fetch_array($ret)){	?>  
                              <tr>
                                <th><?php echo $u; ?></th>
                                <th><?php echo $row['Address_ID']; ?></th>
                                <th><?php echo $row['Address']; ?></th>
                                <th><?php echo $row['Lat']; ?></th>
                                <th><?php echo $row['Lng']; ?></th>
                                <th><?php echo $row['City_Name']; ?></th>
                                <th><?php echo $row['Category_Name']; ?></th>
                                <th><?php echo $row['Company_Name']; ?></th>
                                 <th><?php echo $row['View']; ?></th>
                               
                                                   
                                <th><?php echo $row['Created_Date']; ?></th>
                                <th><?php echo $row['Lastin_Date']; ?></th>
                                <th><a href="../Address/Detail/<?php echo $row['Address_ID']; ?>">Detail</a></th>
                                <th><a href="../Address/Edit/<?php echo $row['Address_ID']; ?>"><img src="../../YellowAdmin/img/wrench-screwdriver.png"  width="20" height="20"/></a></th>
                                <th><a href="../Address/Remove/<?php echo $row['Address_ID']; ?>">
                <img src="../../YellowAdmin/img/cross-script.png"  width="20" height="20" /></a></th>
                </tr>
                           <?php $u=$u+1;  } ?> 
                           </tbody>
                     </table> 
                </div>
               
				</section>
				

       
      </div><!-----End Row-------->
     

    </section><!---End Section------->

  </div><!-- /.End content-wrapper -->
  <footer class="main-footer" style="text-align:center;"><strong >Copyright &copy; 2018 by D.P.S.</strong></footer>
  
</div>

<!-- ./wrapper -->

  <!-- REQUIRED JS SCRIPTS -->
<link rel="stylesheet" href="../../YellowAdmin/css3/bootstrap.min.css">
<link rel="stylesheet" href="../../YellowAdmin/css3/dataTables.bootstrap.min.css">
<link rel="stylesheet" href="../../YellowAdmin/css3/responsive.bootstrap.min.css">
<script src="../../YellowAdmin/js3/jquery-1.12.4.js"></script>  
<script src="../../YellowAdmin/js3/jquery.dataTables.min.js"></script>  
<script src="../../YellowAdmin/js3/dataTables.bootstrap.min.js"></script> 
<script src="../../YellowAdmin/js3/dataTables.responsive.min.js"></script>  
<script src="../../YellowAdmin/js3/responsive.bootstrap.min.js"></script> 
<script>
    $(document).ready(function() {
    $('#publishaddress_data').DataTable();
} );
    </script>
  <style>
  #publishaddress_data_wrapper{
	  width:98%;
	  color:#fff;
	  font-weight:bold;
  }
  #publishaddress_data_filter{
	 margin-right:10%;
  }
  
  div.dataTables_wrapper div.dataTables_paginate {
	  text-align:left;
  }
  section{ width:100%!important; margin-left:1%!important;}
 
 