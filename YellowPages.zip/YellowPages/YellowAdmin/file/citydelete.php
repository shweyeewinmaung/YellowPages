<?php
session_start();

include("../../library/db.php");
include("../../library/function.php");
include("../../library/globalfunction.php");
@include("../../library/adminpermissionforEnd.php");
include("../../dal/dal_city.php");


if(isset($_POST['btnDelete']) && isset($_POST['City_ID']))
{
	$City_ID=Clean($conn,$_POST['City_ID']);
	
	
	DeleteCity($conn,$City_ID);
	print "<script language=\"JavaScript\">window.location.href=\"../../../Admin/City/List \";</script>";
}

if (isset($_GET['City_ID']) && $_GET['City_ID']!="")
{	
	$City_ID=Clean($conn,$_GET['City_ID']);
	$ret=GetCityDataByCityID($conn,$City_ID);
	$num=mysqli_num_rows($ret);
}
?>
<div class="wrapper">

 <?php require_once('../template/sidebarfileEnD.php'); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       <a href="#"><i class="fa fa-dashboard"></i> Delete City</a>
        
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Delete City</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content"><!-----Section Start---------->
     
      <div class="row"><!-----Row Start------->
        
       			<section style="width:70%; margin-left:10%;">
							<header class="major"><h2>Delete City</h2></header>
									<form method="post" >
                       		
                            <?php
                                if($num>0)
                                {
                                        $row=mysqli_fetch_array($ret);
                            ?>
                             
                              <div class="form-group" style="display:none;">
                                  <label for="City_ID">ID:</label>
                                 <input type="text" name="City_ID" value="<?php echo $row['City_ID']; ?>">
                              </div>
                              <div class="form-group">
                                  <label for="City_Name">Name:</label>
                                   <span style="color:#ccc; font-weight:bold;"><?php echo $row['City_Name']; ?></span>
                              </div>
                              
                             	<br />                               
                                <button type="submit" class="btn btn-danger" name="btnDelete" style="margin-left:30%; " >Delete</button>
                               <a href="../../City/List"> <button  type="button" class="btn btn-default" style="margin-left:1%; ">Back</button></a>
                           <?php } ?>
                          
	</form>
				</section>
				

       
      </div><!-----End Row-------->
     

    </section><!---End Section------->

  </div><!-- /.End content-wrapper -->
  <footer class="main-footer" style="text-align:center;"><strong >Copyright &copy; 2018 by D.P.S.</strong></footer>
  
</div>
<!-- ./wrapper -->


