<?php
session_start();

include("../../library/db.php");
include("../../library/function.php");
include("../../library/globalfunction.php");
@include("../../library/adminpermissionforEnd.php");
include("../../dal/dal_user.php");

if(isset($_POST['btnUpdate']) && isset($_POST['User_ID']))
{
	$User_ID=Clean($conn,$_POST['User_ID']);
	$User_Name=Clean($conn,$_POST['User_Name']);
	$User_Role=Clean($conn,$_POST['User_Role']);
	$User_Email=Clean($conn,$_POST['User_Email']);
	$User_Password=Clean($conn,$_POST['User_Password']);
	$Lastin_Date=GetCurrentDate();
		
	UpdateUser($conn,$User_ID, $User_Name,$User_Role,$User_Email,$User_Password,$Lastin_Date);
	print "<script language=\"JavaScript\">window.location.href=\"../../../Admin/User/List \";</script>";
	
}

if (isset($_GET['User_ID']) && $_GET['User_ID']!="")
{	
	$User_ID=Clean($conn,$_GET['User_ID']);
	$ret=GetUserDataByUserID($conn,$User_ID);
	$num=mysqli_num_rows($ret);
}
?>
<div class="wrapper">

 <?php require_once('../template/sidebarfileEnD.php'); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       <a href="#"><i class="fa fa-dashboard"></i> Dashboard</a>
        
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Dashboard</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content"><!-----Section Start---------->
     
      <div class="row"><!-----Row Start------->
        
       			<section style="width:70%; margin-left:10%;">
							<header class="major"><h2>Edit User</h2></header>
								<form method="post">
                    		
							<?php
                            if($num>0)
                            {
                                    $row=mysqli_fetch_array($ret);
                        ?>
                        	<div class="form-group" style="display:none;">
                                  <label for="User_ID">ID:</label>
                                 <input type="text" name="User_ID" value="<?php echo $row['User_ID']; ?>">
                              </div>
                            <div class="form-group">
                              <label for="User_Name">Name:</label>
                              <input type="text" class="form-control" id="User_Name" name="User_Name" value="<?php echo $row['User_Name'];  ?>">
                            </div>
                            <div class="form-group">
                            <label for="User_Role">Type:</label><br />
                              <select class="form-control" id="User_Role" name="User_Role">
                              	<option><?php echo $row['User_Role'];  ?></option>
                                 <option>Manager</option>
                                <option>Staff</option>
                                
                               </select>
                               </div>
                                <div class="form-group">
                              <label for="User_Email">Email:</label>
                              <input type="email" class="form-control" id="User_Email" name="User_Email" value="<?php echo $row['User_Email'];  ?>">
                            </div>
                           
                              
                           <div class="form-group">
                              <label for="User_Password">Old Password:</label>
                             <span style="color:#ccc; font-weight:bold;"> <?php echo $row['User_Password'];  ?></span>
                            </div>
                           <div class="form-group">
                              <label for="User_Password">New Password:</label>
                              <input type="password" class="form-control" id="User_Password" name="User_Password" value="<?php echo $row['User_Password'];  ?>">
                            </div>
                            
                            
                             <?php } ?> 
                           		<br />
                             <button type="submit" class="btn btn-danger" name="btnUpdate" style="margin-left:30%; " >Edit</button>
                            <!-- <a href="../../User/List"> <button  type="button" class="btn btn-default" name="btnDelete" style="margin-left:1%; ">Back</button></a>-->
                            <a href="../../User/List"> <button  type="button" class="btn btn-default" name="btnDelete" style="margin-left:1%; ">Back</button></a>
                          
                          </form>
				</section>
				

       
      </div><!-----End Row-------->
     

    </section><!---End Section------->

  </div><!-- /.End content-wrapper -->
  <footer class="main-footer" style="text-align:center;"><strong >Copyright &copy; 2018 by D.P.S.</strong></footer>
  
</div>
<!-- ./wrapper -->


