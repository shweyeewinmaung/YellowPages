<?php
session_start();

include("../../library/db.php");
include("../../library/function.php");
include("../../library/globalfunction.php");
include("../../library/adminpermissionforEnd.php");
include("../../dal/dal_customer.php");
include("../../dal/dal_city.php");
include("../../dal/dal_category.php");
include("../../dal/dal_address.php");

if (isset($_GET['Address_ID']) && $_GET['Address_ID']!="")
{	
	$Address_ID=Clean($conn,$_GET['Address_ID']);
	$ret=GetAddressDataByAddressID($conn,$Address_ID);
	$num=mysqli_num_rows($ret);
}
?>
<div class="wrapper">

 <?php require_once('../template/sidebarfileEnD.php'); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       <a href="#"><i class="fa fa-dashboard"></i>Detail Address</a>
        
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Detail Address</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content"><!-----Section Start---------->
     
      <div class="row"><!-----Row Start------->
        
       			<section style="width:70%; margin-left:10%;">
							<header class="major"><h2>Detail Address</h2></header>
								<form method="post">
                    		
							<?php
							
							 $zoom = 17;
                            if($num>0)
                            {
                                    $row=mysqli_fetch_array($ret);
									
									
                        ?>
                        	<table id="address_data" class="table" style="width:90%; background:#ccc; color:#000;font-weight:bold;">
                            	<tbody>
                                <tr>
                                    <td colspan="2">
                                    <div class="form-group"  style="display:none;">
                                      <label for="Address_ID">ID:</label>
                                     <input type="text" name="Address_ID" value="<?php echo $row['Address_ID']; ?>">
                              	   </div>
                                    <div class="form-group">
                                      <label for="Address">Address:</label>
                                      <span><?php echo $row['Address']; ?></span>
                                    </div> 
                                    </td>
                                </tr>
                                <tr>
                                	<td>
                                    <div class="form-group">
                                      <label for="Lat">Lat:</label>
                                      <span><?php echo $lat=$row['Lat']; ?></span>
                                    </div>
                            		</td>
                                	<td>
                                     <div class="form-group">
                                      <label for="Lng">Lng:</label>
                                      <span><?php echo $lng=$row['Lng']; ?></span>
                                    </div>
                                    </td>
                                </tr>
                                <tr>
                                	<td>
                                    	<div class="form-group">
                                           <label for="City">City:</label>
                                            <span><?php echo $row['City_Name']; ?></span>
                                         </div> 
                                    </td>
                                    <td>
                                    	<div class="form-group">
                                        <label for="Category_Name">Type:</label>
                                        <span><?php echo $row['Category_Name']; ?></span>
                                      </div>  
                                    </td>
                                </tr>
                                <tr>
                                	<td>
                                    	<div class="form-group">
                                          <label for="Company_Name">Name:</label>
                                          <span><?php echo $row['Company_Name']; ?></span>
                                        </div>
                                    </td>
                                    <td>
                                    	<div class="form-group">
                                          <label for="Email">Email:</label>
                                          <span><?php echo $row['Email']; ?></span>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                	<td>
                                    	 <div class="form-group">
                                          <label for="Phone">Phone:</label>
                                          <span><?php echo $row['Phone']; ?></span>
                                        </div>
                                    </td>
                                    <td>
                                    	<div class="form-group">
                                          <label for="Website">Website:</label>
                                          <span><?php echo $row['Website']; ?></span>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                	<td>
                                    	 <div class="form-group">
                                           <label for="View">View:</label>
                                            <span><?php echo $row['View']; ?></span>
                                          </div>
                                    </td>
                                    <td>
                                    	<div class="form-group">
                                           <label for="Status">Status:</label>
                                            <span><?php echo $row['Status']; ?></span>
                                          </div>
                                    </td>
                                </tr>
                                <tr>
                                	<td>
                                    	 <div class="form-group">
                                          <label for="Created_Date">Added Date:</label>
                                          <span><?php echo $row['Created_Date']; ?></span>
                                        </div>  
                                    </td>
                                    <td>
                                    	<div class="form-group">
                                              <label for="Lastin_Date">Edit Date:</label>
                                              <span><?php echo $row['Lastin_Date']; ?></span>
                                            </div> 
                                    </td>
                                </tr>
                               	<tr>
                                	<td colspan="2">
                                    	  <div class="form-group" style="margin-left:30%;">
                                       
                                          <span>
                                          <?php 	
										 if($row['Photo']!="0" )
										  {
											  echo "<img src=../".$row['Photo']." alt='' width='200' height='200'>"											?>
                                           <?php
										 }
										 else
										 {
											 echo "No Photo Uploaded for this Address";									  }
										?>
                                        </span>
                                       
                                        </div>  
                                    </td>
                                </tr>
                                <tr>
                                	<td colspan="2">
                                    
                                    </td>
                                </tr>
								
                                
                                </tbody>  
                            </table>
                             
                        	
                        <?php } ?> 
                           		<br />
                            
                           
      						<a href="../../Address/Edit/<?php echo $row['Address_ID']; ?>"><button  type="button" class="btn btn-info"  style="margin-left:1%; ">Edit</button></a> 
                             <a href="../../Address/Remove/<?php echo $row['Address_ID']; ?>"><button  type="button" class="btn btn-danger"  style="margin-left:1%; ">Delete</button></a>
                              <a href="../../Address/List"> <button  type="button" class="btn btn-default"  style="margin-left:1%; ">Back</button></a>                   
                          </form>
                          
                           <div id="map-canvas" /></div>
				</section>
				

       
      </div><!-----End Row-------->
     

    </section><!---End Section------->

  </div><!-- /.End content-wrapper -->
  <footer class="main-footer" style="text-align:center;"><strong >Copyright &copy; 2018 by D.P.S.</strong></footer>
  
</div>
<!-- ./wrapper -->
<style>
label{color:#666;}
#map-canvas { height: 60% ; width:90%;}
</style>
 <script type="text/javascript"
      src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBf3t3q5Lio9CbkTxxwpPxSUCoTCBcmTrU&sensor=false">
    </script>
    <script type="text/javascript">
      function initialize() { 
		
        var mapOptions = {
          center: new google.maps.LatLng(<?php echo $lat.', '.$lng; ?>),
          zoom: <?php echo $zoom; ?>,
		  mapTypeId: google.maps.MapTypeId.ROADMAP
		  };
		 var map = new google.maps.Map(document.getElementById("map-canvas"),
            mapOptions);
		var feature = 
          {
            position: new google.maps.LatLng(<?php echo $lat.', '.$lng; ?>),
            type: 'info'
		  };
		 // Create markers.
         var marker = new google.maps.Marker({
            position: feature.position,
            map: map
		  });
        }
	google.maps.event.addDomListener(window, 'load', initialize);
	</script>
