<?php
session_start();

include("../../library/db.php");
include("../../library/function.php");
include("../../library/globalfunction.php");
@include("../../library/adminpermissionforEnd.php");
include("../../dal/dal_customer.php");

if(isset($_POST['btnUpdate']) && isset($_POST['Customer_ID']))
{
	$Customer_ID=Clean($conn,$_POST['Customer_ID']);
	$Customer_Name=Clean($conn,$_POST['Customer_Name']);
	$Customer_Email=Clean($conn,$_POST['Customer_Email']);
	$Customer_Password=Clean($conn,$_POST['Customer_Password']);
	$Customer_Address=Clean($conn,$_POST['Customer_Address']);
	$Lastin_Date=GetCurrentDate();
		
	UpdateCustomer($conn,$Customer_ID, $Customer_Name,$Customer_Email,$Customer_Password,$Customer_Password,$Lastin_Date);
	print "<script language=\"JavaScript\">window.location.href=\"../../../Admin/Customer/List \";</script>";
	
}

if (isset($_GET['Customer_ID']) && $_GET['Customer_ID']!="")
{	
	$Customer_ID=Clean($conn,$_GET['Customer_ID']);
	$ret=GetCustomerDataByCustomerID($conn,$Customer_ID);
	$num=mysqli_num_rows($ret);
}
?>
<div class="wrapper">

 <?php require_once('../template/sidebarfileEnD.php'); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       <a href="#"><i class="fa fa-dashboard"></i> Edit Customer</a>
        
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Edit Customer</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content"><!-----Section Start---------->
     
      <div class="row"><!-----Row Start------->
        
       			<section style="width:70%; margin-left:10%;">
							<header class="major"><h2>Edit Customer</h2></header>
								<form method="post">
                    		
							<?php
                            if($num>0)
                            {
                                    $row=mysqli_fetch_array($ret);
                        ?>
                        	<div class="form-group"  style="display:none;">
                                  <label for="Customer_ID">ID:</label>
                                 <input type="text" name="Customer_ID" value="<?php echo $row['Customer_ID']; ?>">
                              </div>
                            <div class="form-group">
                              <label for="Customer_Name">Name:</label>
                              <input type="text" class="form-control" id="Customer_Name" name="Customer_Name" value="<?php echo $row['Customer_Name'];  ?>">
                            </div>
                          
                                <div class="form-group">
                              <label for="Customer_Email">Email:</label>
                              <input type="email" class="form-control" id="Customer_Email" name="Customer_Email" value="<?php echo $row['Customer_Email'];  ?>">
                            </div>
                           
                              
                           <div class="form-group">
                              <label for="Customer_Password">Old Password:</label>
                               <span style="color:#ccc; font-weight:bold;"><?php echo $row['Customer_Password'];  ?></span>
                            </div>
                           <div class="form-group">
                              <label for="Customer_Password">New Password:</label>
                              <input type="password" class="form-control" id="Customer_Password" name="Customer_Password" value="<?php echo $row['Customer_Password'];  ?>">
                            </div>
                             <div class="form-group">
                              <label for="Customer_Address">Address:</label><br>
                              <textarea name="Customer_Address" class="form-control" ><?php echo $row['Customer_Address'];  ?></textarea>
                             
                            </div>
                            
                             <?php } ?> 
                           		<br />
                             <button type="submit" class="btn btn-danger" name="btnUpdate" style="margin-left:30%; " >Edit</button>
                            <!-- <a href="../../User/List"> <button  type="button" class="btn btn-default" name="btnDelete" style="margin-left:1%; ">Back</button></a>-->
                            <a href="../../Customer/List"> <button  type="button" class="btn btn-default"  style="margin-left:1%; ">Back</button></a>
                          
                          </form>
				</section>
				

       
      </div><!-----End Row-------->
     

    </section><!---End Section------->

  </div><!-- /.End content-wrapper -->
  <footer class="main-footer" style="text-align:center;"><strong >Copyright &copy; 2018 by D.P.S.</strong></footer>
  
</div>
<!-- ./wrapper -->


