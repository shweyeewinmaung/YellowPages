  <?php  
include("../../library/db.php");

           

if(!empty($_POST["keyword"])) {
$query ="SELECT * FROM tbl_address WHERE Company_Name like '" . $_POST["keyword"] . "%' ORDER BY Company_Name LIMIT 0,10";
$result = runQuery($conn,$query);
if(!empty($result)) {
?>
<ul id="company-list" style="overflow-y:scroll;">
<?php
foreach($result as $CompanyName) {
?>
<li onClick="selectCompanyName('<?php echo $CompanyName["Company_Name"]; ?>');"><?php echo $CompanyName["Company_Name"]; ?></li>
<?php } ?>
</ul>
<?php } } ?>

<?php
function runQuery($conn,$query) {
		$result = mysqli_query($conn,$query);
		while($row=mysqli_fetch_assoc($result)) {
			$resultset[] = $row;
		}		
		if(!empty($resultset))
			return $resultset;
	}
	
	function numRows($conn,$query) {
		$result  = mysqli_query($conn,$query);
		$rowcount = mysqli_num_rows($result);
		return $rowcount;	
	}
?>