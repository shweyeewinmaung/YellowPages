<?php
session_start();

include("../../library/db.php");
include("../../library/function.php");
include("../../library/globalfunction.php");
@include("../../library/adminpermissionforEnd.php");
include("../../dal/dal_customer.php");
include("../../dal/dal_city.php");
include("../../dal/dal_category.php");
include("../../dal/dal_address.php");


if(isset($_POST['btnDelete']) && isset($_POST['Address_ID']))
{
	$Address_ID=Clean($conn,$_POST['Address_ID']);
	
	
	DeleteAddress($conn,$Address_ID);
	print "<script language=\"JavaScript\">window.location.href=\"../../../Admin/Address/List \";</script>";
}

if (isset($_GET['Address_ID']) && $_GET['Address_ID']!="")
{	
	$Address_ID=Clean($conn,$_GET['Address_ID']);
	$ret=GetAddressDataByAddressID($conn,$Address_ID);
	$num=mysqli_num_rows($ret);
}
?>
<div class="wrapper">

 <?php require_once('../template/sidebarfileEnD.php'); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       <a href="#"><i class="fa fa-dashboard"></i> Delete Address</a>
        
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Delete Address</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content"><!-----Section Start---------->
     
      <div class="row"><!-----Row Start------->
        
       			<section style="width:70%; margin-left:10%;">
							<header class="major"><h2>Delete Address</h2></header>
									<form method="post" >
                       		
                            <?php
                                if($num>0)
                                {
                                        $row=mysqli_fetch_array($ret);
                            ?>
                             
                            <table id="address_data" class="table" style="width:90%; background:#ccc; color:#000;font-weight:bold;">
                            	<tbody>
                                <tr>
                                    <td colspan="2">
                                    <div class="form-group"  style="display:none;">
                                      <label for="Address_ID">ID:</label>
                                     <input type="text" name="Address_ID" value="<?php echo $row['Address_ID']; ?>">
                              	   </div>
                                    <div class="form-group">
                                      <label for="Address">Address:</label>
                                      <span><?php echo $row['Address']; ?></span>
                                    </div> 
                                    </td>
                                </tr>
                                <tr>
                                	<td>
                                    <div class="form-group">
                                      <label for="Lat">Lat:</label>
                                      <span><?php echo $row['Lat']; ?></span>
                                    </div>
                            		</td>
                                	<td>
                                     <div class="form-group">
                                      <label for="Lng">Lng:</label>
                                      <span><?php echo $row['Lng']; ?></span>
                                    </div>
                                    </td>
                                </tr>
                                <tr>
                                	<td>
                                    	<div class="form-group">
                                           <label for="City">City:</label>
                                            <span><?php echo $row['City_Name']; ?></span>
                                         </div> 
                                    </td>
                                    <td>
                                    	<div class="form-group">
                                        <label for="Category_Name">Type:</label>
                                        <span><?php echo $row['Category_Name']; ?></span>
                                      </div>  
                                    </td>
                                </tr>
                                <tr>
                                	<td>
                                    	<div class="form-group">
                                          <label for="Company_Name">Name:</label>
                                          <span><?php echo $row['Company_Name']; ?></span>
                                        </div>
                                    </td>
                                    <td>
                                    	<div class="form-group">
                                          <label for="Email">Email:</label>
                                          <span><?php echo $row['Email']; ?></span>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                	<td>
                                    	 <div class="form-group">
                                          <label for="Phone">Phone:</label>
                                          <span><?php echo $row['Phone']; ?></span>
                                        </div>
                                    </td>
                                    <td>
                                    	<div class="form-group">
                                          <label for="Website">Website:</label>
                                          <span><?php echo $row['Website']; ?></span>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                	<td>
                                    	 <div class="form-group">
                                           <label for="View">View:</label>
                                            <span><?php echo $row['View']; ?></span>
                                          </div>
                                    </td>
                                    <td>
                                    	<div class="form-group">
                                           <label for="Status">Status:</label>
                                            <span><?php echo $row['Status']; ?></span>
                                          </div>
                                    </td>
                                </tr>
                                <tr>
                                	<td>
                                    	 <div class="form-group">
                                          <label for="Created_Date">Added Date:</label>
                                          <span><?php echo $row['Created_Date']; ?></span>
                                        </div>  
                                    </td>
                                    <td>
                                    	<div class="form-group">
                                              <label for="Lastin_Date">Edit Date:</label>
                                              <span><?php echo $row['Lastin_Date']; ?></span>
                                            </div> 
                                    </td>
                                </tr>
                                <tr>
                                	<td colspan="2">
                                    	  <div class="form-group">
                                         
                                          <span><img src="../../Photo/<?php echo $row['Photo']; ?>" alt=""  width="200" height="200" /></span>
                                        </div>  
                                    </td>
                                </tr>
                                </tbody>  
                            </table>
                             	<br />                               
                                <button type="submit" class="btn btn-danger" name="btnDelete" style="margin-left:30%; " >Delete</button>
                               <a href="../../Address/List"> <button  type="button" class="btn btn-default" style="margin-left:1%; ">Back</button></a>
                           <?php } ?>
                          
	</form>
				</section>
				

       
      </div><!-----End Row-------->
     

    </section><!---End Section------->

  </div><!-- /.End content-wrapper -->
  <footer class="main-footer" style="text-align:center;"><strong >Copyright &copy; 2018 by D.P.S.</strong></footer>
  
</div>
<!-- ./wrapper -->


