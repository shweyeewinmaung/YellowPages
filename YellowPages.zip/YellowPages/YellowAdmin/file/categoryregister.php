<?php
session_start();

include("../../library/db.php");
include("../../library/function.php");
include("../../library/globalfunction.php");
include("../../library/adminpermission.php");
include("../../dal/dal_category.php");

if (isset($_POST['Category_Name']))
{	
	$Category_ID=AutoID($conn, 'tbl_category','Category_ID','CA-',6);
	$Category_Name=Clean($conn,$_POST['Category_Name']);
	
	$Created_Date=GetCurrentDate();
	$Lastin_Date=GetCurrentDate();
	
	$ret=GetCategoryDataBy_CategoryName($conn,$Category_Name);
		
	$num=mysqli_num_rows($ret);
	if($num>0)
	{
		$_SESSION['Category_Name']="Exist";
	}else{
		InsertCategory($conn,$Category_ID, $Category_Name,$Created_Date,$Lastin_Date);
		$_SESSION['Category_Name']="Success";
	}
}
?>
<div class="wrapper">

 <?php require_once('../template/sidebarfile.php'); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       <a href="#"><i class="fa fa-dashboard"></i> Category Entry</a>
        
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Category Entry</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content"><!-----Section Start---------->
     
      <div class="row"><!-----Row Start------->
        
       			<section style="width:70%; margin-left:10%;">
							<header class="major"><h2>Category Entry</h2></header>
							<form method="post">
                    			<font style="color:red; font-size:18px; line-height:50px;">
							<?php
                                if(@$_SESSION['Category_Name']=="Success"){ echo "Category Name is Added Successfully"; unset($_SESSION['Category_Name']);}
                             ?>
                            <?php 
                                if(@$_SESSION['Category_Name']=="Exist"){ echo "Category Name is Already Exist!"; unset($_SESSION['Category_Name']);}
                            ?></font>
                            <div class="form-group">
                              <label for="Category_Name">Name:</label>
                              <input type="text" class="form-control" id="Category_Name" name="Category_Name" required>
                            </div>
                           
                           
                            <button type="submit" class="btn-primary" name="btnAdd"  >Entry</button>
                          
                          </form>
				</section>
				

       
      </div><!-----End Row-------->
     

    </section><!---End Section------->

  </div><!-- /.End content-wrapper -->
  <footer class="main-footer" style="text-align:center;"><strong >Copyright &copy; 2018 by D.P.S.</strong></footer>
  
</div>
<!-- ./wrapper -->


