  <?php  
include("../../library/db.php");

           

if(!empty($_POST["keyword"])) {
$query ="SELECT * FROM tbl_address WHERE Address like '" . $_POST["keyword"] . "%' ORDER BY Address LIMIT 0,10";
$result = runQuery($conn,$query);
if(!empty($result)) {
?>
<ul id="address-list" style="overflow-y:scroll;">
<?php
foreach($result as $Address) {
?>
<li onClick="selectAddress('<?php echo $Address["Address"]; ?>');"><?php echo $Address["Address"]; ?></li>
<?php } ?>
</ul>
<?php } } ?>

<?php
function runQuery($conn,$query) {
		$result = mysqli_query($conn,$query);
		while($row=mysqli_fetch_assoc($result)) {
			$resultset[] = $row;
		}		
		if(!empty($resultset))
			return $resultset;
	}
	
	function numRows($conn,$query) {
		$result  = mysqli_query($conn,$query);
		$rowcount = mysqli_num_rows($result);
		return $rowcount;	
	}
?>