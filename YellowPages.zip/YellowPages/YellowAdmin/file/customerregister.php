<?php
session_start();

include("../../library/db.php");
include("../../library/function.php");
include("../../library/globalfunction.php");
include("../../library/adminpermission.php");
include("../../dal/dal_customer.php");

if (isset($_POST['Customer_Name']))
{	
	//$Customer_ID=AutoID($conn, 'tbl_customer','Customer_ID','C-',6);
	$Customer_Name=Clean($conn,$_POST['Customer_Name']);
	$Customer_Email=Clean($conn,$_POST['Customer_Email']);
	$Customer_Password=Clean($conn,$_POST['Customer_Password']);
	$Customer_Address=Clean($conn,$_POST['Customer_Address']);
	$Created_Date=GetCurrentDate();
	$Lastin_Date=GetCurrentDate();
	
	$ret=GetCustomerDataBy_CustomerName($conn,$Customer_Name);
		
	$num=mysqli_num_rows($ret);
	if($num>0)
	{
		$_SESSION['Customer_Email']="Exist";
	}else{
		InsertCustomer($conn, $Customer_Name, $Customer_Email, $Customer_Password,$Customer_Address,$Created_Date,$Lastin_Date);
		$_SESSION['Customer_Email']="Success";
	}
}
?>
<div class="wrapper">

 <?php require_once('../template/sidebarfile.php'); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       <a href="#"><i class="fa fa-dashboard"></i> Customer Entry</a>
        
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Customer Entry</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content"><!-----Section Start---------->
     
      <div class="row"><!-----Row Start------->
        
       			<section style="width:70%; margin-left:10%;">
							<header class="major"><h2>Customer Entry</h2></header>
							<form method="post">
                    			<font style="color:red; font-size:18px; line-height:50px;">
							<?php
                                if(@$_SESSION['Customer_Email']=="Success"){ echo "Email Address is Added Successfully"; unset($_SESSION['Customer_Email']);}
                             ?>
                            <?php 
                                if(@$_SESSION['Customer_Email']=="Exist"){ echo " Email Address is Already Exist!"; unset($_SESSION['Customer_Email']);}
                            ?></font>
                            <div class="form-group">
                              <label for="Customer_Name">Name:</label>
                              <input type="text" class="form-control" id="Customer_Name" name="Customer_Name" required>
                            </div>
                           
                              <div class="form-group">
                              <label for="Customer_Email">Email:</label>
                              <input type="email" class="form-control" id="Customer_Email" name="Customer_Email">
                            </div>
                            <div class="form-group">
                              <label for="Customer_Password">Password:</label>
                              <input type="password" class="form-control" id="Customer_Password" name="Customer_Password" required>
                            </div>
                             <div class="form-group">
                              <label for="Customer_Address">Address:</label><br>
                              <textarea name="Customer_Address" class="form-control" ></textarea>
                             
                            </div>
                            <button type="submit" class="btn-primary" name="btnAdd"  >Entry</button>
                          
                          </form>
				</section>
				

       
      </div><!-----End Row-------->
     

    </section><!---End Section------->

  </div><!-- /.End content-wrapper -->
  <footer class="main-footer" style="text-align:center;"><strong >Copyright &copy; 2018 by D.P.S.</strong></footer>
  
</div>
<!-- ./wrapper -->


