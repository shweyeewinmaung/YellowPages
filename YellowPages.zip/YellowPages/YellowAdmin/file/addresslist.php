<?php
session_start();

include("../../library/db.php");
include("../../library/function.php");
include("../../library/globalfunction.php");
include("../../library/adminpermission.php");
include("../../dal/dal_customer.php");
include("../../dal/dal_city.php");
include("../../dal/dal_category.php");
include("../../dal/dal_address.php");
include("../../pager/pager_address.php");

$pageSize=500;

if(isset($_GET['page']))
{
	$currentPageIndex=Clean($conn,$_GET['page']);
}
else
{
	$currentPageIndex=1;
}
$objPager=new pager($pageSize,$currentPageIndex);

if(isset($_GET['btnSearch']) )
{
	$Address=Clean($conn,$_GET['Address']);
	$Category_Name=Clean($conn,$_GET['Category_Name']);
	$Company_Name=Clean($conn,$_GET['Company_Name']);
	$City_Name=Clean($conn,$_GET['City_Name']);
	$sql=$objPager->SearchData_AddressSearch($conn,$_GET['Address'],$_GET['Category_Name'],$_GET['Company_Name'],$_GET['City_Name']);
	$ret=$objPager->Search_Data($conn,$sql);
	$num=mysqli_num_rows($ret);
	
		$A="";
		$CN="";
		$CO="";
		$CI="";
		
		$OrderBy=" ORDER BY Address_ID";
		
		if($Address!="")
		{
			$A="Address LIKE '%$Address%' ";
		}
		
		if($Category_Name!="")
		{
			if($A!="")
			{
				$CN="AND Category_Name LIKE '%$Category_Name%' ";
			}
			elseif($A=="")
			{
				$CN="Category_Name LIKE '%$Category_Name%' ";
			}
		}
		if($Company_Name!="")
		{
			if($A!="" || $CN!="")
			{
				$CO="AND Company_Name LIKE '%$Company_Name%' ";
			}
			elseif($A=="" || $CN=="")
			{
				$CO="Company_Name LIKE '%$Company_Name%' ";
			}
		}
		if($City_Name!="")
		{
			if($A!="" || $CN!="" || $CO!="")
			{
				$CI="AND City_Name LIKE '%$City_Name%' ";
			}
			elseif($A=="" || $CN=="" || $CO=="")
			{
				$CI="City_Name LIKE '%$City_Name%' ";
			}
		}
		$sql2="SELECT * FROM `tbl_address` WHERE $A $CN $CO $CI";
	
	$ret2=mysqli_query($conn,$sql2);
	$num2=mysqli_num_rows($ret2);
	$numberofpage=ceil($num2/$pageSize);
}
if(!isset($_GET['btnSearch']) )
{
	
	$sql=$objPager->SearchData_GetAllAddress($conn);
	$ret=$objPager->Search_Data($conn,$sql);
	$num=mysqli_num_rows($ret);
		
	$sql2="SELECT * FROM `tbl_address` ORDER BY Address_ID DESC ";
	$ret2=mysqli_query($conn,$sql2);
	$num2=mysqli_num_rows($ret2);
	
	$numberofpage=ceil($num2/$pageSize);
	
}

/*****************jump page*********************/
/*if(isset($_GET['btnNumSearch']) )
{
	$numberofpagecount=Clean($conn,$_GET['numberofpagecount']);
	$Address=Clean($conn,$_GET['Address']);
	$Category_Name=Clean($conn,$_GET['Category_Name']);
	$Company_Name=Clean($conn,$_GET['Company_Name']);
	$City_Name=Clean($conn,$_GET['City_Name']);
	?>
	<?php 
	if($Category_Name=="" && $Address=="" && $Company_Name=="" && $City_Name=="")
	{
		//header("location:../../Admin/Address/List?page=$numberofpagecount");
		
       
         print "<script language=\"JavaScript\">window.location.href=\"../../Admin/Address/List?page=$numberofpagecount\";</script>";
	}
	elseif( $Address!="" && $Category_Name!="" && $Company_Name!="" && $City_Name!="")
	{
		//header("location:../../Admin/Address/List?Address=$Address&Category_Name=$Category_Name&Company_Name=$Company_Name&City_Name=$City_Name&btnSearch=Search&page=$numberofpagecount");
		print "<script language=\"JavaScript\">window.location.href=\"../../Admin/Address/List?Address=$Address&Category_Name=$Category_Name&Company_Name=$Company_Name&City_Name=$City_Name&btnSearch=Search&page=$numberofpagecount\";</script>";
	}
	elseif(( $Address=="" && $Category_Name!="" && $Company_Name!="" && $City_Name!="")|| ( $Address=="" && $Category_Name!="" && $Company_Name=="" && $City_Name=="") || ( $Address=="" && $Category_Name!="" && $Company_Name!="" && $City_Name=="")||( $Address=="" && $Category_Name!="" && $Company_Name=="" && $City_Name!="")||( $Address=="" && $Category_Name=="" && $Company_Name!="" && $City_Name=="")||( $Address=="" && $Category_Name=="" && $Company_Name=="" && $City_Name!=""))
	{
		//header("location:../../Admin/Address/List?Address=$Address&Category_Name=$Category_Name&Company_Name=$Company_Name&City_Name=$City_Name&btnSearch=Search&page=$numberofpagecount");
		  print "<script language=\"JavaScript\">window.location.href=\"../../Admin/Address/List?Address=$Address&Category_Name=$Category_Name&Company_Name=$Company_Name&City_Name=$City_Name&btnSearch=Search&page=$numberofpagecount\";</script>";
	}
	elseif(($Address!="" && $Category_Name=="" && $Company_Name=="" && $City_Name=="")||($Address!="" && $Category_Name!="" && $Company_Name=="" && $City_Name=="")||($Address!="" && $Category_Name!="" && $Company_Name!="" && $City_Name=="")||($Address!="" && $Category_Name=="" && $Company_Name=="" && $City_Name!="")||($Address!="" && $Category_Name=="" && $Company_Name!="" && $City_Name=="")||($Address!="" && $Category_Name!="" && $Company_Name=="" && $City_Name!=""))
	{
		//header("location:../../Admin/Address/List?Address=$Address&Category_Name=$Category_Name&Company_Name=$Company_Name&City_Name=$City_Name&btnSearch=Search&page=$numberofpagecount");
		 print "<script language=\"JavaScript\">window.location.href=\"../../Admin/Address/List?Address=$Address&Category_Name=$Category_Name&Company_Name=$Company_Name&City_Name=$City_Name&btnSearch=Search&page=$numberofpagecount\";</script>";
	}
	elseif(($Address!="" && $Category_Name=="" && $Company_Name!="" && $City_Name!="")||($Address!="" && $Category_Name=="" && $Company_Name!="" && $City_Name=="")||($Address!="" && $Category_Name=="" && $Company_Name=="" && $City_Name=="")||($Address!="" && $Category_Name=="" && $Company_Name=="" && $City_Name!="")||($Address=="" && $Category_Name=="" && $Company_Name!="" && $City_Name=="")||($Address=="" && $Category_Name=="" && $Company_Name=="" && $City_Name!=""))
	{
		//header("location:../../Admin/Address/List?Address=$Address&Category_Name=$Category_Name&Company_Name=$Company_Name&City_Name=$City_Name&btnSearch=Search&page=$numberofpagecount");
		 print "<script language=\"JavaScript\">window.location.href=\"../../Admin/Address/List?Address=$Address&Category_Name=$Category_Name&Company_Name=$Company_Name&City_Name=$City_Name&btnSearch=Search&page=$numberofpagecount\";</script>";
	}
	elseif(($Address=="" && $Category_Name!="" && $Company_Name=="" && $City_Name=="")|| ($Address=="" && $Category_Name!="" && $Company_Name=="" && $City_Name!="")||($Address=="" && $Category_Name!="" && $Company_Name!="" && $City_Name=="")||($Address!="" && $Category_Name!="" && $Company_Name=="" && $City_Name=="")||($Address!="" && $Category_Name!="" && $Company_Name=="" && $City_Name!="")||($Address!="" && $Category_Name!="" && $Company_Name!="" && $City_Name==""))
	{
		//header("location:../../Admin/Address/List?Address=$Address&Category_Name=$Category_Name&Company_Name=$Company_Name&City_Name=$City_Name&btnSearch=Search&page=$numberofpagecount");
		 print "<script language=\"JavaScript\">window.location.href=\"../../Admin/Address/List?Address=$Address&Category_Name=$Category_Name&Company_Name=$Company_Name&City_Name=$City_Name&btnSearch=Search&page=$numberofpagecount\";</script>";
	}
	elseif(($Address!="" && $Category_Name!="" && $Company_Name=="" && $City_Name!="")||($Address!="" && $Category_Name!="" && $Company_Name=="" && $City_Name=="")||($Address=="" && $Category_Name!="" && $Company_Name=="" && $City_Name!="")||($Address!="" && $Category_Name=="" && $Company_Name=="" && $City_Name=="")||($Address=="" && $Category_Name=="" && $Company_Name=="" && $City_Name!="")||($Address!="" && $Category_Name!="" && $Company_Name=="" && $City_Name=="")||($Address=="" && $Category_Name!="" && $Company_Name=="" && $City_Name==""))
	{
		//header("location:../../Admin/Address/List?Address=$Address&Category_Name=$Category_Name&Company_Name=$Company_Name&City_Name=$City_Name&btnSearch=Search&page=$numberofpagecount");
		 print "<script language=\"JavaScript\">window.location.href=\"../../Admin/Address/List?Address=$Address&Category_Name=$Category_Name&Company_Name=$Company_Name&City_Name=$City_Name&btnSearch=Search&page=$numberofpagecount\";</script>";
	}
	elseif(($Address=="" && $Category_Name=="" && $Company_Name!="" && $City_Name=="")||($Address=="" && $Category_Name=="" && $Company_Name!="" && $City_Name!="")||($Address=="" && $Category_Name!="" && $Company_Name!="" && $City_Name!="")||($Address!="" && $Category_Name=="" && $Company_Name!="" && $City_Name=="")||($Address!="" && $Category_Name=="" && $Company_Name!="" && $City_Name!="")||($Address=="" && $Category_Name!="" && $Company_Name!="" && $City_Name=="")||($Address!="" && $Category_Name!="" && $Company_Name!="" && $City_Name==""))
	{
		//header("location:../../Admin/Address/List?Address=$Address&Category_Name=$Category_Name&Company_Name=$Company_Name&City_Name=$City_Name&btnSearch=Search&page=$numberofpagecount");
		 print "<script language=\"JavaScript\">window.location.href=\"../../Admin/Address/List?Address=$Address&Category_Name=$Category_Name&Company_Name=$Company_Name&City_Name=$City_Name&btnSearch=Search&page=$numberofpagecount\";</script>";
	}
	elseif(($Address!="" && $Category_Name!="" && $Company_Name!="" && $City_Name=="")||($Address=="" && $Category_Name=="" && $Company_Name!="" && $City_Name=="")||($Address=="" && $Category_Name!="" && $Company_Name!="" && $City_Name=="")||($Address!="" && $Category_Name=="" && $Company_Name!="" && $City_Name=="")||($Address=="" && $Category_Name!="" && $Company_Name=="" && $City_Name=="")||($Address!="" && $Category_Name!="" && $Company_Name!="" && $City_Name=="")||($Address!="" && $Category_Name=="" && $Company_Name=="" && $City_Name==""))
	{
		//header("location:../../Admin/Address/List?Address=$Address&Category_Name=$Category_Name&Company_Name=$Company_Name&City_Name=$City_Name&btnSearch=Search&page=$numberofpagecount");
		 print "<script language=\"JavaScript\">window.location.href=\"../../Admin/Address/List?Address=$Address&Category_Name=$Category_Name&Company_Name=$Company_Name&City_Name=$City_Name&btnSearch=Search&page=$numberofpagecount\";</script>";
	}
	elseif(($Address=="" && $Category_Name=="" && $Company_Name=="" && $City_Name!="")||($Address=="" && $Category_Name=="" && $Company_Name!="" && $City_Name!="")||($Address=="" && $Category_Name!="" && $Company_Name!="" && $City_Name!="")||($Address!="" && $Category_Name=="" && $Company_Name!="" && $City_Name!="")||($Address!="" && $Category_Name!="" && $Company_Name=="" && $City_Name!="")||($Address!="" && $Category_Name=="" && $Company_Name=="" && $City_Name!="")||($Address=="" && $Category_Name!="" && $Company_Name=="" && $City_Name!=""))
	{
		//header("location:../../Admin/Address/List?Address=$Address&Category_Name=$Category_Name&Company_Name=$Company_Name&City_Name=$City_Name&btnSearch=&page=$numberofpagecount");
		 print "<script language=\"JavaScript\">window.location.href=\"../../Admin/Address/List?Address=$Address&Category_Name=$Category_Name&Company_Name=$Company_Name&City_Name=$City_Name&btnSearch=Search&page=$numberofpagecount\";</script>";
	}
}
*/
?>
<div class="wrapper">

 <?php require_once('../template/sidebarfile.php'); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       <a href="#"><i class="fa fa-dashboard"></i> Address List</a>
        
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Address List</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content"><!-----Section Start---------->
     
      <div class="row"><!-----Row Start------->
        
       			<section >
							<header class="major"><h2>Address List</h2></header>
                            <form method="get" class="formsearch">
                            <div class="table-responsive">
                                    <table class="table" style="width:95%; " >
                                         <tbody>
                                         <tr>
                                            <td style="border-top:none;">
                                            	<label for="Address">Address:</label>
                                                <div class="form-group ">
                                                    <div class="input-group">
                                                    	
                                                        <input class="form-control" id="Address"  placeholder="Address"  type="text" name="Address" value="<?php if(isset($_GET['showAll'])){ echo "";}else{ echo @htmlspecialchars($_GET['Address']);} ?>"/>
                                                       
                                                        <div class="input-group-addon"><span class="glyphicon fa fa-map-marker"></span></div>
                                                   </div>
                                               </div>
                                            </td>
                                            
                                              <td style="border-top:none;">
                                               <label for="Category_Name">Type:</label>
                                               <div class="form-group">
                                               
                                                <select class="form-control" id="Category_Name" name="Category_Name"  >
                                                     <option ><?php if(isset($_GET['showAll'])){ echo "";}else{ echo @htmlspecialchars($_GET['Category_Name']);} ?></option>
                                                     <option></option>
													 <?php	
                                                        $retCA=getAllCategoryData($conn);
                                                        while($rowCA=mysqli_fetch_array($retCA))
                                                        {	echo "<option>" . $rowCA['Category_Name'] . "</option>";	}
                                                    ?>
                                                </select>
                                              </div>    
                                              </td>
                                               <td style="border-top:none;">
                                            	<label for="Company">Company:</label>
                                                <div class="form-group ">
                                                    <div class="input-group">
                                                    	
                                                        <input class="form-control" id="Company_Name"  placeholder="Company"  type="text" name="Company_Name" value="<?php if(isset($_GET['showAll'])){ echo "";}else{ echo @htmlspecialchars($_GET['Company_Name']);} ?>" />
                                                       
                                                       
                                                   </div>
                                               </div>
                                            </td>
                                            <td style="border-top:none;">
                                               <label for="City_Name">City:</label>
                                               <div class="form-group">
                                               
                                                <select class="form-control" id="City_Name" name="City_Name"  >
                                                     <option ><?php if(isset($_GET['showAll'])){ echo "";}else{ echo @htmlspecialchars($_GET['City_Name']);} ?></option>
                                                     <option></option>
													 <?php	
                                                        $retCI=getAllCityData($conn);
                                                        while($rowCI=mysqli_fetch_array($retCI))
                                                        {	echo "<option>" . $rowCI['City_Name'] . "</option>";	}
                                                    ?>
                                                </select>
                                              </div>    
                                              </td>
                                              <td style="border-top:none;"> <button type="submit" name="showAll" class="btn btn-info" style="width:70%">All</button><p style="margin-bottom:10px;"></p><button type="submit" class="btn btn-info"  name="btnSearch" style="width:70%">Search</button></td>
                                              </tr>
                                            <!--tr>
                                              <td style="border-top:none;">
                                               <label for="numberofpagecount">Page:</label>
                                            <div class="form-group"  style="width:30%;">
                                            	
                                                <select class="form-control" id="numberofpagecount" name="numberofpagecount" >
                                                  <option><?php echo $currentPageIndex ;?></option>
                                                   <?php 
                                                    for($p=1;$p<=$numberofpage;$p++)
                                                    {echo "<option>".$p ."</option>";}
                                                  ?>
                                                </select>
                                              </div>
                                            
                                            </td>
                                            <td style="border-top:none;">  <label for="btnNumSearch" style="margin-left:-60%">Jump to Page</label><br />
                                            <button type="submit" class="btn btn-info"  name="btnNumSearch" style="width:50%;margin-left:-60%;">Go Pages</button></td> 
                                           
                                         </tr-->
                                         </tbody>
                                     </table>
                                     </div>
                            </form>
                            
        <p style="padding:5px 0px;color:#fff; font-weight:bold; font-size:18px;">Search Results :<?php echo $num2; ?> Entries</p>     
  <div class="table-responsive">
			<table id="address_data" class="table table-striped table-bordered" style="width:100%; background:#ccc;">  
             <?php if(@$num>0)
						{  ?>  
               <thead  style="background:#007cc7;color:#fff; font-weight:bold;">
                <tr>
                    <th>No</th>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Lat</th>
                    <th>Lng</th>
                    <th>City</th>
                    <th>Type</th>
                    <th>Company</th>
                    
                    <th>View</th>
                    <th>Created Date</th>
                    <th>Lastin Update</th>
                    <th>Detail</th>
                    <th>Edit</th>
                    <th>Delete</th>
                </tr>
                </thead>
                <tbody>
                	<?php
							$u=(($currentPageIndex*$pageSize)+1)-$pageSize; 
							while($row=mysqli_fetch_array($ret))
							{
								?>
                <tr>
                    <th><?php echo $u; ?></th>
                    <th><?php echo $row['Address_ID']; ?></th>
                    <th><?php echo $row['Address']; ?></th>
                    <th><?php echo $row['Lat']; ?></th>
                    <th><?php echo $row['Lng']; ?></th>
                    <th><?php echo $row['City_Name']; ?></th>
                    <th><?php echo $row['Category_Name']; ?></th>
                    <th><?php echo $row['Company_Name']; ?></th>
                   
                                       
                    <th><?php echo $row['View']; ?></th>
                    <th><?php echo $row['Created_Date']; ?></th>
                    <th><?php echo $row['Lastin_Date']; ?></th>
                    <th><a href="../Address/Detail/<?php echo $row['Address_ID']; ?>">Detail</a></th>
                    <th><a href="../Address/Edit/<?php echo $row['Address_ID']; ?>"><img src="../../YellowAdmin/img/wrench-screwdriver.png"  width="20" height="20"/></a></th>
                    <th><a href="../Address/Remove/<?php echo $row['Address_ID']; ?>">
    <img src="../../YellowAdmin/img/cross-script.png"  width="20" height="20" /></a></th>
                </tr>
               <?php $u=$u+1;  } 
			   
			   }
					 else
					{
						?>
                        	<center>Not available!</center>
                        <?php
					}
			   ?> 
                     </table>
                     </div>
                     <span id="pager" style="padding-left:30%;"> 
                       <?php
                	@$objPager->Generate_Pager($str,$conn);
?>
                </span>
       		
				</section>
				

       
      </div><!-----End Row-------->
     

    </section><!---End Section------->

  </div><!-- /.End content-wrapper -->
  <footer class="main-footer" style="text-align:center;"><strong >Copyright &copy; 2018 by D.P.S.</strong></footer>
  
</div>

<!-- ./wrapper -->

  <!-- REQUIRED JS SCRIPTS -->

  <style>
 
  section{ width:100%!important; margin-left:1%!important;}
 
 
  

#address-list{float:left;list-style:none;margin-top:10%;padding:0;width:100%;position: absolute; border:1px solid#000;}
#address-list li{padding: 10px; background: #fff; border-bottom: #666; border-radius:1px;}
#address-list li:hover{background:#ccc;cursor: pointer;}

#company-list{float:left;list-style:none;margin-top:10%;padding:0;width:100%;position: absolute; border:1px solid#000;}
#company-list li{padding: 10px; background: #fff; border-bottom: #666; border-radius:1px;}
#company-list li:hover{background:#ccc;cursor: pointer;}
.ac_results{width:20%!important;}
.ac_results li{padding:7px 7px!important; font-family:Verdana, Geneva, sans-serif!important; background:#CCC; border-bottom:1px solid#fafafa; font-size:12px!important;}
.input-group-addon{color:#ff0000; background-color: #ffffff; width:10%; border:2px solid#ccc;}

</style>
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<script src="https://code.jquery.com/jquery-2.1.1.min.js" type="text/javascript"></script>
<!--script>
$(document).ready(function(){
	$("#search-box").keyup(function(){
		$.ajax({
		type: "POST",
		url: "../../YellowAdmin/file/readAddress.php",
		data:'keyword='+$(this).val(),
		beforeSend: function(){
			$("#search-box").css("background","#FFF url(../../YellowAdmin/img/LoaderIcon.gif) no-repeat 165px");
		},
		success: function(data){
			$("#suggesstion-box").show();
			$("#suggesstion-box").html(data);
			$("#search-box").css("background","#FFF");
		}
		});
	});
});

function selectAddress(val) {
$("#search-box").val(val);
$("#suggesstion-box").hide();
}
</script

<script>
$(document).ready(function(){
	$("#search-box2").keyup(function(){
		$.ajax({
		type: "POST",
		url: "../../YellowAdmin/file/readCompany.php",
		data:'keyword='+$(this).val(),
		beforeSend: function(){
			$("#search-box2").css("background","#FFF url(../../YellowAdmin/img/LoaderIcon.gif) no-repeat 165px");
		},
		success: function(data){
			$("#suggesstion-box2").show();
			$("#suggesstion-box2").html(data);
			$("#search-box2").css("background","#FFF");
		}
		});
	});
});

function selectCompanyName(val) {
$("#search-box2").val(val);
$("#suggesstion-box2").hide();
}
</script>-->
<link rel="stylesheet" type="text/css" href="../../YellowAdmin/file/css/jquery.ajaxcomplete.css" />
<script type="text/javascript" src="../../YellowAdmin/file/js/jquery.js"></script>
<script type="text/javascript" src="../../YellowAdmin/file/js/jquery.ajaxcomplete.js"></script>
<script>
$(document).ready(function(){
 $("#Address").autocomplete("../../YellowAdmin/file/ajaxcompleteaddress.php", {
		selectFirst: true
	});
});
</script>
<script>
$(document).ready(function(){
 $("#Company_Name").autocomplete("../../YellowAdmin/file/ajaxcompletecompany.php", {
		selectFirst: true
	});
});
</script>
