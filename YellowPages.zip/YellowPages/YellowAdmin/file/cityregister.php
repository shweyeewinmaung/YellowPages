<?php
session_start();

include("../../library/db.php");
include("../../library/function.php");
include("../../library/globalfunction.php");
include("../../library/adminpermission.php");
include("../../dal/dal_city.php");

if (isset($_POST['City_Name']))
{	
	$City_ID=AutoID($conn, 'tbl_city','City_ID','CI-',6);
	$City_Name=Clean($conn,$_POST['City_Name']);
	
	$Created_Date=GetCurrentDate();
	$Lastin_Date=GetCurrentDate();
	
	$ret=GetCityDataBy_CityName($conn,$City_Name);
		
	$num=mysqli_num_rows($ret);
	if($num>0)
	{
		$_SESSION['City_Name']="Exist";
	}else{
		InsertCity($conn,$City_ID, $City_Name,$Created_Date,$Lastin_Date);
		$_SESSION['City_Name']="Success";
	}
}
?>
<div class="wrapper">

 <?php require_once('../template/sidebarfile.php'); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       <a href="#"><i class="fa fa-dashboard"></i> City Entry</a>
        
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">City Entry</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content"><!-----Section Start---------->
     
      <div class="row"><!-----Row Start------->
        
       			<section style="width:70%; margin-left:10%;">
							<header class="major"><h2>City Entry</h2></header>
							<form method="post">
                    			<font style="color:red; font-size:18px; line-height:50px;">
							<?php
                                if(@$_SESSION['City_Name']=="Success"){ echo "City Name is Added Successfully"; unset($_SESSION['City_Name']);}
                             ?>
                            <?php 
                                if(@$_SESSION['City_Name']=="Exist"){ echo "City Name is Already Exist!"; unset($_SESSION['City_Name']);}
                            ?></font>
                            <div class="form-group">
                              <label for="City_Name">Name:</label>
                              <input type="text" class="form-control" id="City_Name" name="City_Name" required>
                            </div>
                           
                           
                            <button type="submit" class="btn-primary" name="btnAdd"  >Entry</button>
                          
                          </form>
				</section>
				

       
      </div><!-----End Row-------->
     

    </section><!---End Section------->

  </div><!-- /.End content-wrapper -->
  <footer class="main-footer" style="text-align:center;"><strong >Copyright &copy; 2018 by D.P.S.</strong></footer>
  
</div>
<!-- ./wrapper -->


