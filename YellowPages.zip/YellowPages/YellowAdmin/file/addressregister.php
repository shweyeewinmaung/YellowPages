<?php
session_start();

include("../../library/db.php");
include("../../library/function.php");
include("../../library/globalfunction.php");
include("../../library/adminpermission.php");
include("../../dal/dal_category.php");
include("../../dal/dal_city.php");
include("../../dal/dal_customer.php");
include("../../dal/dal_address.php");

if (isset($_POST['Address']))
{	
	$Address=Clean($conn,$_POST['Address']);
	$Lat=Clean($conn,$_POST['Lat']);
	$Lng=Clean($conn,$_POST['Lng']);
	$City_Name=Clean($conn,$_POST['City_Name']);
	$Category_Name=Clean($conn,$_POST['Category_Name']);
	$Company_Name=Clean($conn,$_POST['Company_Name']);
	$Email=Clean($conn,$_POST['Email']);
	$Phone=Clean($conn,$_POST['Phone']);
	$Website=Clean($conn,$_POST['Website']);
	$View="0";
	$Status=Clean($conn,$_POST['Status']);
	
	/***************************************************************/						
		//For "ItemImage"
		// get the original filename
		$image = $_FILES['Photo']['name'];
			
		// image storing folder, make sure you indicate the right path
		$folder = "../../Photo/"; 
		
		// image checking if exist or the input field is not empty
		if($image) 
		{ 
		  // creating a filename
		  $filename = $folder . $Company_Name . "_" . $image; 		  
		  // uploading image file to specified folder
		  $copied = copy($_FILES['Photo']['tmp_name'], $filename); 
		  
		  // checking if upload succesfull
		  if (!$copied) 
		  { 			  
			exit("Problem occured. Cannot Upload Item Image.");
		  }
		}
		/***************************************************************/	
	
	$Created_Date=GetCurrentDate();
	$Lastin_Date=GetCurrentDate();
	
	$ret=GetAddressDataBy_Address($conn,$Address);
		
	$num=mysqli_num_rows($ret);
	if($num>0)
	{
		$_SESSION['Address']="Exist";
	}else{
		InsertAddress($conn,$Address,$Lat,$Lng,$City_Name,$Category_Name,$Company_Name,$Email,$Phone,$Website,$View,$Status,$filename,$Created_Date,$Lastin_Date);
		$_SESSION['Address']="Success";
	}
}
?>
<div class="wrapper">

 <?php require_once('../template/sidebarfile.php'); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       <a href="#"><i class="fa fa-dashboard"></i> Address Entry</a>
        
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Address Entry</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content"><!-----Section Start---------->
     
      <div class="row"><!-----Row Start------->
        
       			<section style="width:70%; margin-left:10%;">
							<header class="major"><h2>Address Entry</h2></header>
							<form method="post" enctype="multipart/form-data">
                    			<font style="color:red; font-size:18px; line-height:50px;">
							<?php
                                if(@$_SESSION['Category_Name']=="Success"){ echo "Category Name is Added Successfully"; unset($_SESSION['Category_Name']);}
                             ?>
                            <?php 
                               if(@$_SESSION['Category_Name']=="Exist"){ echo "Category Name is Already Exist!"; unset($_SESSION['Category_Name']);}
                            ?></font>
                            
                             <div class="form-group">
                              <label for="Address">Address:</label>
                              <textarea class="form-control" rows="5" id="Address" name="Address"></textarea>
                            </div> 
                            <div class="form-group">
                              <label for="Lat">Lat:</label>
                              <input type="text" class="form-control" id="Lat" name="Lat">
                            </div>
                             <div class="form-group">
                              <label for="Lng">Lng:</label>
                              <input type="text" class="form-control" id="Lng" name="Lng">
                            </div>
                           <div class="form-group">
                           <label for="City">City:</label>
                            <select class="form-control" id="City_Name" name="City_Name">
                                 <?php	
								 	$retC=getAllCityData($conn);
									while($rowC=mysqli_fetch_array($retC))
									{	echo "<option>" . $rowC['City_Name'] . "</option>";	}
								?>
                            </select>
                          </div>    
                            <div class="form-group">
                            <label for="Category_Name">Type:</label>
                            <select class="form-control" id="Category_Name" name="Category_Name">
                                 <?php	
								 	$retCA=getAllCategoryData($conn);
									while($rowCA=mysqli_fetch_array($retCA))
									{	echo "<option>" . $rowCA['Category_Name'] . "</option>";	}
								?>
                            </select>
                          </div>    
                                                        
                            <div class="form-group">
                              <label for="Company_Name">Name:</label>
                              <input type="text" class="form-control" id="Company_Name" name="Company_Name">
                            </div>
                            <div class="form-group">
                              <label for="Email">Email:</label>
                              <input type="email" class="form-control" id="Email" name="Email" >
                            </div>
                            <div class="form-group">
                              <label for="Phone">Phone:</label>
                              <input type="text" class="form-control" id="Phone" name="Phone">
                            </div>
                            <div class="form-group">
                              <label for="Website">Website:</label>
                              <input type="text" class="form-control" id="Website" name="Website">
                            </div>
                           <div class="form-group">
                            <select class="form-control" id="Status" name="Status">
                                 <option>Success</option>
                                 <option>Pending</option>
                            </select>
                          </div>
                          <div class="form-group">
                              <label for="Photo">Photo:</label>
                              <input type="file" name="Photo"  id="Photo"/>
                            </div>  
                           
                            <button type="submit" class="btn-primary" name="btnAdd"  >Entry</button>
                          
                          </form>
				</section>
				

       
      </div><!-----End Row-------->
     

    </section><!---End Section------->

  </div><!-- /.End content-wrapper -->
  <footer class="main-footer" style="text-align:center;"><strong >Copyright &copy; 2018 by D.P.S.</strong></footer>
  
</div>
<!-- ./wrapper -->


