<?php
session_start();

include("../../library/db.php");
include("../../library/function.php");
include("../../library/globalfunction.php");
include("../../library/adminpermission.php");
include("../../dal/dal_user.php");

if (isset($_POST['User_Name']))
{	
	$User_ID=AutoID($conn, 'tbl_user','User_ID','U-',6);
	$User_Name=Clean($conn,$_POST['User_Name']);
	$User_Email=Clean($conn,$_POST['User_Email']);
	$User_Password=Clean($conn,$_POST['User_Password']);
	$User_Role=Clean($conn,$_POST['User_Role']);
	$Created_Date=GetCurrentDate();
	$Lastin_Date=GetCurrentDate();
	
	$ret=GetUserDataBy_UserName($conn,$User_Name);
		
	$num=mysqli_num_rows($ret);
	if($num>0)
	{
		$_SESSION['User_Name']="Exist";
	}else{
		InsertUser($conn,$User_ID, $User_Name, $User_Email, $User_Password,$User_Role,$Created_Date,$Lastin_Date);
		$_SESSION['User_Name']="Success";
	}
}
?>
<div class="wrapper">

 <?php require_once('../template/sidebarfile.php'); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       <a href="#"><i class="fa fa-dashboard"></i> Dashboard</a>
        
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Dashboard</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content"><!-----Section Start---------->
     
      <div class="row"><!-----Row Start------->
        
       			<section style="width:70%; margin-left:10%;">
							<header class="major"><h2>Add User</h2></header>
							<form method="post">
                    			<font style="color:red; font-size:18px; line-height:50px;">
							<?php
                                if(@$_SESSION['User_Name']=="Success"){ echo "Name is Added"; unset($_SESSION['User_Name']);}
                             ?>
                            <?php 
                                if(@$_SESSION['User_Name']=="Exist"){ echo "Already Exist!"; unset($_SESSION['User_Name']);}
                            ?></font>
                            <div class="form-group">
                              <label for="User_Name">Name:</label>
                              <input type="text" class="form-control" id="User_Name" name="User_Name" required>
                            </div>
                            <div class="form-group">
                            <label for="User_Role">Role:</label><br />
                              <select class="form-control" id="User_Role" name="User_Role">
                                <option>Manager</option>
                                <option>Staff</option>
                               </select>
                              </div>
                              <div class="form-group">
                              <label for="User_Email">Email:</label>
                              <input type="email" class="form-control" id="User_Email" name="User_Email">
                            </div>
                            <div class="form-group">
                              <label for="User_Password">Password:</label>
                              <input type="password" class="form-control" id="User_Password" name="User_Password" required>
                            </div>
                            
                            <button type="submit" class="btn-primary" name="btnAdd"  >Entry</button>
                          
                          </form>
				</section>
				

       
      </div><!-----End Row-------->
     

    </section><!---End Section------->

  </div><!-- /.End content-wrapper -->
  <footer class="main-footer" style="text-align:center;"><strong >Copyright &copy; 2018 by D.P.S.</strong></footer>
  
</div>
<!-- ./wrapper -->


