<?php
session_start();

include("../../library/db.php");
include("../../library/function.php");
include("../../library/globalfunction.php");
include("../../library/adminpermission.php");
include("../../pager/pager_category.php");

$pageSize=1;

if(isset($_GET['page']))
{
	$currentPageIndex=Clean($conn,$_GET['page']);
}
else
{
	$currentPageIndex=1;
}
$objPager=new pager($pageSize,$currentPageIndex);

if(isset($_GET['btnSearch']) )
{
	$Category_Name=Clean($conn,$_GET['Category_Name']);
	$sql=$objPager->SearchData_CategorySearch($conn,$_GET['Category_Name']);
	$ret=$objPager->Search_Data($conn,$sql);
	$num=mysqli_num_rows($ret);
	
	$N="";
	$OrderBy=" ORDER BY Category_ID";
	if($Category_Name!="")
	{
	$N="Category_Name LIKE '%$Category_Name%' ";
	}
	$sql2="SELECT * FROM `tbl_category` WHERE $N ";
	
	$ret2=mysqli_query($conn,$sql2);
	$num2=mysqli_num_rows($ret2);
	$numberofpage=ceil($num2/$pageSize);
}
if(!isset($_GET['btnSearch']) )
{
	@$Category_Name=Clean($conn,$_GET['Category_Name']);
	
	$sql=$objPager->SearchData_GetAllCategory($conn);
	$ret=$objPager->Search_Data($conn,$sql);
	$num=mysqli_num_rows($ret);
	
	$sql2="SELECT * FROM `tbl_category` ORDER BY Category_ID DESC ";
	$ret2=mysqli_query($conn,$sql2);
	$num2=mysqli_num_rows($ret2);
	
	$numberofpage=ceil($num2/$pageSize);
}
if(isset($_GET['btnNumSearch']) )
{
	$numberofpagecount=Clean($conn,$_GET['numberofpagecount']);
	$Category_Name=Clean($conn,$_GET['Category_Name']);
	if($Category_Name=="")
	{
		
		header("location:../../Admin/Category/List?page=$numberofpagecount");
	}
	else
	{
		header("location:../../Admin/Category/List?Category_Name=$Category_Name&btnSearch=&page=$numberofpagecount");
	}
	//header("location:$_SERVER[PHP_SELF]?Category_Name=$Category_Name&page=$numberofpage");
	
}

?>
<div class="wrapper">

 <?php require_once('../template/sidebarfile.php'); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       <a href="#"><i class="fa fa-dashboard"></i> Category List</a>
        
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Category List</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content"><!-----Section Start---------->
     
      <div class="row"><!-----Row Start------->
        
       			<section >
							<header class="major"><h2>Category List</h2></header>
						
               
<form method="get" class="formsearch">
        <table class="table" style="width:60%; " >
        	 <tbody>
             <tr>
             	<td style="border-top:none;">
                    <div class="form-group ">
                        <div class="input-group">
                            <input class="form-control" id="search-box"  placeholder="Category Name"  type="text" name="Category_Name" value="<?php echo @htmlspecialchars($_GET['Category_Name']); ?>"/>
                            <div id="suggesstion-box"></div>
                            <div class="input-group-addon"><span class="glyphicon fa fa-map-marker"></span></div>
                       </div>
                   </div>
                </td>
                <td style="border-top:none;"> <button type="submit" class="btn btn-info"  name="btnSearch" style="width:60%">Search</button></td>
             	  <td style="border-top:none;">
                <div class="form-group">
                 	<select class="form-control" id="numberofpagecount" name="numberofpagecount">
                      <option><?php echo $currentPageIndex ;?></option>
                       <?php 
					  	for($p=1;$p<=$numberofpage;$p++)
						{echo "<option>".$p ."</option>";}
					  ?>
                    </select>
                  </div>
                
             	</td>
                <td style="border-top:none;"> <button type="submit" class="btn btn-info"  name="btnNumSearch" style="width:60%">Search</button></td> 
             </tr>
             </tbody>
         </table>
</form>
       
			<table id="user_data" class="table table-striped table-bordered" style="width:90%; background:#ccc;">  
                        <?php
					if(@$num>0)
					{
						?>
                         <thead  style="background:#007cc7;color:#fff; font-weight:bold;">
                <tr>
                    <th>No</th>
                    <th>Name</th>
                  
                    <th>Created Date</th>
                    <th>Lastin Update</th>
                    <th>Edit</th>
                    <th>Delete</th>
                </tr>
                </thead>
                <tbody>
                 <?php  $u=(($currentPageIndex*$pageSize)+1)-$pageSize;
				  	while($row=mysqli_fetch_array($ret)){	?>  
                <tr>
                    <th><?php echo $u; ?></th>
                    <th><?php echo $row['Category_Name']; ?></th>
                   
                    <th><?php echo $row['Created_Date']; ?></th>
                    <th><?php echo $row['Lastin_Date']; ?></th>
                    <th><a href="../Category/Edit/<?php echo $row['Category_ID']; ?>"><img src="../../YellowAdmin/img/wrench-screwdriver.png"  width="20" height="20"/></a></th>
                    <th><a href="../Category/Remove/<?php echo $row['Category_ID']; ?>">
    <img src="../../YellowAdmin/img/cross-script.png"  width="20" height="20" /></a></th>
                </tr>
               <?php $u=$u+1;  } 
			   
			   }
					 else
					{
						?>
                        	<center>Not available!</center>
                        <?php
					}
			   ?> 
                     </table>
                     
                     <span id="pager" style="padding-left:30%;"> 
                       <?php
                	@$objPager->Generate_Pager($str,$conn);
                ?>
                </span>
				</section>
				

       
      </div><!-----End Row-------->
     

    </section><!---End Section------->

  </div><!-- /.End content-wrapper -->
  <footer class="main-footer" style="text-align:center;"><strong >Copyright &copy; 2018 by D.P.S.</strong></footer>
  
</div>

<!-- ./wrapper -->

  <!-- REQUIRED JS SCRIPTS -->

  <style>
 
  section{ width:100%!important; margin-left:1%!important;}
 
 
  

#category-list{float:left;list-style:none;margin-top:10%;padding:0;width:100%;position: absolute; border:1px solid#000;}
#category-list li{padding: 10px; background: #fff; border-bottom: #666; border-radius:1px;}
#category-list li:hover{background:#ccc;cursor: pointer;}

.input-group-addon{color:#ff0000; background-color: #ffffff; width:10%; border:2px solid#ccc;}

</style>
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<script src="https://code.jquery.com/jquery-2.1.1.min.js" type="text/javascript"></script>
<script>
$(document).ready(function(){
	$("#search-box").keyup(function(){
		$.ajax({
		type: "POST",
		url: "../../YellowAdmin/file/readCategory.php",
		data:'keyword='+$(this).val(),
		beforeSend: function(){
			$("#search-box").css("background","#FFF url(../../YellowAdmin/img/LoaderIcon.gif) no-repeat 165px");
		},
		success: function(data){
			$("#suggesstion-box").show();
			$("#suggesstion-box").html(data);
			$("#search-box").css("background","#FFF");
		}
		});
	});
});

function selectCategory(val) {
$("#search-box").val(val);
$("#suggesstion-box").hide();
}
</script>