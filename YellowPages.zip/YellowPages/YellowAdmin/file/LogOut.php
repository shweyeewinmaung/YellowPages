<?php
session_start();
session_destroy();
//header("Location:../LogIn");
//header("Location:LogIn");
print "<script language=\"JavaScript\">window.location.href=\"LogIn\";</script>";
?>