<?php
session_start();

include("../../library/db.php");
include("../../library/function.php");
include("../../library/globalfunction.php");
@include("../../library/adminpermissionforEnd.php");
include("../../dal/dal_city.php");

if(isset($_POST['btnUpdate']) && isset($_POST['City_ID']))
{
	$City_ID=Clean($conn,$_POST['City_ID']);
	$City_Name=Clean($conn,$_POST['City_Name']);
	
	$Lastin_Date=GetCurrentDate();
		
	UpdateCity($conn,$City_ID, $City_Name,$Lastin_Date);
	print "<script language=\"JavaScript\">window.location.href=\"../../../Admin/City/List \";</script>";
	
}

if (isset($_GET['City_ID']) && $_GET['City_ID']!="")
{	
	$City_ID=Clean($conn,$_GET['City_ID']);
	$ret=GetCityDataByCityID($conn,$City_ID);
	$num=mysqli_num_rows($ret);
}
?>
<div class="wrapper">

 <?php require_once('../template/sidebarfileEnD.php'); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       <a href="#"><i class="fa fa-dashboard"></i> Edit City</a>
        
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Edit City</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content"><!-----Section Start---------->
     
      <div class="row"><!-----Row Start------->
        
       			<section style="width:70%; margin-left:10%;">
							<header class="major"><h2>Edit City</h2></header>
								<form method="post">
                    		
							<?php
                            if($num>0)
                            {
                                    $row=mysqli_fetch_array($ret);
                        ?>
                        	<div class="form-group"  style="display:none;">
                                  <label for="City_ID">ID:</label>
                                 <input type="text" name="City_ID" value="<?php echo $row['City_ID']; ?>">
                              </div>
                            <div class="form-group">
                              <label for="City_Name">Name:</label>
                              <input type="text" class="form-control" id="City_Name" name="City_Name" value="<?php echo $row['City_Name'];  ?>">
                            </div>
                            <?php } ?> 
                           		<br />
                             <button type="submit" class="btn btn-danger" name="btnUpdate" style="margin-left:30%; " >Edit</button>
                            <!-- <a href="../../User/List"> <button  type="button" class="btn btn-default" name="btnDelete" style="margin-left:1%; ">Back</button></a>-->
                            <a href="../../City/List"> <button  type="button" class="btn btn-default"  style="margin-left:1%; ">Back</button></a>
                          
                          </form>
				</section>
				

       
      </div><!-----End Row-------->
     

    </section><!---End Section------->

  </div><!-- /.End content-wrapper -->
  <footer class="main-footer" style="text-align:center;"><strong >Copyright &copy; 2018 by D.P.S.</strong></footer>
  
</div>
<!-- ./wrapper -->


