<?php
session_start();

include("../../library/db.php");
include("../../library/function.php");
include("../../library/globalfunction.php");
include("../../library/adminpermission.php");
include("../../dal/dal_category.php");

$ret=GetCategoryDataByCategory($conn);
$num=mysqli_num_rows($ret);
?>
<div class="wrapper">

 <?php require_once('../template/sidebarfile.php'); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       <a href="#"><i class="fa fa-dashboard"></i> Category List</a>
        
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Category List</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content"><!-----Section Start---------->
     
      <div class="row"><!-----Row Start------->
        
       			<section >
							<header class="major"><h2>Category List</h2></header>
							<div class="table-responsive">
                    <table id="category_data" class="table table-striped table-bordered dt-responsive nowrap" width="98%" cellspacing="0">
                         <thead>
                            <tr>
                                <th>No</th>
                                <th>Name</th>
                                                               
                                <th>Added Date</th>
                                <th>Edited Date</th>
                                <th>Edit</th>
                                <th>Delete</th>
                            </tr>
                            </thead>
                            <tbody>
                             <?php  $u=1;
                                while($row=mysqli_fetch_array($ret)){	?>  
                            <tr>
                                <th><?php echo $u; ?></th>
                                <th><?php echo $row['Category_Name']; ?></th>
                                                             
                                <th><?php echo $row['Created_Date']; ?></th>
                                <th><?php echo $row['Lastin_Date']; ?></th>
                                <th><a href="../../Admin/Category/Edit/<?php echo $row['Category_ID']; ?>"><img src="../../YellowAdmin/img/wrench-screwdriver.png"  width="20" height="20"/></a></th>
                                <th><a href="../../Admin/Category/Remove/<?php echo $row['Category_ID']; ?>">
                <img src="../../YellowAdmin/img/cross-script.png" width="20" height="20" /></a></th>
                            </tr>
                           <?php $u=$u+1;  } ?> 
                           </tbody>
                     </table> 
                </div>
                <div class="frmSearch">
<input type="text" id="search-box" placeholder="Country Name" />
<div id="suggesstion-box"></div>
</div>  
				</section>
				

       
      </div><!-----End Row-------->
     

    </section><!---End Section------->

  </div><!-- /.End content-wrapper -->
  <footer class="main-footer" style="text-align:center;"><strong >Copyright &copy; 2018 by D.P.S.</strong></footer>
  
</div>

<!-- ./wrapper -->

  <!-- REQUIRED JS SCRIPTS -->
<link rel="stylesheet" href="../../YellowAdmin/css3/bootstrap.min.css">
<link rel="stylesheet" href="../../YellowAdmin/css3/dataTables.bootstrap.min.css">
<link rel="stylesheet" href="../../YellowAdmin/css3/responsive.bootstrap.min.css">
<script src="../../YellowAdmin/js3/jquery-1.12.4.js"></script>  
<script src="../../YellowAdmin/js3/jquery.dataTables.min.js"></script>  
<script src="../../YellowAdmin/js3/dataTables.bootstrap.min.js"></script> 
<script src="../../YellowAdmin/js3/dataTables.responsive.min.js"></script>  
<script src="../../YellowAdmin/js3/responsive.bootstrap.min.js"></script> 
<script>
    $(document).ready(function() {
    $('#category_data').DataTable();
} );
    </script>
  <style>
  #category_data_wrapper{
	  width:98%;
  }
  #category_data_filter{
	 margin-right:10%;
  }
  
  div.dataTables_wrapper div.dataTables_paginate {
	  text-align:left;
  }
  section{ width:100%!important; margin-left:1%!important;}
 
 
  
.frmSearch {border: 1px solid #a8d4b1;background-color: #c6f7d0;margin: 2px 0px;padding:40px;border-radius:4px;}
#category-list{float:left;list-style:none;margin-top:-3px;padding:0;width:190px;position: absolute;}
#category-list li{padding: 10px; background: #f0f0f0; border-bottom: #bbb9b9 1px solid;}
#category-list li:hover{background:#ece3d2;cursor: pointer;}
#search-box{padding: 10px;border: #a8d4b1 1px solid;border-radius:4px;}
</style>
<script src="https://code.jquery.com/jquery-2.1.1.min.js" type="text/javascript"></script>
<script>
$(document).ready(function(){
	$("#search-box").keyup(function(){
		$.ajax({
		type: "POST",
		url: "../../YellowAdmin/file/readCategory.php",
		data:'keyword='+$(this).val(),
		beforeSend: function(){
			$("#search-box").css("background","#FFF url(../../YellowAdmin/img/LoaderIcon.gif) no-repeat 165px");
		},
		success: function(data){
			$("#suggesstion-box").show();
			$("#suggesstion-box").html(data);
			$("#search-box").css("background","#FFF");
		}
		});
	});
});

function selectCategory(val) {
$("#search-box").val(val);
$("#suggesstion-box").hide();
}
</script>