<?php
session_start();

include("../../library/db.php");
include("../../library/function.php");
include("../../library/globalfunction.php");
@include("../../library/adminpermissionforEnd.php");
include("../../dal/dal_category.php");

if(isset($_POST['btnUpdate']) && isset($_POST['Category_ID']))
{
	$Category_ID=Clean($conn,$_POST['Category_ID']);
	$Category_Name=Clean($conn,$_POST['Category_Name']);
	
	$Lastin_Date=GetCurrentDate();
		
	UpdateCategory($conn,$Category_ID, $Category_Name,$Lastin_Date);
	print "<script language=\"JavaScript\">window.location.href=\"../../../Admin/Category/List \";</script>";
	
}

if (isset($_GET['Category_ID']) && $_GET['Category_ID']!="")
{	
	$Category_ID=Clean($conn,$_GET['Category_ID']);
	$ret=GetCategoryDataByCategoryID($conn,$Category_ID);
	$num=mysqli_num_rows($ret);
}
?>
<div class="wrapper">

 <?php require_once('../template/sidebarfileEnD.php'); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       <a href="#"><i class="fa fa-dashboard"></i> Edit Category</a>
        
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Edit Category</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content"><!-----Section Start---------->
     
      <div class="row"><!-----Row Start------->
        
       			<section style="width:70%; margin-left:10%;">
							<header class="major"><h2>Edit Category</h2></header>
							<form method="post" enctype="multipart/form-data">
                    		
							<?php
                            if($num>0)
                            {
                                    $row=mysqli_fetch_array($ret);
                        ?>
                        	<div class="form-group"  style="display:none;">
                                  <label for="Category_ID">ID:</label>
                                 <input type="text" name="Category_ID" value="<?php echo $row['Category_ID']; ?>">
                              </div>
                            <div class="form-group">
                              <label for="Category_Name">Name:</label>
                              <input type="text" class="form-control" id="Category_Name" name="Category_Name" value="<?php echo $row['Category_Name'];  ?>">
                            </div>
                            <?php } ?> 
                           		<br />
                             <button type="submit" class="btn btn-danger" name="btnUpdate" style="margin-left:30%; " >Edit</button>
                            <!-- <a href="../../User/List"> <button  type="button" class="btn btn-default" name="btnDelete" style="margin-left:1%; ">Back</button></a>-->
                            <a href="../../Category/List"> <button  type="button" class="btn btn-default"  style="margin-left:1%; ">Back</button></a>
                          
                          </form>
				</section>
				

       
      </div><!-----End Row-------->
     

    </section><!---End Section------->

  </div><!-- /.End content-wrapper -->
  <footer class="main-footer" style="text-align:center;"><strong >Copyright &copy; 2018 by D.P.S.</strong></footer>
  
</div>
<!-- ./wrapper -->


