<?php
session_start();

include("../../library/db.php");
include("../../library/function.php");
include("../../library/globalfunction.php");
@include("../../library/adminpermissionforEnd.php");
include("../../dal/dal_user.php");


if(isset($_POST['btnDelete']) && isset($_POST['User_ID']))
{
	$User_ID=Clean($conn,$_POST['User_ID']);
	
	
	DeleteUser($conn,$User_ID);
		print "<script language=\"JavaScript\">window.location.href=\"../../../Admin/User/List \";</script>";
}

if (isset($_GET['User_ID']) && $_GET['User_ID']!="")
{	
	$User_ID=Clean($conn,$_GET['User_ID']);
	$ret=GetUserDataByUserID($conn,$User_ID);
	$num=mysqli_num_rows($ret);
}
?>
<div class="wrapper">

 <?php require_once('../template/sidebarfileEnD.php'); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       <a href="#"><i class="fa fa-dashboard"></i> Dashboard</a>
        
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Dashboard</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content"><!-----Section Start---------->
     
      <div class="row"><!-----Row Start------->
        
       			<section style="width:70%; margin-left:10%;">
							<header class="major"><h2>Delete User</h2></header>
									<form method="post" >
                       		
                            <?php
                                if($num>0)
                                {
                                        $row=mysqli_fetch_array($ret);
                            ?>
                             
                              <div class="form-group" style="display:none;">
                                  <label for="User_ID">ID:</label>
                                 <input type="text" name="User_ID" value="<?php echo $row['User_ID']; ?>">
                              </div>
                              <div class="form-group">
                                  <label for="User_Name">Name:</label>
                                  <span style="color:#ccc; font-weight:bold;"> <?php echo $row['User_Name']; ?></span>
                              </div>
                               <div class="form-group">
                                  <label for="User_Role">Type:</label>
                                  <span style="color:#ccc; font-weight:bold;"> <?php echo $row['User_Role']; ?></span>
                              </div>
                              <div class="form-group">
                                  <label for="User_Email">Email:</label>
                                   <span style="color:#ccc; font-weight:bold;"><?php echo $row['User_Email']; ?></span>
                              </div>
                              <div class="form-group">
                                  <label for="User_Password">Password:</label>
                                   <span style="color:#ccc; font-weight:bold;"><?php echo $row['User_Password']; ?></span>
                              </div>
                             	<br />                               
                                <button type="submit" class="btn btn-danger" name="btnDelete" style="margin-left:30%; " >Delete</button>
                               <a href="../../User/List"> <button  type="button" class="btn btn-default" name="btnDelete" style="margin-left:1%; ">Back</button></a>
                                
                                         
                                    </th>
                                </tr>
                               <?php } ?>
                            </table>
	</form>
				</section>
				

       
      </div><!-----End Row-------->
     

    </section><!---End Section------->

  </div><!-- /.End content-wrapper -->
  <footer class="main-footer" style="text-align:center;"><strong >Copyright &copy; 2018 by D.P.S.</strong></footer>
  
</div>
<!-- ./wrapper -->


