<?php
include("../library/db.php");
include("../dal/dal_address.php");
	$qq=$_GET['q'];
	$my_data=$qq;
	$sql="SELECT DISTINCT Company_Name FROM tbl_address WHERE Company_Name LIKE '%$my_data%' AND Status='Success' ORDER BY Address_ID LIMIT 10";
	
	$result = mysqli_query($conn,$sql) or die(mysqli_error());
	
	if($result)
	{
		while($row=mysqli_fetch_array($result))
		{
			echo $row['Company_Name']."\n";
		}
	}
?>