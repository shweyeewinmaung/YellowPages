<?php
session_start();
include("../../YellowPages/library/db.php");

//include("../../YellowPages/library/adminpermissionforEnd.php");
//include("../../YellowPages/dal/dal_customer.php");
include("../../YellowPages/dal/dal_city.php");
include("../../YellowPages/dal/dal_category.php");
include("../../YellowPages/dal/dal_address.php");

if (isset($_GET['Address_ID']) && $_GET['Address_ID']!="")
{	
	$Address_ID=$_GET['Address_ID'];
	IncreaseView($conn,$Address_ID);
	$ret=GetAddressDataByAddressID($conn,$Address_ID);
	$num=mysqli_num_rows($ret);
}


?>
<html><head>
		
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<!--[if lte IE 8]><script src="css/ie/html5shiv.js"></script><![endif]-->
		<script src="../file/js/jquery.min.js"></script>
		<script src="../file/js/jquery.dropotron.min.js"></script>
		<script src="../file/js/skel.min.js" ></script>
		<script src="../file/js/skel-layers.min.js"></script>
		<script src="../file/js/init.js"></script>
		
			<link rel="stylesheet" href="../file/css/skel.css" />
			<link rel="stylesheet" href="../file/css/style.css" />
			<link rel="stylesheet" href="../file/css/style-wide.css" />
		
		<!--[if lte IE 8]><link rel="stylesheet" href="css/ie/v8.css" /><![endif]-->
    
	</head>
     <style>
     body{
	background:#000!important;
	height:1%!important;
}
	#map-canvas { height: 30% ; width:50%; position:absolute!important;}
	.well{ border:none!important;}
     </style>
	<body>

		<!-- Wrapper -->
			<div class="wrapper style1">

			<?php require_once("../template/headerfileD.php"); ?>

				<!-- Page -->
					<div id="page" class="container" style="height:1000px;">
						<section>
							<header class="major">
								<h2>Address Detail</h2>
								
							</header>
						<?php
							
							 $zoom = 17;
                            if($num>0)
                            {
                                    $row=mysqli_fetch_array($ret);
									
									
                        ?>
                        <div class="container">
					            <div class="row row-centered pos">
					                <div class="col-lg-10 col-xs-12 col-centered">
					                    <div class="well">
					                    	 <p>
                                         
                                          <?php 	
										 if($row['Photo']!="0" )
										  {
											  echo "<img src=../YellowPages/Photo/".$row['Photo']." alt='' width='250' height='250' style='border:3px solid#ccc;float:right'>"											?>
                                           <?php
										 }
										 else
										 {
											 echo ""; }
										?>
                                       
                                          </p>
					                    	<h2><a href="Detail/<?php echo $row['Address_ID']; ?>"><?php echo $row['Company_Name']; ?></a></h2> 
					                    	<h4><?php echo $row['Category_Name']; ?></h4>
					                    	<h3><?php echo $row['Address']; ?>
					                    	<p style="font-size:15px;"><?php echo $row['City_Name']; ?><br>
					                    	<?php if($row['Phone']=='0' || $row['Phone']==""){echo "";}else{ echo $row['Phone']; }?><br>
					                    	<?php if($row['Email']=='0' || $row['Email']==""){echo "";}else{ echo $row['Email']; } ?><br>
					                    	<?php if($row['Website']=='0' || $row['Website']==""){echo "";}else{ echo $row['Website']; } ?><br>
					                    	
											<?php $lat=$row['Lat']; ?>
                                            <?php $lng=$row['Lng']; ?>
                                            <?php $Address=$row['Address']; ?>

					                    </p>
<p style="font-size:15px; background:#06C; border-radius:5px; width:10%; color:#fff; text-align:center; "><?php echo $row['View']; ?> Views</p> 

					                    </div>
                                       
					                </div>
					                
					            </div>
                           	<h2><?php echo $row['Company_Name']; ?>'s Map</h2>
                        	 <div id="map-canvas" /></div>
                        <?php } ?> 
                           		<br />
                                               
                          
                       
						

						</section>
					</div>
				<!-- /Page -->
                 
 
					<?php //require_once("../template/mainfile.php"); ?>

	</div><!------Wrapper---------->

	<?php //require_once("../template/footerfile.php"); ?>

	<?php require_once("../template/copyfile.php"); ?>
	</body>
</html>
<script type="text/javascript"
      src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAkgLvsHlmuqAkafvTrCyR6X1qp8WVAbvg&sensor=false">
    </script>
    <script type="text/javascript">
      function initialize() { 
		
        var mapOptions = {
          center: new google.maps.LatLng(<?php echo $lat.', '.$lng; ?>),
          zoom: <?php echo $zoom; ?>,
		  mapTypeId: google.maps.MapTypeId.ROADMAP
		  };
		 var map = new google.maps.Map(document.getElementById("map-canvas"),
            mapOptions);
		var feature = 
          {
            position: new google.maps.LatLng(<?php echo $lat.', '.$lng; ?>),
            type: 'info'
		  };
		   <!-- var contentString = '<div id="content">'+
          <!--  '<div id="siteNotice">'+
           <!-- '</div>'+
          <!--  '<h1 id="firstHeading" class="firstHeading">Uluru</h1>'+
           <!-- '<div id="bodyContent">'+
           <!-- '<p><b>Uluru</b>, also referred to as <b>Ayers Rock</b>, is a large ' +
           <!-- 'sandstone rock formation in the southern part of the '+
           <!-- 'Northern Territory, central Australia. It lies 335&#160;km (208&#160;mi) '+
           <!-- 'south west of the nearest large town, Alice Springs; 450&#160;km '+
           <!-- '(280&#160;mi) by road. Kata Tjuta and Uluru are the two major '+
           <!-- 'features of the Uluru - Kata Tjuta National Park. Uluru is '+
           <!-- 'sacred to the Pitjantjatjara and Yankunytjatjara, the '+
           <!-- 'Aboriginal people of the area. It has many springs, waterholes, '+
           <!-- 'rock caves and ancient paintings. Uluru is listed as a World '+
           <!-- 'Heritage Site.</p>'+
            <!--'<p>Attribution: Uluru, <a href="https://en.wikipedia.org/w/index.php?title=Uluru&oldid=297882194">'+
            <!--'https://en.wikipedia.org/w/index.php?title=Uluru</a> '+
           <!-- '(last visited June 22, 2009).</p>'+
           <!-- '</div>'+
            <!--'</div>';
			
			var contentString = '<div id="content">'+
            '<h3><?php echo $Address; ?></h3>'+
          
            '</div>';
		  var infowindow = new google.maps.InfoWindow({
          content: contentString
        });
		 // Create markers.
         var marker = new google.maps.Marker({
            position: feature.position,
            map: map
		  });
		   marker.addListener('click', function() {
          infowindow.open(map, marker);
        });
		  
        }
	google.maps.event.addDomListener(window, 'load', initialize);
	</script>
