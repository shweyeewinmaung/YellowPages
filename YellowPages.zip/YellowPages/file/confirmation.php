<?php
session_start();
include("../library/db.php");
//include("../library/globalfunction.php");


$passkey = $_GET['passkey'];//passkey that got from link
$tbl_name1 = "temp";

$sql1 = "SELECT * FROM $tbl_name1 WHERE confirm_code='$passkey'";//retrieve from table where row that match this 
$result1 = mysqli_query($conn,$sql1);

?>
<html><head>
		
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<!--[if lte IE 8]><script src="css/ie/html5shiv.js"></script><![endif]-->
		<script src="js/jquery.min.js"></script>
		<script src="js/jquery.dropotron.min.js"></script>
		<script src="js/skel.min.js"></script>
		<script src="js/skel-layers.min.js"></script>
		<script src="js/init.js"></script>
		<noscript>
			<link rel="stylesheet" href="css/skel.css" />
			<link rel="stylesheet" href="css/style.css" />
			<link rel="stylesheet" href="css/style-wide.css" />
		</noscript>
		<!--[if lte IE 8]><link rel="stylesheet" href="css/ie/v8.css" /><![endif]-->
    
	</head>
     <style>
     body{
	background:#000!important;
	height:1%!important;
}
	
     </style>
	<body>

		<!-- Wrapper -->
			<div class="wrapper style1">

			<?php require_once("../template/headerfile.php"); ?>

				<!-- Page -->
					<div id="page" class="container">
						<section>
							<header class="major">
								<h2>Activate Code</h2>
                                <h3 style="color:#003; font-weight:bold; text-align:center;">Thank for Signup. You can Login Now..</h3>
                                	<?php	
									if($result1)//if successfully queried
{
	$count = mysqli_num_rows($result1);//count how many row has this passkey
	if($count==1)//if found this passkey in our database,retrieve data from table "temp_members_db"
	{
		$rows=mysqli_fetch_array($result1);
		$Customer_Name=$rows['Customer_Name'];
		$Customer_Phone=$rows['Customer_Phone'];
		$Customer_Email=$rows['Customer_Email'];
		$Customer_Password=$rows['Customer_Password'];
		$Customer_Address=$rows['Customer_Address'];
		$Created_Date=GetCurrentDate();
		$Lastin_Date=GetCurrentDate();
		$tbl_name2="tbl_customer";
		
		$sql2="INSERT INTO $tbl_name2(Customer_Name, Customer_Phone, Customer_Email, Customer_Password,Customer_Address,Created_Date,Lastin_Date)VALUES('$Customer_Name', '$Customer_Phone', '$Customer_Email', '$Customer_Password','$Customer_Address','$Created_Date','$Lastin_Date')";// Insert data that retrieves from "temp_members_db" into table "registered_members" 
		
		$result2=mysqli_query($conn,$sql2);
	}//end if $count
	else//if not found passkey,display message"wrong confirmation code
										{
											?> <p style="text-align:center; font-size:20px; color:red;"><?php echo "Wrong Confirmation Code";?></p> 
											<?php
										}
									// if successfully moved data from table"temp_members_db" to table "registered_members" displays message "Your account has been activated" and don't forget to delete confirmation code from table "temp_members_db"
	if(@$result2)
	{
		?> 
		<p style="text-align:center; font-size:20px; color:#1d1463;"><?php echo "Your account has been activated!  "; ?></p>
     
<?php
		$sql3="DELETE FROM $tbl_name1 WHERE confirm_code='$passkey'";// Delete information of this user from table "temp_members_db" that has this passkey 
		$result3=mysqli_query($conn,$sql3);
	}//end if $result2
}//end if $result1
?>
								
							</header>
						



						</section>
					</div>
				<!-- /Page -->

					<?php //require_once("../template/mainfile.php"); ?>

	</div><!------Wrapper---------->

	<?php //require_once("../template/footerfile.php"); ?>

	<?php require_once("../template/copyfile.php"); ?>
	</body>
</html>