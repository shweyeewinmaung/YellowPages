<html>
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta name="description" content="" />
<meta name="keywords" content="" />
<!--[if lte IE 8]><script src="css/ie/html5shiv.js"></script><![endif]-->
<script src="js/jquery.min.js"></script>
<script src="js/jquery.dropotron.min.js"></script>
<script src="js/skel.min.js"></script>
<script src="js/skel-layers.min.js"></script>
<script src="js/init.js"></script>
<noscript>
<link rel="stylesheet" href="css/skel.css" />
<link rel="stylesheet" href="css/style.css" />
<link rel="stylesheet" href="css/style-wide.css" />
</noscript>
<!--[if lte IE 8]><link rel="stylesheet" href="css/ie/v8.css" /><![endif]-->

</head><style>
body {
	background:#000!important;
	height:1%!important;
}
</style>
<body>

<!-- Wrapper -->
<div class="wrapper style1">
<?php require_once("../template/headerfile.php"); ?>

<!-- Page -->
<div id="page" class="container">
  <section>
    <header class="major">
      <h2>Forget Password</h2>
    </header>
    <form action='#' method='post'>
    		 <div class="form-group">
                     <label for="Customer_Email">Email:</label>
                     <input type="text" class="form-control" id="Customer_Email" name="Customer_Email" required>
             </div>
             <div class="form-group"><input type='submit' name='submit' value='Submit'/></div>
   </form>
    <?php
                            if(isset($_POST['submit']))
                            { 
                            
                             $Customer_Email=$_POST['Customer_Email'];
							 $ret=GetCustomerDataBy_CustomerEmail($conn,$Customer_Email);
                             $num=mysqli_num_rows($ret);
							 
							 if($num>0)
							{
								  $row=mysqli_fetch_array($ret);
								  
								  							  
								  $to=$row['Customer_Email'];
								  $subject='Remind password';
								  $message='Your password : '.$row['Customer_Password']; 
								  $headers='From:dpsmap@gmail.com';
								  				  
								  $m=mail($to,$subject,$message,$headers);
								  
								  /* Let's prepare the message for the e-mail */

							 if($m)
							
                              {
                                echo'Check your inbox in mail';
                              }
                              else
                              {
                               echo'mail is not send';
                              }
                             }
                             else
                             {
                              echo'You entered mail id is not present';
                             }
                            }
                            ?>
  </section>
</div>
<!-- /Page -->

<?php //require_once("../template/mainfile.php"); ?>
</div>
<!------Wrapper---------->

<?php //require_once("../template/footerfile.php"); ?>
<?php require_once("../template/copyfile.php"); ?>
</body>
</html>