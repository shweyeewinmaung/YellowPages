<?php
include("../library/db.php");
include("../dal/dal_address.php");
	$qq=$_GET['q'];
	$my_data=$qq;
	$sql="SELECT DISTINCT Address FROM tbl_address WHERE Address LIKE '%$my_data%' AND Status='Success' ORDER BY Address_ID LIMIT 10";
	$result = mysqli_query($conn,$sql) or die(mysqli_error());
	
	if($result)
	{
		while($row=mysqli_fetch_array($result))
		{
			echo $row['Address']."\n";
		}
	}
?>