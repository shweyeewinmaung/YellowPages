<?php
session_start();
session_destroy();
//header("Location:../LogIn");
//header("location:../YellowPages");
print "<script language=\"JavaScript\">window.location.href=\"../YellowPages\";</script>";
?>