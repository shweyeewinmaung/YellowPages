<?php
session_start();
include("../library/db.php");
include("../library/globalfunction.php");
include("../dal/dal_customer.php");


//if(isset($_SESSION['SESS']['User']['User_ID']))
//{
	//header("Location:Profile.php");
//}

$Customer_Email=Clean($conn,$_POST['Customer_Email']);
$Customer_Password=Clean($conn,$_POST['Customer_Password']);

$ret=GetLogInDataCustomer($conn,$Customer_Email, $Customer_Password);
$num=mysqli_num_rows($ret);

if($num>0)
{
	$row=mysqli_fetch_array($ret);
	$_SESSION['SESS']['Customer']['Customer_ID']=$row['Customer_ID'];
	$_SESSION['SESS']['Customer']['Customer_Name']=$row['Customer_Name'];
	//$_SESSION['SESS']['Customer']['Customer_Phone']=$row['Customer_Phone'];
	$_SESSION['SESS']['Customer']['Customer_Email']=$row['Customer_Email'];
	$_SESSION['SESS']['Customer']['Customer_Password']=$row['Customer_Password'];
	$_SESSION['SESS']['Customer']['Customer_Address']=$row['Customer_Address'];
	
	//header("location:../../Enfanto");
	//header("location:../../YellowPages");
	 print "<script language=\"JavaScript\">window.location.href=\"../../YellowPages\";</script>";
}
else
{
	$_SESSION['LogIn']="Fail";
	$msg="Invalid LogIn! Please Try Again!!!";
	
	//header("location:../YellowPages");
	print "<script language=\"JavaScript\">window.location.href=\"../YellowPages\";</script>";
	
}
?>