<?php
session_start();
include("../library/db.php");
//include("../dal/dal_customer.php");
include("../dal/dal_city.php");
include("../dal/dal_category.php");
include("../dal/dal_address.php");
include("../pager/pager_address1.php");

$pageSize=200;

if(isset($_GET['page']))
{
	$currentPageIndex=$_GET['page'];
}
else
{
	$currentPageIndex=1;
}
$objPager=new pager($pageSize,$currentPageIndex);

if(isset($_GET['btnSearch']) )
{
	$Address=$_GET['Address'];
	$Category_Name=$_GET['Category_Name'];
	$Company_Name=$_GET['Company_Name'];
	$City_Name=$_GET['City_Name'];
	$sql=$objPager->SearchData_AddressSearch($conn,$_GET['Address'],$_GET['Category_Name'],$_GET['Company_Name'],$_GET['City_Name']);
	$ret=$objPager->Search_Data($conn,$sql);
	$num=mysqli_num_rows($ret);
	
		$A="";
		$CN="";
		$CO="";
		$CI="";
		
		$OrderBy=" ORDER BY Address_ID";
		
		if($Address!="")
		{
			$A="Address LIKE '%$Address%' ";
		}
		
		if($Category_Name!="")
		{
			if($A!="")
			{
				$CN="AND Category_Name LIKE '%$Category_Name%' ";
			}
			elseif($A=="")
			{
				$CN="Category_Name LIKE '%$Category_Name%' ";
			}
		}
		if($Company_Name!="")
		{
			if($A!="" || $CN!="")
			{
				$CO="AND Company_Name LIKE '%$Company_Name%' ";
			}
			elseif($A=="" || $CN=="")
			{
				$CO="Company_Name LIKE '%$Company_Name%' ";
			}
		}
		if($City_Name!="")
		{
			if($A!="" || $CN!="" || $CO!="")
			{
				$CI="AND City_Name LIKE '%$City_Name%' ";
			}
			elseif($A=="" || $CN=="" || $CO=="")
			{
				$CI="City_Name LIKE '%$City_Name%' ";
			}
		}
		$sql2="SELECT * FROM `tbl_address` WHERE $A $CN $CO $CI AND Status='Success'";
	
	$ret2=mysqli_query($conn,$sql2);
	$num2=mysqli_num_rows($ret2);
	
	$numberofpage=ceil($num2/$pageSize);
}

if(isset($_GET['btnSearch1']) )
{
	$Address=$_GET['Address'];
	$Category_Name=$_GET['Category_Name'];
	$Company_Name=$_GET['Company_Name'];
	$City_Name=$_GET['City_Name'];
	$sql=$objPager->SearchData_AddressSearch($conn,$_GET['Address'],$_GET['Category_Name'],$_GET['Company_Name'],$_GET['City_Name']);
	$ret=$objPager->Search_Data($conn,$sql);
	$num=mysqli_num_rows($ret);
	
		$A="";
		$CN="";
		$CO="";
		$CI="";
		
		$OrderBy=" ORDER BY Address_ID";
		
		if($Address!="")
		{
			$A="Address LIKE '%$Address%' ";
		}
		
		if($Category_Name!="")
		{
			if($A!="")
			{
				$CN="AND Category_Name LIKE '%$Category_Name%' ";
			}
			elseif($A=="")
			{
				$CN="Category_Name LIKE '%$Category_Name%' ";
			}
		}
		if($Company_Name!="")
		{
			if($A!="" || $CN!="")
			{
				$CO="AND Company_Name LIKE '%$Company_Name%' ";
			}
			elseif($A=="" || $CN=="")
			{
				$CO="Company_Name LIKE '%$Company_Name%' ";
			}
		}
		if($City_Name!="")
		{
			if($A!="" || $CN!="" || $CO!="")
			{
				$CI="AND City_Name LIKE '%$City_Name%' ";
			}
			elseif($A=="" || $CN=="" || $CO=="")
			{
				$CI="City_Name LIKE '%$City_Name%' ";
			}
		}
		$sql2="SELECT * FROM `tbl_address` WHERE $A $CN $CO $CI AND Status='Success'";
	
	$ret2=mysqli_query($conn,$sql2);
	@$num2=mysqli_num_rows($ret2);
	$numberofpage=ceil($num2/$pageSize);
}
/***********************************************/
if(!isset($_GET['btnSearch1']) && !isset($_GET['btnSearch']) )
{
	
	$sql=$objPager->SearchData_GetPublishAddress($conn);
	$ret=$objPager->Search_Data($conn,$sql);
	$num=mysqli_num_rows($ret);
		
	$sql2="SELECT * FROM `tbl_address` ORDER BY Address_ID DESC ";
	$ret2=mysqli_query($conn,$sql2);
	$num2=mysqli_num_rows($ret2);
	
	$numberofpage=ceil($num2/$pageSize);
	
}


/*****************jump page*********************/
/*if(isset($_GET['btnNumSearch']) )
{
	$numberofpagecount=$_GET['numberofpagecount'];
	$Address=$_GET['Address'];
	$Category_Name=$_GET['Category_Name'];
	$Company_Name=$_GET['Company_Name'];
	$City_Name=$_GET['City_Name'];
	?>
	<?php 
	if($Category_Name=="" && $Address=="" && $Company_Name=="" && $City_Name=="")
	{
		//header("location:Search?page=$numberofpagecount");
		 print "<script language=\"JavaScript\">window.location.href=\"Search?page=$numberofpagecount\";</script>";
	}
	elseif( $Address!="" && $Category_Name!="" && $Company_Name!="" && $City_Name!="")
	{
		//header("location:Search?Address=$Address&Category_Name=$Category_Name&Company_Name=$Company_Name&City_Name=$City_Name&btnSearch=Search&page=$numberofpagecount");
		 print "<script language=\"JavaScript\">window.location.href=\"Search?Address=$Address&Category_Name=$Category_Name&Company_Name=$Company_Name&City_Name=$City_Name&btnSearch=Search&page=$numberofpagecount\";</script>";
	}
	elseif(( $Address=="" && $Category_Name!="" && $Company_Name!="" && $City_Name!="")|| ( $Address=="" && $Category_Name!="" && $Company_Name=="" && $City_Name=="") || ( $Address=="" && $Category_Name!="" && $Company_Name!="" && $City_Name=="")||( $Address=="" && $Category_Name!="" && $Company_Name=="" && $City_Name!="")||( $Address=="" && $Category_Name=="" && $Company_Name!="" && $City_Name=="")||( $Address=="" && $Category_Name=="" && $Company_Name=="" && $City_Name!=""))
	{
		//header("location:Search?Address=$Address&Category_Name=$Category_Name&Company_Name=$Company_Name&City_Name=$City_Name&btnSearch=Search&page=$numberofpagecount");
		 print "<script language=\"JavaScript\">window.location.href=\"Search?Address=$Address&Category_Name=$Category_Name&Company_Name=$Company_Name&City_Name=$City_Name&btnSearch=Search&page=$numberofpagecount\";</script>";
	}
	elseif(($Address!="" && $Category_Name=="" && $Company_Name=="" && $City_Name=="")||($Address!="" && $Category_Name!="" && $Company_Name=="" && $City_Name=="")||($Address!="" && $Category_Name!="" && $Company_Name!="" && $City_Name=="")||($Address!="" && $Category_Name=="" && $Company_Name=="" && $City_Name!="")||($Address!="" && $Category_Name=="" && $Company_Name!="" && $City_Name=="")||($Address!="" && $Category_Name!="" && $Company_Name=="" && $City_Name!=""))
	{
		//header("location:Search?Address=$Address&Category_Name=$Category_Name&Company_Name=$Company_Name&City_Name=$City_Name&btnSearch=Search&page=$numberofpagecount");
		 print "<script language=\"JavaScript\">window.location.href=\"Search?Address=$Address&Category_Name=$Category_Name&Company_Name=$Company_Name&City_Name=$City_Name&btnSearch=Search&page=$numberofpagecount\";</script>";
	}
	elseif(($Address!="" && $Category_Name=="" && $Company_Name!="" && $City_Name!="")||($Address!="" && $Category_Name=="" && $Company_Name!="" && $City_Name=="")||($Address!="" && $Category_Name=="" && $Company_Name=="" && $City_Name=="")||($Address!="" && $Category_Name=="" && $Company_Name=="" && $City_Name!="")||($Address=="" && $Category_Name=="" && $Company_Name!="" && $City_Name=="")||($Address=="" && $Category_Name=="" && $Company_Name=="" && $City_Name!=""))
	{
		//header("location:Search?Address=$Address&Category_Name=$Category_Name&Company_Name=$Company_Name&City_Name=$City_Name&btnSearch=Search&page=$numberofpagecount");
		 print "<script language=\"JavaScript\">window.location.href=\"Search?Address=$Address&Category_Name=$Category_Name&Company_Name=$Company_Name&City_Name=$City_Name&btnSearch=Search&page=$numberofpagecount\";</script>";
	}
	elseif(($Address=="" && $Category_Name!="" && $Company_Name=="" && $City_Name=="")|| ($Address=="" && $Category_Name!="" && $Company_Name=="" && $City_Name!="")||($Address=="" && $Category_Name!="" && $Company_Name!="" && $City_Name=="")||($Address!="" && $Category_Name!="" && $Company_Name=="" && $City_Name=="")||($Address!="" && $Category_Name!="" && $Company_Name=="" && $City_Name!="")||($Address!="" && $Category_Name!="" && $Company_Name!="" && $City_Name==""))
	{
		//header("location:Search?Address=$Address&Category_Name=$Category_Name&Company_Name=$Company_Name&City_Name=$City_Name&btnSearch=Search&page=$numberofpagecount");
		 print "<script language=\"JavaScript\">window.location.href=\"Search?Address=$Address&Category_Name=$Category_Name&Company_Name=$Company_Name&City_Name=$City_Name&btnSearch=Search&page=$numberofpagecount\";</script>";
	}
	elseif(($Address!="" && $Category_Name!="" && $Company_Name=="" && $City_Name!="")||($Address!="" && $Category_Name!="" && $Company_Name=="" && $City_Name=="")||($Address=="" && $Category_Name!="" && $Company_Name=="" && $City_Name!="")||($Address!="" && $Category_Name=="" && $Company_Name=="" && $City_Name=="")||($Address=="" && $Category_Name=="" && $Company_Name=="" && $City_Name!="")||($Address!="" && $Category_Name!="" && $Company_Name=="" && $City_Name=="")||($Address=="" && $Category_Name!="" && $Company_Name=="" && $City_Name==""))
	{
		//header("location:Search?Address=$Address&Category_Name=$Category_Name&Company_Name=$Company_Name&City_Name=$City_Name&btnSearch=Search&page=$numberofpagecount");
		 print "<script language=\"JavaScript\">window.location.href=\"Search?Address=$Address&Category_Name=$Category_Name&Company_Name=$Company_Name&City_Name=$City_Name&btnSearch=Search&page=$numberofpagecount\";</script>";
	}
	elseif(($Address=="" && $Category_Name=="" && $Company_Name!="" && $City_Name=="")||($Address=="" && $Category_Name=="" && $Company_Name!="" && $City_Name!="")||($Address=="" && $Category_Name!="" && $Company_Name!="" && $City_Name!="")||($Address!="" && $Category_Name=="" && $Company_Name!="" && $City_Name=="")||($Address!="" && $Category_Name=="" && $Company_Name!="" && $City_Name!="")||($Address=="" && $Category_Name!="" && $Company_Name!="" && $City_Name=="")||($Address!="" && $Category_Name!="" && $Company_Name!="" && $City_Name==""))
	{
		//header("location:Search?Address=$Address&Category_Name=$Category_Name&Company_Name=$Company_Name&City_Name=$City_Name&btnSearch=Search&page=$numberofpagecount");
		 print "<script language=\"JavaScript\">window.location.href=\"Search?Address=$Address&Category_Name=$Category_Name&Company_Name=$Company_Name&City_Name=$City_Name&btnSearch=Search&page=$numberofpagecount\";</script>";
	}
	elseif(($Address!="" && $Category_Name!="" && $Company_Name!="" && $City_Name=="")||($Address=="" && $Category_Name=="" && $Company_Name!="" && $City_Name=="")||($Address=="" && $Category_Name!="" && $Company_Name!="" && $City_Name=="")||($Address!="" && $Category_Name=="" && $Company_Name!="" && $City_Name=="")||($Address=="" && $Category_Name!="" && $Company_Name=="" && $City_Name=="")||($Address!="" && $Category_Name!="" && $Company_Name!="" && $City_Name=="")||($Address!="" && $Category_Name=="" && $Company_Name=="" && $City_Name==""))
	{
		//header("location:Search?Address=$Address&Category_Name=$Category_Name&Company_Name=$Company_Name&City_Name=$City_Name&btnSearch=Search&page=$numberofpagecount");
		 print "<script language=\"JavaScript\">window.location.href=\"Search?Address=$Address&Category_Name=$Category_Name&Company_Name=$Company_Name&City_Name=$City_Name&btnSearch=Search&page=$numberofpagecount\";</script>";
	}
	elseif(($Address=="" && $Category_Name=="" && $Company_Name=="" && $City_Name!="")||($Address=="" && $Category_Name=="" && $Company_Name!="" && $City_Name!="")||($Address=="" && $Category_Name!="" && $Company_Name!="" && $City_Name!="")||($Address!="" && $Category_Name=="" && $Company_Name!="" && $City_Name!="")||($Address!="" && $Category_Name!="" && $Company_Name=="" && $City_Name!="")||($Address!="" && $Category_Name=="" && $Company_Name=="" && $City_Name!="")||($Address=="" && $Category_Name!="" && $Company_Name=="" && $City_Name!=""))
	{
		//header("location:Search?Address=$Address&Category_Name=$Category_Name&Company_Name=$Company_Name&City_Name=$City_Name&btnSearch=&page=$numberofpagecount");
		 print "<script language=\"JavaScript\">window.location.href=\"Search?Address=$Address&Category_Name=$Category_Name&Company_Name=$Company_Name&City_Name=$City_Name&btnSearch=Search&page=$numberofpagecount\";</script>";
	}
}
*/
?>
<html><head>
		
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<!--[if lte IE 8]><script src="css/ie/html5shiv.js"></script><![endif]-->
		<script src="js/jquery.min.js"></script>
		<script src="js/jquery.dropotron.min.js"></script>
		<script src="js/skel.min.js"></script>
		<script src="js/skel-layers.min.js"></script>
		<script src="js/init.js"></script>
		<noscript>
			<link rel="stylesheet" href="css/skel.css" />
			<link rel="stylesheet" href="css/style.css" />
			<link rel="stylesheet" href="css/style-wide.css" />
		</noscript>
		<!--[if lte IE 8]><link rel="stylesheet" href="css/ie/v8.css" /><![endif]-->
    
	</head>
     <style>
     body{
	background:#000!important;
	height:1%!important;
	color:red;
}
	
     </style>
	<body>

		<!-- Wrapper -->
			<div class="wrapper style1">
            

			<?php require_once("../template/headerfile.php"); ?>

				<!-- Page -->
					<div id="page" class="container" > 
                    	
						<section>
							<header class="major">
								<h2>Search for Address</h2>
								
							</header>
						<form method="get" class="formsearch" style="width: 100%">
                            <div class="table-responsive">
                                    <table class="table" style="width:95%; " >
                                         <tbody>
                                         <tr>
                                            <td style="border-top:none;">
                                            	<label for="Address">Address:</label>
                                                <div class="form-group ">
                                                    <div class="input-group">
                                                    	
                                                        <input class="form-control" id="Address"  placeholder="Address"  type="text" name="Address" value="<?php if(isset($_GET['showAll'])){ echo "";}else{ echo @htmlspecialchars($_GET['Address']);} ?>"/>
                                                       
                                                        <div class="input-group-addon"><span class="fa fa-map-marker"></span></div>
                                                   </div>
                                               </div>
                                            </td>
                                            
                                              <td style="border-top:none;">
                                               <label for="Category_Name">Type:</label>
                                               <div class="form-group">
                                               
                                                <select class="form-control" id="Category_Name" name="Category_Name"  >
                                                     <option ><?php if(isset($_GET['showAll'])){ echo "";}else{ echo @htmlspecialchars($_GET['Category_Name']);} ?></option>
                                                     <option></option>
													 <?php	
                                                        $retCA=getAllCategoryData($conn);
                                                        while($rowCA=mysqli_fetch_array($retCA))
                                                        {	echo "<option>" . $rowCA['Category_Name'] . "</option>";	}
                                                    ?>
                                                </select>
                                              </div>    
                                              </td>
                                               <td style="border-top:none;">
                                            	<label for="Company">Company:</label>
                                                <div class="form-group ">
                                                    <div class="input-group">
                                                    	
                                                        <input class="form-control" id="Company_Name"  placeholder="Company"  type="text" name="Company_Name" value="<?php if(isset($_GET['showAll'])){ echo "";}else{ echo @htmlspecialchars($_GET['Company_Name']);} ?>" />
                                                       
                                                       
                                                   </div>
                                               </div>
                                            </td>
                                            <td style="border-top:none;">
                                               <label for="City_Name">City:</label>
                                               <div class="form-group">
                                               
                                                <select class="form-control" id="City_Name" name="City_Name"  >
                                                     <option ><?php if(isset($_GET['showAll'])){ echo "";}else{ echo @htmlspecialchars($_GET['City_Name']);} ?></option>
                                                     <option></option>
													 <?php	
                                                        $retCI=getAllCityData($conn);
                                                        while($rowCI=mysqli_fetch_array($retCI))
                                                        {	echo "<option>" . $rowCI['City_Name'] . "</option>";	}
                                                    ?>
                                                </select>
                                              </div>    
                                              </td>
                                              <td style="border-top:none;"><button type="submit" name="showAll" class="btn btn-info" style="width:80%">All</button><p style="margin-bottom:10px;"></p><button type="submit" class="btn btn-info"  name="btnSearch1" style="width:80%; text-align:center;">Search</button></td>
                                              </tr>
                                            <!--tr>
                                              <td style="border-top:none;">
                                               <label for="numberofpagecount">Page:</label>
                                            <div class="form-group"  style="width:30%;">
                                            	
                                                <select class="form-control" id="numberofpagecount" name="numberofpagecount" >
                                                  <option><?php //echo $currentPageIndex ;?></option>
                                                   <?php 
                                                   // for($p=1;$p<=$numberofpage;$p++)
                                                   // {echo "<option>".$p ."</option>";}
                                                  ?>
                                                </select>
                                              </div>
                                            
                                            </td>
                                            <td style="border-top:none;">  <label for="btnNumSearch" style="margin-left:-60%">Jump to Page</label><br />
                                            <button type="submit" class="btn btn-info"  name="btnNumSearch" style="width:50%;margin-left:-60%;">Go Pages</button></td> 
                                           
                                         </tr-->
                                         </tbody>
                                     </table>
                                     </div>
                            </form>
									 <?php if(@$num<10){  ?>  
                           			<div id="map-canvas" style="width:90%; height:40%;"></div>
                                   <p> <br></br><br></br><br></br><br></br><br></br>
                                    <br></br><br></br><br></br><br></p>
                                   <?php }else{?>
                                   <div id="map-canvas" style="width:90%; height:400px;"></div>
                                   <p> <br></br><br></br><br></br><br></br><br></br>
                                    <br></br><br></br><br></br><br></p>
                                    <?php } ?>
                              <p style="padding:5px 0px;color:#900; font-weight:bold; font-size:18px;">Search Results :<?php echo $num2; ?> Entries</p>
                              
                               <div class="table-responsive">
			<table id="address_data" class="table table-striped table-bordered" style="width:100%; background:#ccc;">  
             <?php if(@$num>0)
						{  ?>  
               <thead  style="background:#007cc7;color:#fff; font-weight:bold;">
                <tr>
                    <th>No</th>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Lat</th>
                    <th>Lng</th>
                    <th>City</th>
                    <th>Type</th>
                    <th>Company</th>
                    <th>Photo</th>
                                        
                    <th>View</th>
                    <th>Created Date</th>
                    <th>Lastin Update</th>
                    <th>Detail</th>
                    
                </tr>
                </thead>
                <tbody>
                	<?php
							$u=(($currentPageIndex*$pageSize)+1)-$pageSize; 
							while($row=mysqli_fetch_array($ret))
							{
								?>
                <tr>
                    <th><?php echo $u; ?></th>
                    <th><?php echo $row['Address_ID']; ?></th>
                    <th><?php echo $row['Address']; ?></th>
                    <th><?php echo $row['Lat']; ?></th>
                    <th><?php echo $row['Lng']; ?></th>
                    <th><?php echo $row['City_Name']; ?></th>
                    <th><?php echo $row['Category_Name']; ?></th>
                    <th><?php echo $row['Company_Name']; ?></th>
                    <th><?php  if($row['Photo']!="0" ){echo "<img src=YellowPages/Photo/".$row['Photo']." alt='' width='25' height='25' style='border:3px solid#ccc;'>"	?><?php }else{	 echo ""; }	?></th>
                   
                                       
                    <th><?php echo $row['View']; ?></th>
                    <th><?php echo $row['Created_Date']; ?></th>
                    <th><?php echo $row['Lastin_Date']; ?></th>
                    <th><a href="Detail/<?php echo $row['Address_ID']; ?>" style="float:right;">Detail>>></a></th>
                      <?php           $Address_ID = $row['Address_ID'];
									  				$Lat = $row['Lat'];
  												 $Lng = $row['Lng'];
												$Address = $row['Address'];
												$Company_Name = $row['Company_Name'];
												$locations[]=array( 'Address_ID'=>$Address_ID,'Company_Name'=>$Company_Name, 'Lat'=>$Lat, 'Lng'=>$Lng, 'Address'=>$Address ); ?>    
                              
                </tr>
               <?php $u=$u+1;  } 
			   
			   }
					 else
					{
						?>
                        	<center>Not available!</center>
                        <?php
					}
			   ?> 
                     </table>
                     </div>
                     <span id="pager" style="padding-left:30%;"> 
                       <?php
                	@$objPager->Generate_Pager($str,$conn);
?>
                </span>
                          
                              
                
					        </div>
					        


                           </section>
                           
                           
					</div>
				<!-- /Page -->

					<?php //require_once("../template/mainfile.php"); ?>

	</div><!------Wrapper---------->

	<?php //require_once("../template/footerfile.php"); ?>

	<?php require_once("../template/copyfile.php"); ?>
	</body>
</html>
 <style>
 
  section{ width:100%!important; margin-left:1%!important;}
 
#address-list{float:left;list-style:none;margin-top:10%;padding:0;width:100%;position: absolute; border:1px solid#000;}
#address-list li{padding: 10px; background: #fff; border-bottom: #666; border-radius:1px;}
#address-list li:hover{background:#ccc;cursor: pointer;}

#company-list{float:left;list-style:none;margin-top:10%;padding:0;width:100%;position: absolute; border:1px solid#000;}
#company-list li{padding: 10px; background: #fff; border-bottom: #666; border-radius:1px;}
#company-list li:hover{background:#ccc;cursor: pointer;}
.ac_results{width:30%!important;}
.ac_results li{padding:10px 10px!important; font-family:Arial!important; background:#ccc; border-bottom:1px solid#fafafa; font-size:12px!important;}
.ac_results li:hover{color:#007cc7;}
.input-group-addon{color:#ff0000; background-color: #ffffff; width:10%; border:2px solid#ccc;}
</style>
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<script src="https://code.jquery.com/jquery-2.1.1.min.js" type="text/javascript"></script>

<link rel="stylesheet" type="text/css" href="file/css/jquery.ajaxcomplete.css" />
<script type="text/javascript" src="file/js/jquery.js"></script>
<script type="text/javascript" src="file/js/jquery.ajaxcomplete.js"></script>
<script>
$(document).ready(function(){
 $("#Address").autocomplete("file/ajaxcompleteaddress1.php", {
		selectFirst: true
	});
});
</script>
<script>
$(document).ready(function(){
 $("#Company_Name").autocomplete("file/ajaxcompletecompany1.php", {
		selectFirst: true
	});
});
</script>

 <script type="text/javascript" src="http://maps.googleapis.com/maps/api/js?key=AIzaSyBf3t3q5Lio9CbkTxxwpPxSUCoTCBcmTrU"></script> 
    <script type="text/javascript">
    var map;
    var Markers = {};
    var infowindow;
    var locations = [
        <?php for($i=0;$i<sizeof($locations);$i++){ $j=$i+1;?>
        [
            
			'<?php echo $locations[$i]['Address'];?>',
            '<p><a href="Detail/<?php echo $locations[$i]['Address_ID'];?>"><?php echo $locations[$i]['Address']; ?></a></p>',
            <?php echo $locations[$i]['Lat'];?>,
            <?php echo $locations[$i]['Lng'];?>,
			
            0
        ]<?php if($j!=sizeof($locations))echo ","; }?>
    ];
    var origin = new google.maps.LatLng(locations[0][2], locations[0][3]);
    function initialize() {
      var mapOptions = {
        zoom: 11,
		 mapTypeId: google.maps.MapTypeId.ROADMAP,
       center: new google.maps.LatLng(<?php echo $Lat.', '.$Lng; ?>),
      };
	  
	 
	  
      map = new google.maps.Map(document.getElementById('map-canvas'), mapOptions);
        infowindow = new google.maps.InfoWindow();
        for(i=0; i<locations.length; i++) {
            var position = new google.maps.LatLng(locations[i][2], locations[i][3]);
            var marker = new google.maps.Marker({
                position: position,
                map: map,
				title:locations[i][0]
            });
            google.maps.event.addListener(marker, 'click', (function(marker, i) {
                return function() {
                    infowindow.setContent(locations[i][1]);
                    infowindow.setOptions({maxWidth: 200});
                    infowindow.open(map, marker);
                }
            }) (marker, i));
			 
            Markers[locations[i][4]] = marker;
        }
        locate(0);
    }
    function locate(marker_id) {
        var myMarker = Markers[marker_id];
        var markerPosition = myMarker.getPosition();
        map.setCenter(markerPosition);
        google.maps.event.trigger(myMarker, 'click');
    }
    google.maps.event.addDomListener(window, 'load', initialize);
    </script>
    <style>
    #map-canvas { width:90%; height:40%;position:absolute!important;}
	@media-screen(max-width: 768px){ #map-canvas { width:100%; position:absolute!important;}}
	@media-screen(max-width: 768px){ .form-control{ width:100%;} form{width:200%;}}
    </style>

