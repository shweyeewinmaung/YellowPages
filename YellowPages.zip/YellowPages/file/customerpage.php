<?php
session_start();
include("../library/db.php");
include("../library/globalfunction1.php");

include("../dal/dal_category.php");
include("../dal/dal_city.php");
//include("../dal/dal_customer.php");
include("../dal/dal_address.php");



if (isset($_POST['Address']))
{	
	$Address=$_POST['Address'];
	$Lat=$_POST['Lat'];
	$Lng=$_POST['Lng'];
	$City_Name=$_POST['City_Name'];
	$Category_Name=$_POST['Category_Name'];
	$Company_Name=$_POST['Company_Name'];
	$Customer_ID=$_SESSION['SESS']['Customer']['Customer_ID'];
	$Email=$_POST['Email'];
	$Phone=$_POST['Phone'];
	$Website=$_POST['Website'];
	$View="0";
	$Status="0";
	
	/***************************************************************/						
		//For "ItemImage"
		// get the original filename
		$image = $_FILES['Photo']['name'];
			
		// image storing folder, make sure you indicate the right path
		$folder = "../Photo/"; 
		
		// image checking if exist or the input field is not empty
		if($image) 
		{ 
		  // creating a filename
		  $filename = $folder . $Company_Name . "_" . $image; 		  
		  // uploading image file to specified folder
		  $copied = copy($_FILES['Photo']['tmp_name'], $filename); 
		  
		  // checking if upload succesfull
		  if (!$copied) 
		  { 			  
			exit("Problem occured. Cannot Upload Item Image.");
		  }
		}
		/***************************************************************/	
	
	$Created_Date=GetCurrentDate1();
	$Lastin_Date=GetCurrentDate1();
	
	//$ret=GetAddressDataBy_Address($conn,$Address);
		
	//$num=mysqli_num_rows($ret);
	//if($num>0)
	//{
		//$_SESSION['Address']="Exist";
	//}else{
		InsertAddressCustomer($conn,$Address,$Lat,$Lng,$City_Name,$Category_Name,$Company_Name,$Customer_ID,$Email,$Phone,$Website,$View,$Status,$filename,$Created_Date,$Lastin_Date);
		//$_SESSION['Address']="Success";
	//}
}
?>
<html><head>
		
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<!--[if lte IE 8]><script src="css/ie/html5shiv.js"></script><![endif]-->
		<script src="js/jquery.min.js"></script>
		<script src="js/jquery.dropotron.min.js"></script>
		<script src="js/skel.min.js"></script>
		<script src="js/skel-layers.min.js"></script>
		<script src="js/init.js"></script>
		<noscript>
			<link rel="stylesheet" href="css/skel.css" />
			<link rel="stylesheet" href="css/style.css" />
			<link rel="stylesheet" href="css/style-wide.css" />
		</noscript>
		<!--[if lte IE 8]><link rel="stylesheet" href="css/ie/v8.css" /><![endif]-->
    
	</head>
     <style>
     body{
	background:#000!important;
	height:1%!important;
}
	
     </style>
	<body>

		<!-- Wrapper -->
			<div class="wrapper style1">

			<?php require_once("../template/headerfile.php"); ?>

				<!-- Page -->
					<div id="page" class="container">
						<section>
							<header class="major"><h2>My Page</h2></header>
							<form method="post" enctype="multipart/form-data">
                    		
                             <div class="form-group">
                              <label for="Address">Address:</label>
                              <textarea class="form-control" rows="5" id="Address" name="Address"></textarea>
                            </div> 
                            <div class="form-group">
                              <label for="Lat">Lat:</label>
                              <input type="text" class="form-control" id="Lat" name="Lat">
                            </div>
                             <div class="form-group">
                              <label for="Lng">Lng:</label>
                              <input type="text" class="form-control" id="Lng" name="Lng">
                            </div>
                           <div class="form-group">
                           <label for="City">City:</label>
                            <select class="form-control" id="City_Name" name="City_Name">
                                 <?php	
								 	$retC=getAllCityData($conn);
									while($rowC=mysqli_fetch_array($retC))
									{	echo "<option>" . $rowC['City_Name'] . "</option>";	}
								?>
                            </select>
                          </div>    
                            <div class="form-group">
                            <label for="Category_Name">Type:</label>
                            <select class="form-control" id="Category_Name" name="Category_Name">
                                 <?php	
								 	$retCA=getAllCategoryData($conn);
									while($rowCA=mysqli_fetch_array($retCA))
									{	echo "<option>" . $rowCA['Category_Name'] . "</option>";	}
								?>
                            </select>
                          </div>    
                                                        
                            <div class="form-group">
                              <label for="Company_Name">Name:</label>
                              <input type="text" class="form-control" id="Company_Name" name="Company_Name">
                            </div>
                            <div class="form-group">
                              <label for="Email">Email:</label>
                              <input type="email" class="form-control" id="Email" name="Email" >
                            </div>
                            <div class="form-group">
                              <label for="Phone">Phone:</label>
                              <input type="text" class="form-control" id="Phone" name="Phone">
                            </div>
                            <div class="form-group">
                              <label for="Website">Website:</label>
                              <input type="text" class="form-control" id="Website" name="Website">
                            </div>
                         
                          <div class="form-group">
                              <label for="Photo">Photo:</label>
                              <input type="file" name="Photo"  id="Photo"/>
                            </div>  
                           
                            <button type="submit" class="btn-primary" name="btnAdd"  >Entry</button>
                          
                          </form>



						</section>
					</div>
				<!-- /Page -->

					<?php //require_once("../template/mainfile.php"); ?>

	</div><!------Wrapper---------->

	<?php // require_once("../template/footerfile.php"); ?>

	<?php require_once("../template/copyfile.php"); ?>
	</body>
</html>