<?php
mysqli_close($database);
?>