<?php
include("db.php");
function AutoID($conn,$tableName, $FieldName, $Prefix, $NoOfZero)
{
	$sql="SELECT * FROM " . $tableName . " ORDER BY " . $FieldName . " DESC";
	$ret=mysqli_query($conn, $sql);
	$num=mysqli_num_rows($ret);
	if($num<1)
	{
		return $Prefix . str_pad("1", $NoOfZero, "0", STR_PAD_LEFT);
	}
	else
	{
		$row=mysqli_fetch_array($ret);
		$OldID=$row[$FieldName];
		$Temp = explode("-", $OldID);
		$Value=$Temp[1];
		$Value++;
		$NewID=$Prefix . str_pad($Value, $NoOfZero, "0", STR_PAD_LEFT);
		return $NewID;
	}
}


?>
