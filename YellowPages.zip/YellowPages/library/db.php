<?php
$host="localhost";
$username="root";
$password="";
$database="yellowpagedb";

$conn = mysqli_connect($host, $username, $password) or die(mysqli_error());
mysqli_set_charset($conn,'utf8');
mysqli_select_db($conn,$database) or die(mysqli_error());


?>