<?php
if(!$_SESSION['SESS']['User'])
{
	header("Location:Admin/LogIn");
}
?>