<?php
include("db.php");

function GetCurrentDate1()
{
	date_default_timezone_set("Asia/Rangoon");
	//return date("Y-M-d");
	return date("d-m-Y");
}

