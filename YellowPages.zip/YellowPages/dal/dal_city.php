<?php
function getAllCityData($conn){
	$sql="Select * from tbl_city order by City_ID";
	$ret=mysqli_query($conn,$sql);
	return $ret;
}
function GetCityDataBy_CityName($conn,$City_Name)
{
	$sql="SELECT * FROM tbl_city WHERE City_Name='$City_Name'";
	$ret=mysqli_query($conn,$sql);
	return $ret;
}
function GetCityDataByCityID($conn,$City_ID)
{
	$sql="SELECT * FROM tbl_city WHERE City_ID='$City_ID'";
	return mysqli_query($conn,$sql);
}
function GetCityDataByCity($conn)
{
	$sql="SELECT * FROM tbl_city order by City_ID desc";
	return mysqli_query($conn,$sql);
}
function InsertCity($conn,$City_ID, $City_Name,$Created_Date,$Lastin_Date)
{
	$sql="INSERT INTO tbl_city(City_ID, City_Name,Created_Date,Lastin_Date) 
			VALUES('$City_ID', '$City_Name','$Created_Date','$Lastin_Date')";
	mysqli_query($conn,$sql);
}
function UpdateCity($conn,$City_ID, $City_Name,$Lastin_Date)
{
	$sql="UPDATE tbl_city SET City_Name='$City_Name', Lastin_Date='$Lastin_Date'
							 
							WHERE City_ID='$City_ID'";
	mysqli_query($conn,$sql);
}
function DeleteCity($conn,$City_ID)
{
	$sql="DELETE FROM tbl_city WHERE City_ID='$City_ID'";
	mysqli_query($conn,$sql);
}
?>