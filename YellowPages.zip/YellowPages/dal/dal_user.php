<?php
function GetLogInData($conn,$User_Name, $User_Password)
{
	$sql="SELECT * FROM tbl_user WHERE User_Name='$User_Name' AND User_Password='$User_Password'";
	
	return mysqli_query($conn,$sql);
}
function GetUserDataByUser($conn)
{
	$sql="SELECT * FROM tbl_user order by User_ID desc";
	return mysqli_query($conn,$sql);
}
function GetUserDataBy_UserName($conn,$User_Name)
{
	$sql="SELECT * FROM tbl_user WHERE User_Name='$User_Name'";
	$ret=mysqli_query($conn,$sql);
	return $ret;
}
function GetUserDataByUserID($conn,$User_ID)
{
	$sql="SELECT * FROM tbl_user WHERE User_ID='$User_ID'";
	return mysqli_query($conn,$sql);
}
function GetUserNameByUserID($conn,$User_ID)
{
	$sql="SELECT * FROM tbl_user WHERE User_ID='$User_ID'";
	$ret=mysqli_query($conn,$sql);
	$row=mysqli_fetch_array($ret);
	
	return $row['1'];
}
function InsertUser($conn,$User_ID, $User_Name, $User_Email, $User_Password,$User_Role,$Created_Date,$Lastin_Date)
{
	$sql="INSERT INTO tbl_user(User_ID, User_Name, User_Email, User_Password,User_Role,Created_Date,Lastin_Date) 
			VALUES('$User_ID', '$User_Name', '$User_Email', '$User_Password', '$User_Role','$Created_Date','$Lastin_Date')";
	mysqli_query($conn,$sql);
}
function UpdateUser($conn,$User_ID, $User_Name,$User_Role, $User_Email, $User_Password, $Lastin_Date)
{
	$sql="UPDATE tbl_user SET User_Name='$User_Name', 
							  User_Role='$User_Role',
							  User_Email='$User_Email', 
							  User_Password='$User_Password',
							  Lastin_Date='$Lastin_Date'
							 
							WHERE User_ID='$User_ID'";
	mysqli_query($conn,$sql);
}
function DeleteUser($conn,$User_ID)
{
	$sql="DELETE FROM tbl_user WHERE User_ID='$User_ID'";
	mysqli_query($conn,$sql);
}
?>