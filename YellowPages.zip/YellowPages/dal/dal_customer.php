<?php
function GetLogInDataCustomer($conn,$Customer_Email, $Customer_Password)
{
	$sql="SELECT * FROM tbl_customer WHERE Customer_Email='$Customer_Email' AND Customer_Password='$Customer_Password'";
	
	return mysqli_query($conn,$sql);
}
function GetCustomerDataBy_CustomerName($conn,$Customer_Name)
{
	$sql="SELECT * FROM tbl_customer WHERE Customer_Name='$Customer_Name'";
	$ret=mysqli_query($conn,$sql);
	return $ret;
}
function GetCustomerDataBy_CustomerEmail($conn,$Customer_Email)
{
	$sql="SELECT * FROM tbl_customer WHERE Customer_Email='$Customer_Email'";
	$ret=mysqli_query($conn,$sql);
	return $ret;
}
function GetCustomerDataByCustomerID($conn,$Customer_ID)
{
	$sql="SELECT * FROM tbl_customer WHERE Customer_ID='$Customer_ID'";
	return mysqli_query($conn,$sql);
}
function GetCustomerDataByCustomer($conn)
{
	$sql="SELECT * FROM tbl_customer order by Customer_ID desc";
	return mysqli_query($conn,$sql);
}
function InsertCustomer($conn, $Customer_Name, $Customer_Email, $Customer_Password,$Customer_Address,$Created_Date,$Lastin_Date)
{
	$sql="INSERT INTO tbl_customer( Customer_Name, Customer_Email, Customer_Password,Customer_Address,Created_Date,Lastin_Date) 
			VALUES( '$Customer_Name', '$Customer_Email', '$Customer_Password', '$Customer_Address','$Created_Date','$Lastin_Date')";
	mysqli_query($conn,$sql);
}
function UpdateCustomer($conn,$Customer_ID, $Customer_Name,$Customer_Email,$Customer_Password,$Customer_Address,$Lastin_Date)
{
	$sql="UPDATE tbl_customer SET Customer_Name='$Customer_Name', 
							  Customer_Email='$Customer_Email',
							  Customer_Password='$Customer_Password', 
							  Customer_Address='$Customer_Address',
							  Lastin_Date='$Lastin_Date'
							 
							WHERE Customer_ID='$Customer_ID'";
	mysqli_query($conn,$sql);
}

function DeleteCustomer($conn,$Customer_ID)
{
	$sql="DELETE FROM tbl_customer WHERE Customer_ID='$Customer_ID'";
	mysqli_query($conn,$sql);
}
?>