<?php
function GetAddressDataBy_Address($conn,$Address)
{
	$sql="SELECT * FROM tbl_address WHERE Address='$Address'";
	$ret=mysqli_query($conn,$sql);
	return $ret;
}
function IncreaseView($conn,$Address_ID)
{
	$sql="UPDATE tbl_address SET View=View+1 WHERE Address_ID='$Address_ID'";
	mysqli_query($conn,$sql);
}
function GetPublishDataByAddress($conn)
{
	$sql="SELECT * FROM tbl_address Where Status='Success' order by Address_ID desc";
	return mysqli_query($conn,$sql);
}
function GetRequestDataByAddress($conn)
{
	$sql="SELECT * FROM tbl_address Where Status='0' || Status ='' order by Address_ID desc";
	return mysqli_query($conn,$sql);
}
function GetAddressDataByAddressID($conn,$Address_ID)
{
	$sql="SELECT * FROM tbl_address WHERE Address_ID='$Address_ID'";
	return mysqli_query($conn,$sql);
}
function InsertAddress($conn,$Address,$Lat,$Lng,$City_Name,$Category_Name,$Company_Name,$Email,$Phone,$Website,$View,$Status,$Photo,$Created_Date,$Lastin_Date)
{
	$sql="INSERT INTO tbl_address(Address,Lat,Lng,City_Name,Category_Name,Company_Name,Email,Phone,Website,View,Status,Photo,Created_Date,Lastin_Date) 
			VALUES('$Address','$Lat','$Lng','$City_Name','$Category_Name','$Company_Name','$Email','$Phone','$Website','$View','$Status','$Photo','$Created_Date','$Lastin_Date')";
	mysqli_query($conn,$sql);
}
function InsertAddressCustomer($conn,$Address,$Lat,$Lng,$City_Name,$Category_Name,$Company_Name,$Customer_ID,$Email,$Phone,$Website,$View,$Status,$Photo,$Created_Date,$Lastin_Date)
{
	$sql="INSERT INTO tbl_address(Address,Lat,Lng,City_Name,Category_Name,Company_Name,Customer_ID,Email,Phone,Website,View,Status,Photo,Created_Date,Lastin_Date) 
			VALUES('$Address','$Lat','$Lng','$City_Name','$Category_Name','$Company_Name','$Customer_ID','$Email','$Phone','$Website','$View','$Status','$Photo','$Created_Date','$Lastin_Date')";
	mysqli_query($conn,$sql);
}
function UpdateAddressPhoto($conn,$Address_ID,$Address,$Lat,$Lng,$City_Name,$Category_Name,$Company_Name,$Email,$Phone,$Website,$Status,$Photo,$Lastin_Date)
{
	$sql="UPDATE tbl_address SET Address='$Address', 
	
								Lat='$Lat',
								Lng='$Lng',
								City_Name='$City_Name',
								Category_Name='$Category_Name',
								Company_Name='$Company_Name',
								Email='$Email',
								Phone='$Phone',
								Website='$Website',
								Status='$Status',
								Photo='$Photo',
								
								Lastin_Date='$Lastin_Date'
							 
							WHERE Address_ID='$Address_ID'";
							
	mysqli_query($conn,$sql);
}
function UpdateAddress($conn,$Address_ID,$Address,$Lat,$Lng,$City_Name,$Category_Name,$Company_Name,$Email,$Phone,$Website,$Status,$Lastin_Date)
{
	$sql="UPDATE tbl_address SET Address='$Address', 
	
								Lat='$Lat',
								Lng='$Lng',
								City_Name='$City_Name',
								Category_Name='$Category_Name',
								Company_Name='$Company_Name',
								Email='$Email',
								Phone='$Phone',
								Website='$Website',
								Status='$Status',
																
								Lastin_Date='$Lastin_Date'
							 
							WHERE Address_ID='$Address_ID'";
							
	mysqli_query($conn,$sql);
}
function DeleteAddress($conn,$Address_ID)
{
	$sql="DELETE FROM tbl_address WHERE Address_ID='$Address_ID'";
	mysqli_query($conn,$sql);
}

?>