<?php
function getAllCategoryData($conn){
	$sql="Select * from tbl_category order by Category_ID";
	$ret=mysqli_query($conn,$sql);
	return $ret;
}
function GetCategoryDataBy_CategoryName($conn,$Category_Name)
{
	$sql="SELECT * FROM tbl_category WHERE Category_Name='$Category_Name'";
	$ret=mysqli_query($conn,$sql);
	return $ret;
}
function GetCategoryDataByCategoryID($conn,$Category_ID)
{
	$sql="SELECT * FROM tbl_category WHERE Category_ID='$Category_ID'";
	return mysqli_query($conn,$sql);
}
function GetCategoryDataByCategory($conn)
{
	$sql="SELECT * FROM tbl_category order by Category_ID desc";
	return mysqli_query($conn,$sql);
}
function InsertCategory($conn,$Category_ID, $Category_Name,$Created_Date,$Lastin_Date)
{
	$sql="INSERT INTO tbl_category(Category_ID, Category_Name,Created_Date,Lastin_Date) 
			VALUES('$Category_ID', '$Category_Name','$Created_Date','$Lastin_Date')";
	mysqli_query($conn,$sql);
}
function UpdateCategory($conn,$Category_ID, $Category_Name,$Lastin_Date)
{
	$sql="UPDATE tbl_category SET Category_Name='$Category_Name', Lastin_Date='$Lastin_Date'
							 
							WHERE Category_ID='$Category_ID'";
	mysqli_query($conn,$sql);
}
function DeleteCategory($conn,$Category_ID)
{
	$sql="DELETE FROM tbl_category WHERE Category_ID='$Category_ID'";
	mysqli_query($conn,$sql);
}
?>