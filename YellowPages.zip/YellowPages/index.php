<?php

include("dal/dal_city.php");
include("dal/dal_category.php");
include("dal/dal_address.php");

?>
<html><head>
		
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<!--[if lte IE 8]><script src="css/ie/html5shiv.js"></script><![endif]-->
		<script src="js/jquery.min.js"></script>
		<script src="js/jquery.dropotron.min.js"></script>
		<script src="js/skel.min.js"></script>
		<script src="js/skel-layers.min.js"></script>
		<script src="js/init.js"></script>
		<noscript>
			<link rel="stylesheet" href="css/skel.css" />
			<link rel="stylesheet" href="css/style.css" />
			<link rel="stylesheet" href="css/style-wide.css" />
		</noscript>
		<!--[if lte IE 8]><link rel="stylesheet" href="css/ie/v8.css" /><![endif]-->
     <style>
     body{
	background:#000!important;
	height:1%!important;
}
	
     </style>
	</head>
	<body>

		<!-- Wrapper -->
			<div class="wrapper style1" style="height:700px;">

			<?php require_once("template/headerindex.php"); ?>
            
            <!--iframe width="97%" height="450" frameborder="0" src="https://dpsmap.carto.com/builder/534a4a8a-b6e9-11e6-87bc-0e8c56e2ffdb/embed" allowfullscreen webkitallowfullscreen mozallowfullscreen oallowfullscreen msallowfullscreen style="margin-top:-2%; margin-left:1%;"></iframe-->				

				<!-- Page -->
					<div id="page" class="container" style="background:none;width:100%">
						<section>
							<!--header class="major">
								<h2>Search for Address</h2>
								
							</header-->
             <form method="get" class="formsearch" style="width:100%;" action="Search">
                            <div class="table-responsive">
                                    <table class="table">
                                         <tbody>
                                         <tr>
                                            <td style="border-top:none;">
                                            	<label for="Address">Address:</label>
                                                <div class="form-group" style="width:100%;">
                                                    <div class="input-group">
                                                    	
                                                        <input class="form-control" id="Address"  placeholder="Address"  type="text" name="Address" />
                                                       
                                                        <div class="input-group-addon"><span class="fa fa-map-marker"></span></div>
                                                   </div>
                                               </div>
                                            </td>
                                            
                                              <td style="border-top:none;">
                                               <label for="Category_Name" >Type:</label>
                                               <div class="form-group">
                                               
                                                <select class="form-control" id="Category_Name" name="Category_Name" >
                                                      <option></option>
													 <?php	
                                                        $retCA=getAllCategoryData($conn);
                                                        while($rowCA=mysqli_fetch_array($retCA))
                                                        {	echo "<option>" . $rowCA['Category_Name'] . "</option>";	}
                                                    ?>
                                                </select>
                                              </div>    
                                              </td>
                                               <td style="border-top:none;">
                                            	<label for="Company">Company:</label>
                                                <div class="form-group ">
                                                    <div class="input-group">
                                                    	
                                                        <input class="form-control" id="Company_Name"  placeholder="Company"  type="text" name="Company_Name"/>
                                                       
                                                       
                                                   </div>
                                               </div>
                                            </td>
                                            <td style="border-top:none;">
                                               <label for="City_Name">City:</label>
                                               <div class="form-group">
                                               
                                                <select class="form-control" id="City_Name" name="City_Name"  >
                                                <option></option>
                                                   <?php	
                                                        $retCI=getAllCityData($conn);
                                                        while($rowCI=mysqli_fetch_array($retCI))
                                                        {	echo "<option>" . $rowCI['City_Name'] . "</option>";	}
                                                    ?>
                                                </select>
                                              </div>    
                                              </td>
                                              <td style="border-top:none;"> <!--button type="submit" name="showAll" class="btn btn-info" style="width:70%">All</button--><p style="margin-top:25px;"></p><button type="submit" class="btn btn-info"  name="btnSearch" style="width:100%">Search</button></td>
                                              </tr>
                                            <!--tr>
                                              <td style="border-top:none;">
                                               <label for="numberofpagecount">Page:</label>
                                            <div class="form-group"  style="width:30%;">
                                            	
                                                <select class="form-control" id="numberofpagecount" name="numberofpagecount" >
                                                  <option><?php //echo $currentPageIndex ;?></option>
                                                   <?php 
                                                   // for($p=1;$p<=$numberofpage;$p++)
                                                   // {echo "<option>".$p ."</option>";}
                                                  ?>
                                                </select>
                                              </div>
                                            
                                            </td>
                                            <td style="border-top:none;">  <label for="btnNumSearch" style="margin-left:-60%">Jump to Page</label><br />
                                            <button type="submit" class="btn btn-info"  name="btnNumSearch" style="width:50%;margin-left:-60%;">Go Pages</button></td> 
                                           
                                         </tr-->
                                         </tbody>
                                     </table>
                                     </div>
                            </form>



						</section>
					</div>
				<!-- /Page -->

					<?php //require_once("template/mainindex.php"); ?>

	</div><!------Wrapper---------->

	<?php //require_once("template/footerindex.php"); ?>

	<?php require_once("template/copyindex.php"); ?>
	</body>
</html>
<style>
 
  section{ width:100%!important; margin-left:1%!important;}
 
 
  
.input-group{width:100%; }
#address-list{float:left;list-style:none;margin-top:10%;padding:0;width:100%;position: absolute; border:1px solid#000;}
#address-list li{padding: 10px; background: #fff; border-bottom: #666; border-radius:1px;}
#address-list li:hover{background:#ccc;cursor: pointer;}

#company-list{float:left;list-style:none;margin-top:10%;padding:0;width:100%;position: absolute; border:1px solid#000;}
#company-list li{padding: 10px; background: #fff; border-bottom: #666; border-radius:1px;}
#company-list li:hover{background:#ccc;cursor: pointer;}
.ac_results{width:30%!important;}
.ac_results li{padding:10px 10px!important; font-family:Arial!important; background:#ccc; border-bottom:1px solid#fafafa; font-size:12px!important;}
.ac_results li:hover{color:#007cc7;}
.input-group-addon{color:#ff0000; background-color: #ffffff; width:10%; border:2px solid#ccc;}

</style>
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<script src="https://code.jquery.com/jquery-2.1.1.min.js" type="text/javascript"></script>
<link rel="stylesheet" type="text/css" href="file/css/jquery.ajaxcomplete.css" />
<script type="text/javascript" src="file/js/jquery.js"></script>
<script type="text/javascript" src="file/js/jquery.ajaxcomplete.js"></script>
<script>
$(document).ready(function(){
 $("#Address").autocomplete("file/ajaxcompleteaddress.php", {
		selectFirst: true
	});
});
</script>
<script>
$(document).ready(function(){
 $("#Company_Name").autocomplete("file/ajaxcompletecompany.php", {
		selectFirst: true
	});
});
</script>
