-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 27, 2018 at 05:17 PM
-- Server version: 10.1.30-MariaDB
-- PHP Version: 7.0.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `yellowpagedb`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_address`
--

CREATE TABLE `tbl_address` (
  `Address_ID` int(11) NOT NULL,
  `Address` varchar(255) NOT NULL,
  `Lng` float NOT NULL,
  `Lat` float NOT NULL,
  `City_Name` varchar(50) NOT NULL,
  `Category_Name` varchar(50) NOT NULL,
  `Company_Name` varchar(200) NOT NULL,
  `Email` varchar(200) NOT NULL,
  `Phone` int(50) NOT NULL,
  `Website` varchar(100) NOT NULL,
  `View` int(11) NOT NULL,
  `Status` varchar(100) NOT NULL,
  `Photo` varchar(5000) NOT NULL,
  `Customer_ID` varchar(255) NOT NULL,
  `Created_Date` varchar(255) NOT NULL,
  `Lastin_Date` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_address`
--

INSERT INTO `tbl_address` (`Address_ID`, `Address`, `Lng`, `Lat`, `City_Name`, `Category_Name`, `Company_Name`, `Email`, `Phone`, `Website`, `View`, `Status`, `Photo`, `Customer_ID`, `Created_Date`, `Lastin_Date`) VALUES
(1, 'Shwe Dagon Pagoda', 96.1496, 16.7983, 'Yangon', 'Pagoda', 'Shwe Dagon', 'shwedagon@gmail.com', 0, '0', 46, 'Success', '../../Photo/YellowPages_pagoda.jpg', '', '10-04-2018', '19-04-2018'),
(2, '1,Pin Ya Road,Ward 10 (NOKA),North Okkalapa', 96.2004, 16.9455, 'Yangon', '', '', '0', 0, '0', 3, 'Success', '0', '0', '0', '0'),
(3, '3,Pin Ya Road,Ward 10 (NOKA),North Okkalapa', 96.2004, 16.9456, 'Yangon', '', '', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(4, '5,Pin Ya Road,Ward 10 (NOKA),North Okkalapa', 96.2005, 16.9457, 'Yangon', '', '', '0', 0, '0', 1, 'Success', '0', '0', '0', '0'),
(5, '262,Bayint Naung (3) Road,Ward 10 (NOKA),North Okkalapa', 96.2012, 16.9459, 'Yangon', '', '', '0', 0, '0', 4, 'Success', '0', '0', '0', '0'),
(6, '263,Bayint Naung (3) Road,Ward 10 (NOKA),North Okkalapa', 96.2011, 16.9458, 'Yangon', '', '', '0', 0, '0', 1, 'Success', '0', '0', '0', '0'),
(7, '264,Bayint Naung (3) Road,Ward 10 (NOKA),North Okkalapa', 96.2011, 16.9457, 'Yangon', '', '', '0', 0, '0', 1, 'Success', '0', '0', '0', '0'),
(8, '280,Mya Wady Street,Ward 10 (NOKA),North Okkalapa', 96.202, 16.9457, 'Yangon', '', '', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(9, '282,Mya Wady Street,Ward 10 (NOKA),North Okkalapa', 96.2019, 16.9456, 'Yangon', '', '', '0', 0, '0', 1, 'Success', '0', '0', '0', '0'),
(10, '284,Mya Wady Street,Ward 10 (NOKA),North Okkalapa', 96.2018, 16.9454, 'Yangon', '', '', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(11, '310,Bo Myat Htun Street,Ward 10 (NOKA),North Okkalapa', 96.202, 16.9447, 'Yangon', '', '', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(12, '312,Bo Myat Htun Street,Ward 10 (NOKA),North Okkalapa', 96.2021, 16.9447, 'Yangon', '', '', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(13, '314,Bo Myat Htun Street,Ward 10 (NOKA),North Okkalapa', 96.2022, 16.9446, 'Yangon', '', '', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(14, '254,Bayint Naung (3) Road,Ward 10 (NOKA),North Okkalapa', 96.2018, 16.9467, 'Yangon', '', '', '0', 0, '0', 1, 'Success', '0', '0', '0', '0'),
(15, '255,Bayint Naung (3) Road,Ward 10 (NOKA),North Okkalapa', 96.2017, 16.9466, 'Yangon', '', '', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(16, '256,Bayint Naung (3) Road,Ward 10 (NOKA),North Okkalapa', 96.2017, 16.9465, 'Yangon', '', '', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(17, '225,Bayint Naung (2) Street,Ward 10 (NOKA),North Okkalapa', 96.2033, 16.9457, 'Yangon', '', '', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(18, '226,Bayint Naung (2) Street,Ward 10 (NOKA),North Okkalapa', 96.2032, 16.9457, 'Yangon', '', '', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(19, '227,Bayint Naung (2) Street,Ward 10 (NOKA),North Okkalapa', 96.2031, 16.9456, 'Yangon', '', '', '0', 0, '0', 1, 'Success', '0', '0', '0', '0'),
(20, '47,Pin Ya Road,Ward 10 (NOKA),North Okkalapa', 96.2019, 16.9477, 'Yangon', '', '', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(21, '49,Pin Ya Road,Ward 10 (NOKA),North Okkalapa', 96.202, 16.9478, 'Yangon', '', '', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(22, '51,Pin Ya Road,Ward 10 (NOKA),North Okkalapa', 96.202, 16.9479, 'Yangon', '', '', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(23, '116,Bayint Naung (3) Road,Ward 10 (NOKA),North Okkalapa', 96.2027, 16.948, 'Yangon', '', '', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(24, '117,Bayint Naung (3) Road,Ward 10 (NOKA),North Okkalapa', 96.2027, 16.9478, 'Yangon', '', '', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(25, '118,Bayint Naung (3) Road,Ward 10 (NOKA),North Okkalapa', 96.2026, 16.9477, 'Yangon', '', '', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(26, '124,Na Wa Dae Street,Ward 10 (NOKA),North Okkalapa', 96.203, 16.9481, 'Yangon', '', '', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(27, '125,Na Wa Dae Street,Ward 10 (NOKA),North Okkalapa', 96.203, 16.9482, 'Yangon', '', '', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(28, '126,Na Wa Dae Street,Ward 10 (NOKA),North Okkalapa', 96.2033, 16.9481, 'Yangon', '', '', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(29, '140,Nat Shin Naung Street,Ward 10 (NOKA),North Okkalapa', 96.2035, 16.948, 'Yangon', '', '', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(30, '139,Nat Shin Naung Street,Ward 10 (NOKA),North Okkalapa', 96.2035, 16.9479, 'Yangon', '', '', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(31, '133,Nat Shin Naung Street,Ward 10 (NOKA),North Okkalapa', 96.2032, 16.9473, 'Yangon', '', '', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(32, '151,Phoe Yazar Street,Ward 10 (NOKA),North Okkalapa', 96.2038, 16.9474, 'Yangon', '', '', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(33, '149,Phoe Yazar Street,Ward 10 (NOKA),North Okkalapa', 96.2039, 16.9475, 'Yangon', '', '', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(34, '148,Nat Shin Naung Street,Ward 10 (NOKA),North Okkalapa', 96.2037, 16.9476, 'Yangon', '', '', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(35, '145,Nat Shin Naung Street,Ward 10 (NOKA),North Okkalapa', 96.2037, 16.9477, 'Yangon', '', '', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(36, '143,Nat Shin Naung Street,Ward 10 (NOKA),North Okkalapa', 96.2038, 16.9478, 'Yangon', '', '', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(37, '147,Phoe Yazar Street,Ward 10 (NOKA),North Okkalapa', 96.2039, 16.9476, 'Yangon', '', '', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(38, '146,Phoe Yazar Street,Ward 10 (NOKA),North Okkalapa', 96.2039, 16.9477, 'Yangon', '', '', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(39, '144,Phoe Yazar Street,Ward 10 (NOKA),North Okkalapa', 96.204, 16.9478, 'Yangon', '', '', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(40, '174,Bayint Naung (3) Road,Ward 10 (NOKA),North Okkalapa', 96.2024, 16.9475, 'Yangon', '', '', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(41, '175,Bayint Naung (3) Road,Ward 10 (NOKA),North Okkalapa', 96.2023, 16.9474, 'Yangon', '', '', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(42, '176,Bayint Naung (3) Road,Ward 10 (NOKA),North Okkalapa', 96.2022, 16.9473, 'Yangon', '', '', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(43, '192,Bayint Naung (2) Street,Ward 10 (NOKA),North Okkalapa', 96.2036, 16.9461, 'Yangon', '', '', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(44, '193,Bayint Naung (2) Street,Ward 10 (NOKA),North Okkalapa', 96.2035, 16.946, 'Yangon', '', '', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(45, '224,Bayint Naung (2) Street,Ward 10 (NOKA),North Okkalapa', 96.2034, 16.9459, 'Yangon', '', '', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(46, '210,Bayint Naung (3) Road,Ward 10 (NOKA),North Okkalapa', 96.202, 16.9469, 'Yangon', '', '', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(47, '209,Bayint Naung (3) Road,Ward 10 (NOKA),North Okkalapa', 96.202, 16.947, 'Yangon', '', '', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(48, '208,Bayint Naung (3) Road,Ward 10 (NOKA),North Okkalapa', 96.2021, 16.9471, 'Yangon', '', '', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(49, '80,Myo Pat St.,Ward 10 (NOKA),North Okkalapa', 96.204, 16.9484, 'Yangon', '', '', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(50, '81,Myo Pat St.,Ward 10 (NOKA),North Okkalapa', 96.2041, 16.9483, 'Yangon', '', '', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(51, '82,Myo Pat St.,Ward 10 (NOKA),North Okkalapa', 96.2043, 16.9483, 'Yangon', '', '', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(52, '9997,Bayint Naung (2) Street,Ward 10 (NOKA),North Okkalapa', 96.2045, 16.9472, 'Yangon', '', '', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(53, '317,Bo Myat Htun Street,Ward 10 (NOKA),North Okkalapa', 96.2024, 16.9445, 'Yangon', '', '', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(54, '319,Bo Myat Htun Street,Ward 10 (NOKA),North Okkalapa', 96.2025, 16.9444, 'Yangon', '', '', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(55, '321,Bo Myat Htun Street,Ward 10 (NOKA),North Okkalapa', 96.2026, 16.9444, 'Yangon', '', '', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(56, '323,Bo Myat Htun Street,Ward 10 (NOKA),North Okkalapa', 96.2027, 16.9443, 'Yangon', '', '', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(57, '325,Bo Myat Htun Street,Ward 10 (NOKA),North Okkalapa', 96.2028, 16.9442, 'Yangon', '', '', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(58, '333,Bo Myat Htun Street,Ward 10 (NOKA),North Okkalapa', 96.2032, 16.944, 'Yangon', '', '', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(59, '335,Bo Myat Htun Street,Ward 10 (NOKA),North Okkalapa', 96.2033, 16.9439, 'Yangon', '', '', '0', 0, '0', 2, 'Success', '0', '0', '0', '0'),
(60, '337,Bo Myat Htun Street,Ward 10 (NOKA),North Okkalapa', 96.2034, 16.9438, 'Yangon', '', '', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(61, '339,Bo Myat Htun Street,Ward 10 (NOKA),North Okkalapa', 96.2035, 16.9438, 'Yangon', '', '', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(62, '368,Bayint Naung (2) Street,Ward 10 (NOKA),North Okkalapa', 96.2027, 16.9448, 'Yangon', '', '', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(63, '379,Bayint Naung (2) Street,Ward 10 (NOKA),North Okkalapa', 96.2028, 16.9449, 'Yangon', '', '', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(64, '372,Bayint Naung (2) Street,Ward 10 (NOKA),North Okkalapa', 96.2029, 16.945, 'Yangon', '', '', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(65, '374,Bayint Naung (2) Street,Ward 10 (NOKA),North Okkalapa', 96.203, 16.9451, 'Yangon', '', '', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(66, '376,Bayint Naung (2) Street,Ward 10 (NOKA),North Okkalapa', 96.2031, 16.9451, 'Yangon', '', '', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(67, '378,Bayint Naung (2) Street,Ward 10 (NOKA),North Okkalapa', 96.2032, 16.9452, 'Yangon', '', '', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(68, '400,Bayint Naung (2) Street,Ward 10 (NOKA),North Okkalapa', 96.2035, 16.9455, 'Yangon', '', '', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(69, '380,Bayint Naung (2) Street,Ward 10 (NOKA),North Okkalapa', 96.2034, 16.9455, 'Yangon', '', '', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(70, '379,Bayint Naung (2) Street,Ward 10 (NOKA),North Okkalapa', 96.2033, 16.9454, 'Yangon', '', '', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(71, '401,Bayint Naung (2) Street,Ward 10 (NOKA),North Okkalapa', 96.2037, 16.9457, 'Yangon', '', '', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(72, '402,Bayint Naung (2) Street,Ward 10 (NOKA),North Okkalapa', 96.2038, 16.9458, 'Yangon', '', '', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(73, '422,Bayint Naung (2) Street,Ward 10 (NOKA),North Okkalapa', 96.2038, 16.9459, 'Yangon', '', '', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(74, '411,Bayint Naung (1) Street,Ward 10 (NOKA),North Okkalapa', 96.2046, 16.9449, 'Yangon', '', '', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(75, '412,Bayint Naung (1) Street,Ward 10 (NOKA),North Okkalapa', 96.2047, 16.945, 'Yangon', '', '', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(76, '413,Bayint Naung (1) Street,Ward 10 (NOKA),North Okkalapa', 96.2047, 16.945, 'Yangon', '', '', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(77, '493,Min Ye Kyaw Swar Street,Ward 10 (NOKA),North Okkalapa', 96.2048, 16.9453, 'Yangon', '', '', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(78, '495,Min Ye Kyaw Swar Street,Ward 10 (NOKA),North Okkalapa', 96.2048, 16.9454, 'Yangon', '', '', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(79, '494,Bayint Naung (1) Street,Ward 10 (NOKA),North Okkalapa', 96.2049, 16.9452, 'Yangon', '', '', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(80, '496,Bayint Naung (1) Street,Ward 10 (NOKA),North Okkalapa', 96.205, 16.9453, 'Yangon', '', '', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(81, '498,Bayint Naung (1) Street,Ward 10 (NOKA),North Okkalapa', 96.2051, 16.9453, 'Yangon', '', '', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(82, '497,Min Ye Kyaw Swar Street,Ward 10 (NOKA),North Okkalapa', 96.2049, 16.9455, 'Yangon', '', '', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(83, '499,Min Ye Kyaw Swar Street,Ward 10 (NOKA),North Okkalapa', 96.205, 16.9456, 'Yangon', '', '', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(84, '501,Min Ye Kyaw Swar Street,Ward 10 (NOKA),North Okkalapa', 96.2051, 16.9456, 'Yangon', '', '', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(85, '503,Min Ye Kyaw Swar Street,Ward 10 (NOKA),North Okkalapa', 96.2052, 16.9457, 'Yangon', '', '', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(86, '500,Bayint Naung (1) Street,Ward 10 (NOKA),North Okkalapa', 96.2052, 16.9454, 'Yangon', '', '', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(87, '502,Bayint Naung (1) Street,Ward 10 (NOKA),North Okkalapa', 96.2052, 16.9455, 'Yangon', '', '', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(88, '504,Bayint Naung (1) Street,Ward 10 (NOKA),North Okkalapa', 96.2053, 16.9456, 'Yangon', '', '', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(89, '506,Bayint Naung (1) Street,Ward 10 (NOKA),North Okkalapa', 96.2054, 16.9457, 'Yangon', '', '', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(90, '505,Min Ye Kyaw Swar Street,Ward 10 (NOKA),North Okkalapa', 96.2053, 16.9458, 'Yangon', '', '', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(91, '507,Min Ye Kyaw Swar Street,Ward 10 (NOKA),North Okkalapa', 96.2054, 16.9459, 'Yangon', '', '', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(92, '508,Bayint Naung (1) Street,Ward 10 (NOKA),North Okkalapa', 96.2055, 16.9458, 'Yangon', '', '', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(93, '509,Min Ye Kyaw Swar Street,Ward 10 (NOKA),North Okkalapa', 96.2054, 16.946, 'Yangon', '', '', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(94, '510,Bayint Naung (1) Street,Ward 10 (NOKA),North Okkalapa', 96.2056, 16.9458, 'Yangon', '', '', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(95, '512,Bayint Naung (1) Street,Ward 10 (NOKA),North Okkalapa', 96.2057, 16.9459, 'Yangon', '', '', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(96, '514,Bayint Naung (1) Street,Ward 10 (NOKA),North Okkalapa', 96.2057, 16.946, 'Yangon', '', '', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(97, '511,Min Ye Kyaw Swar Street,Ward 10 (NOKA),North Okkalapa', 96.2055, 16.9461, 'Yangon', '', '', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(98, '513,Min Ye Kyaw Swar Street,Ward 10 (NOKA),North Okkalapa', 96.2056, 16.9461, 'Yangon', '', '', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(99, '466,Ta Pin Shwe Hi Street,Ward 10 (NOKA),North Okkalapa', 96.2052, 16.9465, 'Yangon', '', '', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(100, '482,Min Ye Kyaw Swar Street,Ward 10 (NOKA),North Okkalapa', 96.2054, 16.9463, 'Yangon', '', '', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(101, '483,Min Ye Kyaw Swar Street,Ward 10 (NOKA),North Okkalapa', 96.2053, 16.9463, 'Yangon', '', '', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(102, 'Lower Kyee Myin Daing Rd.,Htarna Ward,Ahlone', 96.1274, 16.7902, 'Yangon', 'Hospital', 'Academy Hospital', '0', 0, '0', 4, 'Success', '0', '0', '0', '0'),
(103, 'Lower Kyee Myin Daing Rd.,Kayinchan Ward,Ahlone', 96.1293, 16.7925, 'Yangon', 'School', 'B.E.H.S (1) (Ahlone)', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(104, 'Kyee Myin Daing Kannar RD,Sin Min Ward,Ahlone', 96.1257, 16.7863, 'Yangon', 'Condo', 'Ahlone Tower/Shwe Taung Group Of Companies', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(105, 'Ahlone Rd.,Kayinchan Ward,Ahlone', 96.1287, 16.7899, 'Yangon', 'Condo', 'Aspire Condominium', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(106, 'Kyee Myin Daing Kannar Rd.,Indepandent Ward,Ahlone', 96.1239, 16.7885, 'Yangon', 'Residence', 'Aung Zaya Housing', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(107, 'Kanner Road,Indepandent Ward,Ahlone', 96.124, 16.7884, 'Yangon', 'Bank', 'CB Bank Ahlone Branch (Sin Min Market)', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(108, 'Min Ye Kyaw Swar RD.,Saw Yan Paing (East) Ward,Ahlone', 96.135, 16.7851, 'Yangon', 'Condo', 'Crown Condo', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(109, 'Pan Hlaing St.,Pun Hlaing Ward (SCHG),Ahlone', 96.1302, 16.7976, 'Yangon', 'Condo', 'Hematite Condominium', '0', 0, '0', 1, 'Success', '0', '0', '0', '0'),
(110, 'Hnin Si St.,Saw Yan Paing (East) Ward,Ahlone', 96.1344, 16.7842, 'Yangon', 'Condo', 'Hill Top Tower', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(111, 'Min Ye Kyaw Swar RD.,Saw Yan Paing (East) Ward,Ahlone', 96.1352, 16.7829, 'Yangon', 'Condo', 'Hill Top Vista', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(112, 'Min Ye Kyaw Swar Rd.,Saw Yan Paing (East) Ward,Ahlone', 96.1352, 16.7847, 'Yangon', 'Hotel', 'HOTEL GRAND UNITED (Ahlone Branch)', '0', 0, '0', 1, 'Success', '0', '0', '0', '0'),
(113, 'Hnin Si Gone St.,Saw Yan Paing (East) Ward,Ahlone', 96.1346, 16.784, 'Yangon', 'Hotel', 'HOTEL KAN KAW', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(114, 'Ayer Waddy St,Htarna Ward,Ahlone', 96.1278, 16.7881, 'Yangon', 'Condo', 'Kan Yeik Mon', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(115, 'Lower Kyimyintdine Road,Htarna Ward,Ahlone', 96.129, 16.7879, 'Yangon', 'Bank', 'KBZ YANGON BRANCH (102)', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(116, 'Kannar Street,Sin Min Ward,Ahlone', 96.1263, 16.7847, 'Yangon', 'Bank', 'KBZ YANGON BRANCH (84)', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(117, 'Hnin Si Gone ST.,Saw Yan Paing (East) Ward,Ahlone', 96.1346, 16.7842, 'Yangon', 'Condo', 'King Tower Condominium', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(118, 'Min Ye Kyaw Swar Rd.,Saw Yan Paing (East) Ward,Ahlone', 96.1346, 16.7853, 'Yangon', 'Hotel', 'KK Motel', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(119, 'Kyee Myin Daing Kannar Rd.,Sin Min Ward,Ahlone', 96.1239, 16.7907, 'Yangon', 'Residence', 'Mingalar Sin Min Housing', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(120, 'Kyee Myin Daing Kannar Rd.,Sin Min Ward,Ahlone', 96.1264, 16.7864, 'Yangon', 'Residence', 'River View Housing', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(121, 'Thit Taw St.,Thittaw Ward,Ahlone', 96.1277, 16.783, 'Yangon', 'Condo', 'River View Point Condo', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(122, 'Kyee Myin Daing Kannar RD,Sin Min Ward,Ahlone', 96.1245, 16.7889, 'Yangon', 'Condo', 'Royal Sin Min Condo', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(123, 'Shin Saw Pu Rd.,Pun Hlaing Ward (SCHG),Ahlone', 96.1298, 16.7956, 'Yangon', 'Hospital', 'SAKURA HOSPITAL', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(124, 'Than Lwin Street,Shwe Taung Kyar(1) Ward (BHN),Bahan', 96.1465, 16.8173, 'Yangon', 'Hotel', 'AMBASSADOR HOTEL', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(125, 'Sayasan Road,Sayar San Ward (BHN),Bahan', 96.158, 16.8164, 'Yangon', 'Hotel', 'AMBO HOTEL', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(126, 'Kabar Aye Pagoda Rd.,Sayar San Ward (BHN),Bahan', 96.1565, 16.817, 'Yangon', 'Super Market & Shopping Mall', 'Asia Express (Yangon) Co., Ltd.', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(127, 'Shwe Gon Taing Rd.,Shwe Gon Taing Ward (East),Bahan', 96.1689, 16.8113, 'Yangon', 'Residence', 'Aung Chan Thar Housing', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(128, 'Shwegondine Road,Shwe Gon Taing West Ward (BHN),Bahan', 96.1536, 16.805, 'Yangon', 'Bank', 'AYA Yangon (12) Shwegondine Branch', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(129, 'Aye Chan Thar Street,Kyaikasan Ward (BHN),Bahan', 96.1613, 16.8115, 'Yangon', 'Hotel', 'AYE CHAN THAR HOTEL', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(130, 'U Chit Maung Rd.,North Sayar (East) Ward (BHN),Bahan', 96.1656, 16.8194, 'Yangon', 'School', 'B.E.H.S (3) (Bahan)', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(131, 'Bo Cho Street,Bo Cho (1) Ward (BHN),Bahan', 96.1617, 16.8023, 'Yangon', 'Hotel', 'Beauty Land Hotel (I)', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(132, 'Damazedi Road,Shwe Gon Taing West Ward (BHN),Bahan', 96.1456, 16.8058, 'Yangon', 'Hotel', 'BUSINESS ALLIANCE HOTEL', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(133, 'Corner of Damazadi rodad and U Wizaya roda,Shwe Gon Taing West Ward (BHN),Bahan', 96.1428, 16.8046, 'Yangon', 'Bank', 'CB Bank Wizaya Branch', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(134, 'Nat Mauk Rd.,Bo Cho (2) Ward (BHN),Bahan', 96.1668, 16.8004, 'Yangon', 'Office Building', 'Chatriun Hotel Royal Lake Yangon', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(135, 'Shwe Taung Kyar St.,Shwe Taung Kyar(2) Ward (BHN),Bahan', 96.1497, 16.8142, 'Yangon', 'Hotel', 'CLASSIQUE INN', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(136, 'Shwe Gon Taing Rd.,Ko Min Ko Chin Ward (BHN),Bahan', 96.1581, 16.8093, 'Yangon', 'Hotel', 'CRYSTAL PALACE HOTEL', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(137, 'Phoe Sein Rd.,Sayar San Ward (BHN),Bahan', 96.1579, 16.8251, 'Yangon', 'School', 'EC Education Care (Bahan)', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(138, 'Kaba Aye Pagoda Rd.,Ko Min Ko Chin Ward (BHN),Bahan', 96.155, 16.8076, 'Yangon', 'Office Building', 'Excel  Shopping Mall (Excel Co., Ltd.)', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(139, 'Kabar Aye Pagoda Rd.,Ko Min Ko Chin Ward (BHN),Bahan', 96.1548, 16.8079, 'Yangon', 'Hotel', 'EXCEL TREASURE HOTEL', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(140, 'Kaba Aye Pagoda Rd.,Ko Min Ko Chin Ward (BHN),Bahan', 96.1582, 16.8097, 'Yangon', 'Office Building', 'Golden Hill Tower', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(141, 'Shwe Gon Taing Rd.,Ko Min Ko Chin Ward (BHN),Bahan', 96.158, 16.8097, 'Yangon', 'Condo', 'Golden Light Hotel', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(142, 'Inya Myaing RD.,Shwe Taung Kyar(1) Ward (BHN),Bahan', 96.1479, 16.821, 'Yangon', 'Hotel', 'GOLDEN VALLEY INN', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(143, 'New University Avenue Rd.,Sasana Yeiktha Ward (BHN),Bahan', 96.1567, 16.8142, 'Yangon', 'Office Building', 'Good Liff Residence', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(144, 'Kokkine Yeikthar St.,Shwe Taung Kyar(2) Ward (BHN),Bahan', 96.1534, 16.8129, 'Yangon', 'Office Building', 'Green Vision Residence', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(145, 'Pearl St.,Shwe Taung Kyar(2) Ward (BHN),Bahan', 96.1516, 16.8159, 'Yangon', 'Office Building', 'Ho Hup (Myanmar) E & C Co., Ltd.', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(146, 'Pho Sein Rd.,Bo Cho (2) Ward (BHN),Bahan', 96.1708, 16.8039, 'Yangon', 'Hotel', 'HOLIDAY HOTEL', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(147, 'Ngar Htat Kyee Pagoda St.,Bo Cho (1) Ward (BHN),Bahan', 96.1625, 16.8054, 'Yangon', 'Residence', 'Ingyin Myaing Housing / Bo Cho Housing', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(148, 'Ko Min Ko Chin Rd.,Ngar Htat Kyee West Ward (BHN),Bahan', 96.156, 16.803, 'Yangon', 'Hospital', 'Javitadana Sanga Hospital', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(149, 'New University Avenue RD.,Sayar San Ward (BHN),Bahan', 96.1545, 16.8235, 'Yangon', 'Hotel', 'JEWEL HOTEL', '0', 0, '0', 2, 'Success', '0', '0', '0', '0'),
(150, 'Ko Min Ko Chin Rd.,Ko Min Ko Chin Ward (BHN),Bahan', 96.1556, 16.8074, 'Yangon', 'Residence', 'Kaba Aye Housing / Shwe Gon Yeik Mon Housing', '0', 0, '0', 0, 'Success', '0', '0', '0', '0'),
(151, 'Moe Ma Kha Rd.,Bo Cho (2) Ward (BHN),Bahan', 96.1709, 16.8068, 'Yangon', 'Hotel', 'KAUNG LAY INN', '0', 0, '0', 0, 'Success', '0', '0', '0', '0');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_category`
--

CREATE TABLE `tbl_category` (
  `Category_ID` varchar(50) NOT NULL,
  `Category_Name` varchar(255) NOT NULL,
  `Created_Date` varchar(20) NOT NULL,
  `Lastin_Date` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_category`
--

INSERT INTO `tbl_category` (`Category_ID`, `Category_Name`, `Created_Date`, `Lastin_Date`) VALUES
('CA-000001', 'House', '23-03-2018', '23-03-2018'),
('CA-000002', 'Hospital', '23-03-2018', '23-03-2018'),
('CA-000003', 'Bank', '23-03-2018', '23-03-2018'),
('CA-000004', 'Residence', '23-03-2018', '23-03-2018'),
('CA-000005', 'Store', '23-03-2018', '23-03-2018'),
('CA-000006', 'School', '09-04-2018', '09-04-2018'),
('CA-000007', 'Condo', '09-04-2018', '09-04-2018'),
('CA-000008', 'Hotel,aa', '09-04-2018', '10-04-2018'),
('CA-000009', 'Super Market & Shopping Mall', '09-04-2018', '19-04-2018'),
('CA-000010', 'Office Building', '09-04-2018', '09-04-2018'),
('CA-000011', 'Pagoda', '19-04-2018', '19-04-2018');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_city`
--

CREATE TABLE `tbl_city` (
  `City_ID` varchar(50) NOT NULL,
  `City_Name` varchar(255) NOT NULL,
  `Created_Date` varchar(50) NOT NULL,
  `Lastin_Date` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_city`
--

INSERT INTO `tbl_city` (`City_ID`, `City_Name`, `Created_Date`, `Lastin_Date`) VALUES
('CI-000001', 'Yangon', '09-04-2018', '09-04-2018'),
('CI-000002', 'Bago', '09-04-2018', '09-04-2018'),
('CI-000003', 'Mandalay', '09-04-2018', '09-04-2018');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_customer`
--

CREATE TABLE `tbl_customer` (
  `Customer_ID` int(20) NOT NULL,
  `Customer_Name` varchar(50) NOT NULL,
  `Customer_Phone` int(20) NOT NULL,
  `Customer_Email` varchar(20) NOT NULL,
  `Customer_Password` varchar(20) NOT NULL,
  `Customer_Address` text NOT NULL,
  `Created_Date` varchar(20) NOT NULL,
  `Lastin_Date` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_customer`
--

INSERT INTO `tbl_customer` (`Customer_ID`, `Customer_Name`, `Customer_Phone`, `Customer_Email`, `Customer_Password`, `Customer_Address`, `Created_Date`, `Lastin_Date`) VALUES
(1, 'aaaaaa', 3333, 'aa@gmail.com', 'tttttttttt', 'dawefe ', '21-04-2018', ''),
(2, 'aaaaaa', 3333, 'aa@gmail.com', 'tttttttttt', 'dawefe ', '21-04-2018', '21-04-2018'),
(3, 'fd', 3333, 'aa@gmail.com', 'aa', 'fawfw', '21-04-2018', '21-04-2018'),
(4, 'rere', 0, 'aaeee@gmail.com', 'aa', 'fsa', '21-04-2018', '21-04-2018'),
(5, 'adasfe', 0, 'aaeefeawfe@gmail.com', 'aa', 'fase', '21-04-2018', '21-04-2018');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_data`
--

CREATE TABLE `tbl_data` (
  `Data_ID` varchar(50) NOT NULL,
  `DataName_Eng` varchar(255) NOT NULL,
  `DataName_Myan` varchar(255) NOT NULL,
  `Data_Lat` varchar(50) NOT NULL,
  `Data_Long` varchar(50) NOT NULL,
  `Data_Number` int(50) NOT NULL,
  `Data_Street` varchar(255) NOT NULL,
  `Data_Ward` varchar(255) NOT NULL,
  `Data_Township` varchar(255) NOT NULL,
  `Data_State` varchar(255) NOT NULL,
  `Category_ID` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_photo`
--

CREATE TABLE `tbl_photo` (
  `Photo_ID` int(11) NOT NULL,
  `Address_ID` int(11) NOT NULL,
  `PhotoMini` varchar(5000) NOT NULL,
  `PhotoLarge` varchar(5000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `User_ID` varchar(20) NOT NULL,
  `User_Name` varchar(50) NOT NULL,
  `User_Email` varchar(50) NOT NULL,
  `User_Password` varchar(50) NOT NULL,
  `User_Role` varchar(20) NOT NULL,
  `Created_Date` varchar(20) NOT NULL,
  `Lastin_Date` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`User_ID`, `User_Name`, `User_Email`, `User_Password`, `User_Role`, `Created_Date`, `Lastin_Date`) VALUES
('U-000001', 'aa', 'aa@gmail.com', 'aa', 'Admin', '14-03-2018', '16-03-2018'),
('U-000002', 'bb11', 'bb11@gmail.com', 'bb', 'Manager', '16-03-2018', '19-04-2018');

-- --------------------------------------------------------

--
-- Table structure for table `temp`
--

CREATE TABLE `temp` (
  `confirm_code` varchar(100) NOT NULL,
  `Customer_Name` varchar(255) NOT NULL,
  `Customer_Phone` int(20) NOT NULL,
  `Customer_Email` varchar(50) NOT NULL,
  `Customer_Password` varchar(20) NOT NULL,
  `Customer_Address` text NOT NULL,
  `Created_Date` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `temp`
--

INSERT INTO `temp` (`confirm_code`, `Customer_Name`, `Customer_Phone`, `Customer_Email`, `Customer_Password`, `Customer_Address`, `Created_Date`) VALUES
('0', 'xxxxfewe', 3333, 'aa33333@gmail.com', 'aa', 'dawewe', '21-04-2018'),
('0', 'adfaewf', 3333, 'aassss@gmail.com', 'aa', 'fawefw', '21-04-2018');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_address`
--
ALTER TABLE `tbl_address`
  ADD PRIMARY KEY (`Address_ID`);

--
-- Indexes for table `tbl_customer`
--
ALTER TABLE `tbl_customer`
  ADD PRIMARY KEY (`Customer_ID`);

--
-- Indexes for table `tbl_photo`
--
ALTER TABLE `tbl_photo`
  ADD PRIMARY KEY (`Photo_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_address`
--
ALTER TABLE `tbl_address`
  MODIFY `Address_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=152;

--
-- AUTO_INCREMENT for table `tbl_customer`
--
ALTER TABLE `tbl_customer`
  MODIFY `Customer_ID` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tbl_photo`
--
ALTER TABLE `tbl_photo`
  MODIFY `Photo_ID` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
